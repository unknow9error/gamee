import 'dart:math' as math;
import 'dart:ui';

/// A deterministic, connected road network in a 400 × 400 logical canvas.
/// Unused connections are construction sites, never traversable shortcuts.
class MazeNetwork {
  MazeNetwork._(this.nodes, this.roads, this.start, this.goal);

  final List<Offset> nodes;
  final List<MazeRoad> roads;
  final int start;
  final int goal;

  factory MazeNetwork.generate({
    required String seed,
    required int difficulty,
  }) {
    final d = difficulty.clamp(1, 4);
    final columns = d < 3 ? 3 : 4;
    const rows = 4;
    var seedValue = 2166136261;
    for (final unit in seed.codeUnits) {
      seedValue = ((seedValue ^ unit) * 16777619) & 0x7fffffff;
    }
    final random = math.Random(seedValue);
    final nodes = <Offset>[];
    for (var y = 0; y < rows; y++) {
      for (var x = 0; x < columns; x++) {
        nodes.add(
          Offset(
            56 + x * 288 / (columns - 1),
            94 +
                y * 77 +
                (x == 0 || x == columns - 1 ? 0 : random.nextDouble() * 10 - 5),
          ),
        );
      }
    }
    final candidates = <(int, int)>[];
    for (var y = 0; y < rows; y++) {
      for (var x = 0; x < columns; x++) {
        final id = y * columns + x;
        if (x + 1 < columns) candidates.add((id, id + 1));
        if (y + 1 < rows) candidates.add((id, id + columns));
      }
    }
    final start = (rows - 1) * columns;
    final goal = columns - 1;
    // Randomized depth-first spanning tree gives one guaranteed route and
    // meaningful wrong turns without any unreachable part of the network.
    final visited = <int>{start};
    final stack = <int>[start];
    final open = <String>{};
    while (stack.isNotEmpty) {
      final current = stack.last;
      final neighbors =
          candidates
              .where((e) => e.$1 == current || e.$2 == current)
              .map((e) => e.$1 == current ? e.$2 : e.$1)
              .where((n) => !visited.contains(n))
              .toList()
            ..shuffle(random);
      if (neighbors.isEmpty) {
        stack.removeLast();
      } else {
        final next = neighbors.first;
        open.add(MazeRoad.keyFor(current, next));
        visited.add(next);
        stack.add(next);
      }
    }
    final closed =
        candidates
            .where((e) => !open.contains(MazeRoad.keyFor(e.$1, e.$2)))
            .toList()
          ..shuffle(random);
    final blocked = closed
        .take(d + 1)
        .map((e) => MazeRoad.keyFor(e.$1, e.$2))
        .toSet();
    final roads = <MazeRoad>[];
    for (final edge in candidates) {
      final key = MazeRoad.keyFor(edge.$1, edge.$2);
      if (!open.contains(key) && !blocked.contains(key)) continue;
      final a = nodes[edge.$1];
      final b = nodes[edge.$2];
      final delta = b - a;
      final normal = Offset(-delta.dy, delta.dx) / delta.distance;
      final control = (a + b) / 2 + normal * (random.nextBool() ? 11 : -11);
      roads.add(
        MazeRoad(edge.$1, edge.$2, a, b, control, blocked.contains(key)),
      );
    }
    return MazeNetwork._(
      List.unmodifiable(nodes),
      List.unmodifiable(roads),
      start,
      goal,
    );
  }

  Iterable<MazeRoad> roadsFrom(int node) =>
      roads.where((r) => !r.blocked && (r.a == node || r.b == node));
  MazeRoad? roadBetween(int a, int b) {
    for (final road in roads) {
      if (road.key == MazeRoad.keyFor(a, b)) return road;
    }
    return null;
  }

  List<int> routeToGoal(int from) {
    final queue = <int>[from];
    final previous = <int, int?>{from: null};
    for (var i = 0; i < queue.length; i++) {
      final current = queue[i];
      if (current == goal) break;
      for (final edge in roadsFrom(current)) {
        final next = edge.other(current);
        if (previous.containsKey(next)) continue;
        previous[next] = current;
        queue.add(next);
      }
    }
    if (!previous.containsKey(goal)) return [];
    final route = <int>[goal];
    while (route.last != from) {
      route.add(previous[route.last]!);
    }
    return route.reversed.toList(growable: false);
  }
}

class MazeRoad {
  MazeRoad(this.a, this.b, this.from, this.to, this.control, this.blocked);
  final int a;
  final int b;
  final Offset from;
  final Offset to;
  final Offset control;
  final bool blocked;
  String get key => keyFor(a, b);
  static String keyFor(int a, int b) => a < b ? '$a-$b' : '$b-$a';
  int other(int node) => node == a ? b : a;
  Offset point(double t) =>
      from * ((1 - t) * (1 - t)) + control * (2 * (1 - t) * t) + to * (t * t);
  Path get path => Path()
    ..moveTo(from.dx, from.dy)
    ..quadraticBezierTo(control.dx, control.dy, to.dx, to.dy);
}

enum MazeMove { ignored, moving, arrived, blocked, completed }

/// Validates road traversal independently from pointer rendering and persistence.
class MazeSession {
  MazeSession(this.network, {Map<String, dynamic>? saved})
    : route = [network.start] {
    final stored = saved?['route'];
    if (stored is List && stored.isNotEmpty && stored.first == network.start) {
      for (final next in stored.skip(1).take(2000)) {
        if (next is! int || next < 0 || next >= network.nodes.length) break;
        final road = network.roadBetween(route.last, next);
        if (road == null || road.blocked) break;
        route.add(next);
        if (next == network.goal) break;
      }
    }
  }
  final MazeNetwork network;
  final List<int> route;
  MazeRoad? _active;
  double _progress = 0;
  bool _dragging = false;
  int get current => route.last;
  bool get isComplete => current == network.goal;
  bool get isDragging => _dragging;
  Offset get busPosition {
    final road = _active;
    if (road == null) return network.nodes[current];
    return road.point(current == road.a ? _progress : 1 - _progress);
  }

  MazeRoad? get activeRoad => _active;
  double get edgeProgress => _progress;
  Map<String, dynamic> toJson() => {
    'version': 1,
    'type': 'maze',
    'route': List<int>.of(route),
  };

  bool beginDrag(Offset position) {
    if (isComplete || (position - busPosition).distance > 30) return false;
    _dragging = true;
    return true;
  }

  MazeMove dragTo(Offset position) {
    if (!_dragging || isComplete) return MazeMove.ignored;
    MazeRoad? nearest = _active;
    var bestDistance = double.infinity;
    var candidateProgress = _progress;
    final candidates = nearest == null ? network.roadsFrom(current) : [nearest];
    for (final road in candidates) {
      // Sampling the tiny quadratic path also bounds allowed per-event travel.
      for (var i = 0; i <= 40; i++) {
        final t = i / 40;
        final progress = current == road.a ? t : 1 - t;
        if ((progress - _progress).abs() > .32) continue;
        final distance = (position - road.point(t)).distance;
        if (distance < bestDistance) {
          bestDistance = distance;
          nearest = road;
          candidateProgress = progress;
        }
      }
    }
    if (nearest == null || bestDistance > 19) return MazeMove.ignored;
    // Hovering on an intersection must not lock the previous road. A child
    // can pause at a junction and then turn onto any connected road.
    if (candidateProgress < .06 && _active == null) return MazeMove.moving;
    _active = nearest;
    _progress = candidateProgress;
    if (_progress >= .94) {
      route.add(nearest.other(current));
      _active = null;
      _progress = 0;
      return isComplete ? MazeMove.completed : MazeMove.arrived;
    }
    return MazeMove.moving;
  }

  /// Tap alternative: only an immediately connected open road is a valid move.
  MazeMove tapNode(int node) {
    if (isComplete || node == current) return MazeMove.ignored;
    final road = network.roadBetween(current, node);
    if (road == null) return MazeMove.ignored;
    if (road.blocked) return MazeMove.blocked;
    route.add(node);
    _active = null;
    _progress = 0;
    return isComplete ? MazeMove.completed : MazeMove.arrived;
  }

  void endDrag() {
    _active = null;
    _progress = 0;
    _dragging = false;
  }

  void undo() {
    endDrag();
    if (route.length > 1) route.removeLast();
  }

  void reset() {
    endDrag();
    route
      ..clear()
      ..add(network.start);
  }
}
