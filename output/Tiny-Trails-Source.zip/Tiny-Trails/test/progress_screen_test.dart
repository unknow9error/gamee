import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:tiny_trails/application/game_controller.dart';
import 'package:tiny_trails/core/theme.dart';
import 'package:tiny_trails/data/catalog.dart';
import 'package:tiny_trails/domain/models.dart';
import 'package:tiny_trails/features/progress/progress_screen.dart';

void main() {
  Future<void> showProgress(
    WidgetTester tester,
    GameController controller, {
    ValueChanged<LevelDefinition>? onPlay,
    double textScale = 1,
  }) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: buildTheme(),
        builder: (context, child) => MediaQuery(
          data: MediaQuery.of(context)
              .copyWith(textScaler: TextScaler.linear(textScale)),
          child: child!,
        ),
        home: Scaffold(
          body: ProgressScreen(
            controller: controller,
            onPlay: onPlay ?? (_) {},
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();
  }

  testWidgets(
    'mission launches the next unlocked unfinished activity of its kind',
    (tester) async {
      final controller = GameController.forTest();
      addTearDown(controller.dispose);
      await controller.completeLevel(levels.first);
      LevelDefinition? selected;
      await showProgress(
        tester,
        controller,
        onPlay: (level) => selected = level,
      );

      final nextMission = missions.firstWhere(
        (mission) =>
            mission.kind == ActivityKind.numberColor && mission.target == 3,
      );
      final play = find.byKey(ValueKey('mission-play-${nextMission.id}'));
      await tester.ensureVisible(play);
      await tester.tap(play);
      expect(selected, isNotNull);
      expect(selected!.kind, ActivityKind.numberColor);
      expect(controller.isUnlocked(selected!), isTrue);
      expect(controller.progress.containsKey(selected!.id), isFalse);
      expect(find.text(missions.first.title.ru), findsNothing);
    },
  );

  testWidgets(
    'completed mission collection shows collected status without play actions',
    (tester) async {
      final controller = GameController.forTest();
      addTearDown(controller.dispose);
      for (final level in levels) {
        await controller.completeLevel(level);
      }
      await showProgress(tester, controller);
      expect(
        find.text('Миссия выполнена!'),
        findsNWidgets(ActivityKind.values.length),
      );
      expect(find.widgetWithText(TextButton, 'Играть'), findsNothing);
      expect(
        find.text('${missions.length} / ${missions.length}'),
        findsOneWidget,
      );
      expect(tester.takeException(), isNull);
    },
  );

  testWidgets('earned badges update from locked progress after completion', (
    tester,
  ) async {
    final controller = GameController.forTest();
    addTearDown(controller.dispose);
    await showProgress(tester, controller);
    final first = find.byKey(const ValueKey('achievement-first_step'));
    expect(
      find.descendant(of: first, matching: find.text('0 / 1')),
      findsOneWidget,
    );
    expect(
      find.descendant(
        of: first,
        matching: find.byIcon(Icons.lock_outline_rounded),
      ),
      findsOneWidget,
    );

    await controller.completeLevel(levels.first);
    await tester.pumpAndSettle();
    expect(
      find.descendant(of: first, matching: find.text('Получен')),
      findsOneWidget,
    );
    expect(
      find.descendant(of: first, matching: find.byIcon(Icons.check_rounded)),
      findsOneWidget,
    );
    expect(
      find.descendant(
        of: first,
        matching: find.byIcon(Icons.lock_outline_rounded),
      ),
      findsNothing,
    );
  });

  testWidgets(
    'small phone and enlarged localized text fit through the whole collection',
    (tester) async {
      tester.view.physicalSize = const Size(320, 568);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final controller = GameController.forTest();
      addTearDown(controller.dispose);

      for (final language in ['ru', 'kk', 'en']) {
        await controller.setLanguage(language);
        await showProgress(tester, controller, textScale: 1.3);
        expect(tester.takeException(), isNull);
        final last = find.byKey(
          ValueKey('achievement-${achievements.last.id}'),
        );
        await tester.ensureVisible(last);
        await tester.pumpAndSettle();
        expect(tester.takeException(), isNull);
      }
    },
  );
}
