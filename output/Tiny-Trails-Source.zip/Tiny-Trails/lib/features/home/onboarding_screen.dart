import 'package:flutter/material.dart';

import '../../application/game_controller.dart';
import '../../core/strings.dart';
import '../../core/theme.dart';
import '../../domain/models.dart';
import '../../shared/art/scene_illustration.dart';
import '../../shared/widgets/common.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key, required this.controller});
  final GameController controller;
  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _pages = PageController();
  int _page = 0;
  @override
  void dispose() {
    _pages.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.controller, lang = c.language;
    final titles = [
      textFor(
        lang,
        'Большой мир\nмаленьких открытий',
        'Кішкентай жаңалықтардың\nүлкен әлемі',
        'A big world of\nlittle discoveries',
      ),
      textFor(
        lang,
        'Здесь можно\nвсё попробовать',
        'Мұнда бәрін\nбайқап көр',
        'So many ways\nto be curious',
      ),
      textFor(
        lang,
        'Каждый шаг —\nтвоя победа',
        'Әрбір қадам —\nсенің жеңісің',
        'Every little step\nis a big win',
      ),
    ];
    final bodies = [
      textFor(
        lang,
        'Привет, я лисёнок Фини! Давай рисовать, играть и узнавать новое вместе.',
        'Сәлем, мен Фини түлкімін! Бірге сурет салып, ойнап, жаңалық ашайық.',
        'Hi, I’m Fini the fox! Let’s draw, play, and discover wonderful things together.',
      ),
      textFor(
        lang,
        'Раскрашивай, ищи дорогу, находи животных и учись рисовать по шагам.',
        'Сурет боя, жол ізде, жануарларды тап және қадамдап сурет салуды үйрен.',
        'Color pictures, follow trails, find hidden animals, and learn to draw step by step.',
      ),
      textFor(
        lang,
        'Собирай звёзды и сохраняй рисунки. Не спеши: подсказки всегда рядом.',
        'Жұлдыз жинап, суреттеріңді сақта. Асықпа: көмек әрдайым жаныңда.',
        'Collect stars and keep your drawings. Take your time. A little help is always nearby.',
      ),
    ];
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 760),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(24, 16, 16, 0),
                  child: Row(
                    children: [
                      const Icon(Icons.spa_rounded, color: AppColors.green),
                      const SizedBox(width: 7),
                      const Expanded(
                        child: Text(
                          'tiny trails',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 21,
                            fontWeight: FontWeight.w900,
                            letterSpacing: -.7,
                          ),
                        ),
                      ),
                      TextButton(
                        onPressed: () => c.finishOnboarding(),
                        child: Text(
                          textFor(lang, 'Пропустить', 'Өткізу', 'Skip'),
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: PageView.builder(
                    controller: _pages,
                    onPageChanged: (v) => setState(() => _page = v),
                    itemCount: 3,
                    itemBuilder: (context, index) => SingleChildScrollView(
                      padding: const EdgeInsets.fromLTRB(28, 18, 28, 8),
                      child: Column(
                        children: [
                          SizedBox(
                            height: MediaQuery.sizeOf(context).height < 700
                                ? 210
                                : 290,
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                Container(
                                  width: 260,
                                  height: 260,
                                  decoration: BoxDecoration(
                                    color: [
                                      AppColors.lime,
                                      AppColors.blue,
                                      AppColors.peach,
                                    ][index],
                                    shape: BoxShape.circle,
                                  ),
                                ),
                                Entrance(
                                  key: ValueKey(index),
                                  disabled: c.reducedMotion,
                                  child: SceneIllustration(
                                    scene: ['fox', 'whale', 'duck'][index],
                                    size: 280,
                                    subjectOnly: true,
                                  ),
                                ),
                                if (index == 2)
                                  const Positioned(
                                    top: 20,
                                    right: 45,
                                    child: Icon(
                                      Icons.auto_awesome_rounded,
                                      size: 42,
                                      color: Color(0xFFD4A03D),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 18),
                          Text(
                            titles[index],
                            textAlign: TextAlign.center,
                            style: Theme.of(context).textTheme.displaySmall,
                          ),
                          const SizedBox(height: 15),
                          ConstrainedBox(
                            constraints: const BoxConstraints(maxWidth: 400),
                            child: Text(
                              bodies[index],
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                fontSize: 16,
                                color: AppColors.muted,
                                height: 1.5,
                              ),
                            ),
                          ),
                          if (index == 1)
                            Padding(
                              padding: const EdgeInsets.only(top: 20),
                              child: Wrap(
                                alignment: WrapAlignment.center,
                                spacing: 9,
                                children: [
                                  for (final kind in ActivityKind.values)
                                    Container(
                                      width: 45,
                                      height: 45,
                                      decoration: BoxDecoration(
                                        color: activityColor(kind),
                                        borderRadius: BorderRadius.circular(14),
                                      ),
                                      child: Icon(activityIcon(kind), size: 23),
                                    ),
                                ],
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(24, 8, 24, 22),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(
                          3,
                          (i) => AnimatedContainer(
                            duration: Duration(
                              milliseconds: c.reducedMotion ? 0 : 250,
                            ),
                            margin: const EdgeInsets.symmetric(horizontal: 4),
                            width: i == _page ? 25 : 8,
                            height: 8,
                            decoration: BoxDecoration(
                              color: i == _page
                                  ? AppColors.green
                                  : AppColors.line,
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 18),
                      if (_page == 0)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 15),
                          child: SegmentedButton<String>(
                            showSelectedIcon: false,
                            segments: const [
                              ButtonSegment(
                                value: 'ru',
                                label: Text('Русский'),
                              ),
                              ButtonSegment(
                                value: 'kk',
                                label: Text('Қазақша'),
                              ),
                              ButtonSegment(
                                value: 'en',
                                label: Text('English'),
                              ),
                            ],
                            selected: {lang},
                            onSelectionChanged: (v) => c.setLanguage(v.first),
                            style: ButtonStyle(
                              textStyle: WidgetStateProperty.all(
                                const TextStyle(
                                  fontFamily: 'Nunito',
                                  fontSize: 12,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                              minimumSize: WidgetStateProperty.all(
                                const Size(48, 48),
                              ),
                            ),
                          ),
                        ),
                      SizedBox(
                        width: 360,
                        child: FilledButton.icon(
                          key: const Key('onboarding-next'),
                          onPressed: () {
                            if (_page == 2) {
                              c.finishOnboarding();
                            } else {
                              _pages.nextPage(
                                duration: Duration(
                                  milliseconds: c.reducedMotion ? 1 : 350,
                                ),
                                curve: Curves.easeOutCubic,
                              );
                            }
                          },
                          label: Text(
                            _page == 2
                                ? textFor(
                                    lang,
                                    'Пойдём играть!',
                                    'Ойнауға кеттік!',
                                    'Let’s go play!',
                                  )
                                : textFor(lang, 'Дальше', 'Келесі', 'Next'),
                          ),
                          icon: const Icon(Icons.arrow_forward_rounded),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
