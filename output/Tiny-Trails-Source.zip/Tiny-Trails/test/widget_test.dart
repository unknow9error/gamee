import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:tiny_trails/application/game_controller.dart';
import 'package:tiny_trails/data/catalog.dart';
import 'package:tiny_trails/data/progress_store.dart';
import 'package:tiny_trails/domain/models.dart';
import 'package:tiny_trails/features/play/play_screen.dart';
import 'package:tiny_trails/main.dart';
import 'package:tiny_trails/shared/art/art_scene.dart';

void main() {
  testWidgets('onboarding reaches a usable home, studio, and rewards', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(390, 844);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final controller = GameController.inMemory();
    await controller.setReducedMotion(true);
    await tester.pumpWidget(TinyTrailsApp(controller: controller));
    await tester.pumpAndSettle();
    for (var step = 0; step < 3; step++) {
      await tester.tap(find.byKey(const Key('onboarding-next')));
      await tester.pumpAndSettle();
    }
    expect(controller.onboardingComplete, isTrue);
    expect(find.byKey(const Key('continue-adventure')), findsOneWidget);
    await tester.tap(find.text('Мастерская').last);
    await tester.pumpAndSettle();
    expect(find.text('Твоя мастерская'), findsOneWidget);
    await tester.tap(find.text('Награды').last);
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox());
    controller.dispose();
  });

  testWidgets(
    'actual numbered task completion rewards once and survives restart',
    (tester) async {
      tester.view.physicalSize = const Size(390, 844);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final store = MemoryProgressStore();
      final controller = GameController.forTest(store: store);
      await controller.finishOnboarding();
      await controller.setReducedMotion(true);
      await controller.setSound(false);
      await controller.setHaptics(false);
      await controller.markTutorialSeen(ActivityKind.numberColor);
      await tester.pumpWidget(TinyTrailsApp(controller: controller));
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const Key('continue-adventure')));
      await tester.pumpAndSettle();
      final level = levels.first;
      final scene = SceneFactory.create(
        level.scene,
        variant: level.variant,
        segmented: true,
      );
      for (final region in scene.regions) {
        final color = numberPalette[region.number]!;
        await tester.tap(
          find.byKey(ValueKey('color-swatch-${color.toARGB32()}')),
        );
        await tester.pump();
        final rect = tester.getRect(find.byKey(const Key('color-canvas')));
        await tester.tapAt(
          rect.topLeft +
              Offset(
                region.labelPoint.dx / 400 * rect.width,
                region.labelPoint.dy / 400 * rect.height,
              ),
        );
        await tester.pump();
      }
      final button = find.byKey(const Key('color-finish'));
      expect(tester.widget<FilledButton>(button).onPressed, isNotNull);
      await tester.tap(button);
      await tester.pumpAndSettle();
      expect(controller.completedCount, 1);
      expect(controller.totalStars, 3);
      expect(controller.artworks.length, 1);
      expect(controller.earnedAchievements, isNotEmpty);
      await controller.flush();
      final restarted = await GameController.load(store: store);
      expect(restarted.completedCount, 1);
      expect(restarted.totalStars, 3);
      expect(restarted.artworks.single.data['fills'], isNotEmpty);
      expect(tester.takeException(), isNull);
      await tester.pumpWidget(const SizedBox());
      controller.dispose();
      restarted.dispose();
    },
  );

  for (final size in [
    const Size(320, 568),
    const Size(844, 390),
    const Size(768, 1024),
  ]) {
    for (final kind in ActivityKind.values) {
      testWidgets('full ${kind.name} usable canvas at $size', (tester) async {
        tester.view.physicalSize = size;
        tester.view.devicePixelRatio = 1;
        addTearDown(tester.view.resetPhysicalSize);
        addTearDown(tester.view.resetDevicePixelRatio);
        final controller = GameController.inMemory();
        await controller.finishOnboarding();
        await controller.setReducedMotion(true);
        await controller.markTutorialSeen(kind);
        final level = levels.firstWhere((level) => level.kind == kind);
        await tester.pumpWidget(
          MaterialApp(
            home: PlayScreen(controller: controller, level: level),
          ),
        );
        await tester.pumpAndSettle();
        final key = switch (kind) {
          ActivityKind.numberColor || ActivityKind.freeColor => 'color-canvas',
          ActivityKind.maze => 'maze-canvas',
          ActivityKind.guidedDraw => 'drawing-canvas',
          ActivityKind.hiddenAnimals => 'hidden-canvas',
        };
        final canvas = tester.getSize(find.byKey(ValueKey(key)));
        expect(
          canvas.shortestSide,
          greaterThanOrEqualTo(220),
          reason: 'The complete screen must leave room to play.',
        );
        expect(tester.takeException(), isNull);
        await tester.pumpWidget(const SizedBox());
        await tester.pumpAndSettle();
        controller.dispose();
      });
    }
  }
}
