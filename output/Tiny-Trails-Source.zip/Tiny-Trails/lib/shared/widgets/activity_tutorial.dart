import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../core/strings.dart';
import '../../core/theme.dart';
import '../../domain/models.dart';

/// A first-use explanation that demonstrates the gesture rather than putting
/// a long instruction screen between the child and their first activity.
class ActivityTutorial extends StatefulWidget {
  const ActivityTutorial({
    super.key,
    required this.kind,
    required this.language,
    required this.reducedMotion,
    required this.onDismiss,
  });

  final ActivityKind kind;
  final String language;
  final bool reducedMotion;
  final VoidCallback onDismiss;

  @override
  State<ActivityTutorial> createState() => _ActivityTutorialState();
}

class _ActivityTutorialState extends State<ActivityTutorial>
    with SingleTickerProviderStateMixin {
  late final AnimationController _gesture = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 2200),
  )..addStatusListener(_cycle);
  var _cycles = 0;
  var _started = false;

  bool get _still =>
      widget.reducedMotion || MediaQuery.disableAnimationsOf(context);

  void _cycle(AnimationStatus status) {
    if (status == AnimationStatus.completed &&
        mounted &&
        !_still &&
        ++_cycles < 3) {
      _gesture.forward(from: 0);
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_still) {
      _gesture.value = 1;
    } else if (!_started) {
      _started = true;
      _gesture.forward();
    }
  }

  @override
  void dispose() {
    _gesture.dispose();
    super.dispose();
  }

  String _t(String ru, String kk, String en) =>
      textFor(widget.language, ru, kk, en);

  List<String> get _steps => switch (widget.kind) {
    ActivityKind.numberColor => [
      _t(
        'Выбери цвет с числом.',
        'Саны бар түсті таңда.',
        'Choose a numbered color.',
      ),
      _t(
        'Коснись области с таким же числом.',
        'Дәл сол саны бар бөлікті түрт.',
        'Tap a region with the same number.',
      ),
      _t(
        'Раскрась все части картинки.',
        'Суреттің барлық бөлігін боя.',
        'Color every part of the picture.',
      ),
    ],
    ActivityKind.freeColor => [
      _t(
        'Выбери любимый цвет.',
        'Сүйікті түсіңді таңда.',
        'Pick a color you love.',
      ),
      _t(
        'Заливай области или рисуй кистью.',
        'Бөліктерді боя немесе қылқаламмен сал.',
        'Fill a shape or paint with the brush.',
      ),
      _t(
        'Готово? Сохрани свой шедевр!',
        'Дайын ба? Суретіңді сақта!',
        'Ready? Save your masterpiece!',
      ),
    ],
    ActivityKind.maze => [
      _t(
        'Коснись автобуса и веди его по дороге.',
        'Автобусты түртіп, жолмен жүргіз.',
        'Touch the bus and guide it along the road.',
      ),
      _t(
        'Объезжай перекрытые участки.',
        'Жабық жолдарды айналып өт.',
        'Go around the roadworks.',
      ),
      _t(
        'Доберись до школы. Можно идти по шагам!',
        'Мектепке жет. Біртіндеп жүруге болады!',
        'Reach the school. You can move one step at a time!',
      ),
    ],
    ActivityKind.guidedDraw => [
      _t(
        'Проведи пальчиком по контуру.',
        'Саусағыңмен сызықтың үстін жүргіз.',
        'Follow the outline with your finger.',
      ),
      _t(
        'Добавляй детали шаг за шагом.',
        'Бөлшектерді біртіндеп қос.',
        'Add a new part at each step.',
      ),
      _t(
        'Не спеши. Можно отменить и попробовать ещё.',
        'Асықпа. Өшіріп, қайта байқап көр.',
        'Take your time. You can undo and try again.',
      ),
    ],
    ActivityKind.hiddenAnimals => [
      _t(
        'Посмотри, кого нужно найти.',
        'Кімді табу керегін қара.',
        'Look at the friends you need to find.',
      ),
      _t(
        'Ищи животных среди фигур.',
        'Пішіндердің арасынан жануарларды ізде.',
        'Spot the animals hidden in the shapes.',
      ),
      _t(
        'Коснись друга — и он станет цветным!',
        'Досыңды түрт — ол түрлі түске боялады!',
        'Tap a friend to bring their colors back!',
      ),
    ],
  };

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(24, 12, 24, 22),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 500),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Center(
                  child: Container(
                    width: 36,
                    height: 4,
                    decoration: BoxDecoration(
                      color: AppColors.line,
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Text(
                  _t(
                    'Давай попробуем!',
                    'Бірге жасап көрейік!',
                    'Let’s give it a try!',
                  ),
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.headlineMedium,
                ),
                const SizedBox(height: 4),
                Text(
                  activityName(widget.kind, widget.language),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: AppColors.muted,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 16),
                ExcludeSemantics(
                  child: SizedBox(
                    height: 165,
                    child: AnimatedBuilder(
                      animation: _gesture,
                      builder: (context, _) => CustomPaint(
                        painter: _TutorialPainter(
                          kind: widget.kind,
                          progress: _gesture.value,
                          still: _still,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                ..._steps.indexed.map(
                  (step) => Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 28,
                          height: 28,
                          alignment: Alignment.center,
                          decoration: const BoxDecoration(
                            color: AppColors.lime,
                            shape: BoxShape.circle,
                          ),
                          child: Text(
                            '${step.$1 + 1}',
                            style: const TextStyle(fontWeight: FontWeight.w900),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(top: 3),
                            child: Text(
                              step.$2,
                              style: const TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                FilledButton.icon(
                  onPressed: widget.onDismiss,
                  icon: const Icon(Icons.play_arrow_rounded),
                  label: Text(
                    _t('Начать играть', 'Ойынды бастау', 'Let’s play'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _TutorialPainter extends CustomPainter {
  _TutorialPainter({
    required this.kind,
    required this.progress,
    required this.still,
  });
  final ActivityKind kind;
  final double progress;
  final bool still;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    final scale = math.min(size.width / 340, size.height / 165);
    canvas.translate(
      (size.width - 340 * scale) / 2,
      (size.height - 165 * scale) / 2,
    );
    canvas.scale(scale);
    final fill = Paint();
    final outline = Paint()
      ..color = AppColors.ink
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        const Rect.fromLTWH(0, 0, 340, 165),
        const Radius.circular(24),
      ),
      fill..color = const Color(0xFFF0F3E8),
    );
    final t = still
        ? 1.0
        : Curves.easeInOutCubic.transform((progress / .8).clamp(0.0, 1.0));
    Offset pointer;

    switch (kind) {
      case ActivityKind.maze:
        final road = Path()
          ..moveTo(45, 122)
          ..lineTo(125, 122)
          ..quadraticBezierTo(150, 122, 150, 97)
          ..lineTo(150, 69)
          ..quadraticBezierTo(150, 47, 174, 47)
          ..lineTo(275, 47);
        canvas.drawPath(
          road,
          outline
            ..strokeWidth = 26
            ..color = Colors.white,
        );
        canvas.drawPath(
          road,
          outline
            ..strokeWidth = 2.5
            ..color = AppColors.line,
        );
        final branch = Path()
          ..moveTo(150, 97)
          ..lineTo(245, 97);
        canvas.drawPath(
          branch,
          outline
            ..strokeWidth = 20
            ..color = Colors.white,
        );
        final blocked = RRect.fromRectAndRadius(
          const Rect.fromLTWH(204, 85, 12, 26),
          const Radius.circular(2),
        );
        canvas.drawRRect(blocked, fill..color = AppColors.peach);
        for (var y = 88.0; y < 108; y += 7) {
          canvas.drawLine(
            Offset(205, y),
            Offset(215, y + 4),
            outline
              ..strokeWidth = 3
              ..color = AppColors.ink,
          );
        }
        canvas.drawRRect(
          RRect.fromRectAndRadius(
            const Rect.fromLTWH(270, 28, 35, 39),
            const Radius.circular(4),
          ),
          fill..color = AppColors.peach,
        );
        canvas.drawPath(
          Path()
            ..moveTo(265, 28)
            ..lineTo(287, 13)
            ..lineTo(309, 28)
            ..close(),
          fill..color = AppColors.green,
        );
        canvas.drawRect(
          const Rect.fromLTWH(283, 46, 10, 21),
          fill..color = AppColors.paper,
        );
        final metric = road.computeMetrics().first;
        pointer = metric.getTangentForOffset(metric.length * t)!.position;
        canvas.drawRRect(
          RRect.fromRectAndRadius(
            Rect.fromCenter(center: pointer, width: 30, height: 20),
            const Radius.circular(5),
          ),
          fill..color = AppColors.yellow,
        );
        for (final offset in [-9.0, 9.0]) {
          canvas.drawCircle(
            pointer + Offset(offset, 11),
            4,
            fill..color = AppColors.ink,
          );
        }
      case ActivityKind.guidedDraw:
        final duck = Path()
          ..moveTo(132, 79)
          ..cubicTo(100, 25, 179, 4, 186, 52)
          ..cubicTo(189, 72, 174, 83, 168, 89)
          ..cubicTo(207, 102, 237, 89, 244, 87)
          ..cubicTo(243, 133, 166, 151, 141, 111)
          ..cubicTo(135, 102, 133, 88, 132, 79);
        canvas.drawPath(
          duck,
          outline
            ..color = AppColors.muted.withValues(alpha: .3)
            ..strokeWidth = 4,
        );
        final metric = duck.computeMetrics().first;
        canvas.drawPath(
          metric.extractPath(0, metric.length * t),
          outline
            ..color = AppColors.green
            ..strokeWidth = 4,
        );
        canvas.drawCircle(
          const Offset(164, 49),
          3.5,
          fill..color = AppColors.ink,
        );
        final beak = Path()
          ..moveTo(131, 58)
          ..quadraticBezierTo(108, 61, 120, 70)
          ..lineTo(134, 68);
        canvas.drawPath(
          beak,
          outline
            ..color = AppColors.peach
            ..strokeWidth = 4,
        );
        pointer = metric.getTangentForOffset(metric.length * t)!.position;
      case ActivityKind.hiddenAnimals:
        final polygon = [
          Path()
            ..moveTo(82, 30)
            ..lineTo(147, 30)
            ..lineTo(164, 90)
            ..lineTo(94, 90)
            ..close(),
          Path()
            ..moveTo(82, 30)
            ..lineTo(62, 61)
            ..lineTo(91, 58)
            ..close(),
          Path()
            ..moveTo(147, 30)
            ..lineTo(178, 55)
            ..lineTo(155, 60)
            ..close(),
          Path()
            ..moveTo(104, 90)
            ..lineTo(178, 90)
            ..lineTo(189, 139)
            ..lineTo(85, 139)
            ..close(),
        ];
        final background = Path()
          ..moveTo(64, 21)
          ..lineTo(276, 21)
          ..lineTo(276, 144)
          ..lineTo(64, 144)
          ..close();
        canvas.drawPath(background, fill..color = Colors.white);
        canvas.drawPath(
          background,
          outline
            ..color = AppColors.ink
            ..strokeWidth = 2,
        );
        canvas.drawLine(const Offset(180, 21), const Offset(237, 144), outline);
        canvas.drawLine(const Offset(65, 105), const Offset(276, 21), outline);
        canvas.drawLine(const Offset(203, 21), const Offset(276, 110), outline);
        for (final shape in polygon) {
          canvas.drawPath(
            shape,
            fill..color = t > .6 ? AppColors.peach : Colors.white,
          );
          canvas.drawPath(shape, outline);
        }
        for (final point in [const Offset(106, 53), const Offset(136, 53)]) {
          canvas.drawCircle(point, 3, fill..color = AppColors.ink);
        }
        canvas.drawCircle(
          const Offset(123, 69),
          4,
          fill..color = AppColors.ink,
        );
        canvas.drawArc(
          const Rect.fromLTWH(112, 66, 11, 14),
          0,
          math.pi,
          false,
          outline,
        );
        canvas.drawArc(
          const Rect.fromLTWH(123, 66, 11, 14),
          0,
          math.pi,
          false,
          outline,
        );
        pointer = Offset.lerp(
          const Offset(249, 124),
          const Offset(126, 73),
          t,
        )!;
      case ActivityKind.numberColor:
      case ActivityKind.freeColor:
        final petal = Path()
          ..moveTo(193, 92)
          ..cubicTo(147, 115, 122, 80, 145, 57)
          ..cubicTo(151, 24, 192, 31, 193, 67)
          ..cubicTo(203, 24, 245, 32, 243, 64)
          ..cubicTo(276, 71, 257, 111, 218, 98)
          ..cubicTo(242, 123, 203, 145, 193, 112)
          ..cubicTo(175, 143, 142, 121, 169, 99)
          ..close();
        canvas.drawPath(
          petal,
          fill..color = t > .6 ? AppColors.peach : Colors.white,
        );
        canvas.drawPath(
          petal,
          outline
            ..color = AppColors.ink
            ..strokeWidth = 2.5,
        );
        canvas.drawCircle(
          const Offset(196, 87),
          15,
          fill..color = AppColors.yellow,
        );
        canvas.drawCircle(const Offset(196, 87), 15, outline);
        for (var index = 0; index < 3; index++) {
          final color = [
            AppColors.peach,
            AppColors.lavender,
            AppColors.blue,
          ][index];
          canvas.drawCircle(
            Offset(63, 45 + index * 39),
            15,
            fill..color = color,
          );
          if (kind == ActivityKind.numberColor) {
            final label = TextPainter(
              text: TextSpan(
                text: '${index + 6}',
                style: const TextStyle(
                  color: AppColors.ink,
                  fontFamily: 'Nunito',
                  fontWeight: FontWeight.w900,
                  fontSize: 15,
                ),
              ),
              textDirection: TextDirection.ltr,
            )..layout();
            label.paint(
              canvas,
              Offset(63 - label.width / 2, 45 + index * 39 - label.height / 2),
            );
          }
        }
        if (kind == ActivityKind.numberColor && t <= .6) {
          final label = TextPainter(
            text: const TextSpan(
              text: '6',
              style: TextStyle(
                color: AppColors.ink,
                fontFamily: 'Nunito',
                fontSize: 18,
                fontWeight: FontWeight.w900,
              ),
            ),
            textDirection: TextDirection.ltr,
          )..layout();
          label.paint(canvas, const Offset(163, 53));
        }
        pointer = Offset.lerp(
          const Offset(63, 45),
          const Offset(167, 66),
          (t / .65).clamp(0.0, 1.0),
        )!;
    }
    // A light touch ring communicates the tap without relying on color alone.
    final ring = still
        ? 1.0
        : .65 + math.sin(progress * math.pi * 4).abs() * .35;
    canvas.drawCircle(
      pointer,
      16 * ring,
      fill..color = AppColors.green.withValues(alpha: .12),
    );
    canvas.drawCircle(pointer, 8, fill..color = AppColors.paper);
    canvas.drawCircle(
      pointer,
      8,
      outline
        ..color = AppColors.green
        ..strokeWidth = 2.5,
    );
    canvas.drawLine(
      pointer + const Offset(4, 5),
      pointer + const Offset(14, 18),
      outline
        ..strokeWidth = 5
        ..color = AppColors.paper,
    );
    canvas.drawLine(
      pointer + const Offset(4, 5),
      pointer + const Offset(14, 18),
      outline
        ..strokeWidth = 2
        ..color = AppColors.green,
    );
    canvas.restore();
  }

  @override
  bool shouldRepaint(_TutorialPainter oldDelegate) =>
      oldDelegate.progress != progress ||
      oldDelegate.kind != kind ||
      oldDelegate.still != still;
}
