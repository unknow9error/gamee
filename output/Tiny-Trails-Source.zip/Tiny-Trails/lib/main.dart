import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'application/game_controller.dart';
import 'core/theme.dart';
import 'features/home/app_shell.dart';
import 'features/home/onboarding_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final controller = await GameController.load();
  runApp(TinyTrailsApp(controller: controller));
}

class TinyTrailsApp extends StatelessWidget {
  const TinyTrailsApp({super.key, required this.controller});
  final GameController controller;
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: controller,
    builder: (context, _) => MaterialApp(
      title: 'Tiny Trails',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      locale: Locale(controller.language),
      supportedLocales: const [Locale('ru'), Locale('kk'), Locale('en')],
      localizationsDelegates: GlobalMaterialLocalizations.delegates,
      home: controller.onboardingComplete
          ? AppShell(controller: controller)
          : OnboardingScreen(controller: controller),
    ),
  );
}
