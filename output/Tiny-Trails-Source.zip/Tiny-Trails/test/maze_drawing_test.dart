import 'dart:math' as math;
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:tiny_trails/core/theme.dart';
import 'package:tiny_trails/domain/models.dart';
import 'package:tiny_trails/domain/artwork_limits.dart';
import 'package:tiny_trails/features/play/activity_config.dart';
import 'package:tiny_trails/features/play/drawing_activity.dart';
import 'package:tiny_trails/features/play/engines/trace_engine.dart';
import 'package:tiny_trails/shared/art/art_scene.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  List<Offset> sample(Path path, {double offset = 0}) {
    final result = <Offset>[];
    for (final metric in path.computeMetrics()) {
      for (var distance = 0.0; distance < metric.length; distance += 4) {
        final tangent = metric.getTangentForOffset(distance)!;
        result.add(tangent.position + Offset(offset, offset));
      }
    }
    return result;
  }

  test('a real contour, including slightly imprecise tracing, completes', () {
    final circle = Path()..addOval(const Rect.fromLTWH(70, 65, 140, 140));
    final validator = TraceValidator(circle);
    expect(validator.evaluate([sample(circle)]).complete, isTrue);
    final imprecise = validator.evaluate([sample(circle, offset: 8)]);
    expect(imprecise.complete, isTrue);
    expect(imprecise.coverage, greaterThan(.9));
  });

  test('blank input, a dot, and arbitrary scribbling cannot complete', () {
    final circle = Path()..addOval(const Rect.fromLTWH(90, 80, 160, 160));
    final validator = TraceValidator(circle);
    expect(validator.evaluate([]).complete, isFalse);
    expect(
      validator.evaluate([
        [const Offset(100, 100)],
      ]).complete,
      isFalse,
    );
    final scribble = List.generate(
      90,
      (i) => Offset(280 + math.sin(i) * 20, 285 + math.cos(i) * 20),
    );
    expect(validator.evaluate([scribble]).complete, isFalse);
  });

  test('partial contour coverage cannot skip the drawing step', () {
    final oval = Path()..addOval(const Rect.fromLTWH(50, 60, 200, 180));
    final points = sample(oval);
    final result = TraceValidator(oval)
        .evaluate([points.take(points.length ~/ 3).toList()]);
    expect(result.complete, isFalse);
    expect(result.coverage, lessThan(.6));
  });

  test('separate parts must be visited; body cannot skip the face', () {
    final composite = Path()
      ..addOval(const Rect.fromLTWH(50, 60, 220, 210))
      ..addOval(const Rect.fromLTWH(310, 300, 22, 22));
    final body = Path()..addOval(const Rect.fromLTWH(50, 60, 220, 210));
    final result = TraceValidator(composite).evaluate([sample(body)]);
    expect(result.coverage, greaterThan(.78));
    expect(result.complete, isFalse);
    expect(
      TraceValidator(composite).evaluate([
        sample(body),
        sample(Path()..addOval(const Rect.fromLTWH(310, 300, 22, 22))),
      ]).complete,
      isTrue,
    );
  });

  test('large pointer jumps do not fabricate target coverage', () {
    final line = Path()
      ..moveTo(20, 200)
      ..lineTo(380, 200);
    final result = TraceValidator(line).evaluate([
      [const Offset(20, 200), const Offset(380, 200)],
    ]);
    expect(result.complete, isFalse);
    expect(result.drawnLength, 0);
  });

  test('normalized drafts survive resizing without coordinate drift', () {
    final original = [
      [const Offset(12, 24), const Offset(200, 240), const Offset(399, 399)],
    ];
    final encoded = encodeTraceStrokes(original);
    expect(encoded.first.first, [.03, .06]);
    expect(decodeTraceStrokes(encoded), original);
  });

  test('invalid and unbounded draft points are rejected and capped', () {
    final bad = [
      [
        [0, 0],
        [1, 1],
        [double.nan, 0],
        [-1, .4],
        [1.1, .2],
        ['x', 2],
      ],
      [
        [0],
      ],
      for (var i = 0; i < 90; i++)
        [
          [0.2, 0.3],
          [0.4, 0.5],
        ],
    ];
    final decoded = decodeTraceStrokes(bad);
    expect(decoded.length, lessThanOrEqualTo(80));
    expect(decoded.first, [Offset.zero, const Offset(400, 400)]);
    expect(decodeTraceStrokes('bad'), isEmpty);
  });

  test('every real scene can be traced with ordinary small strokes', () {
    for (final scene in SceneFactory.sceneNames) {
      final steps = drawingSteps(scene);
      expect(steps, isNotEmpty, reason: scene);
      for (final step in steps) {
        final strokes = <List<Offset>>[];
        for (final metric in step.path.computeMetrics()) {
          final points = <Offset>[];
          for (var d = 0.0; d < metric.length; d += 2) {
            points.add(metric.getTangentForOffset(d)!.position);
          }
          if (points.length > 1) strokes.add(points);
        }
        expect(
          TraceValidator(step.path, tolerance: 16).evaluate(strokes).complete,
          isTrue,
          reason: '$scene contour ${steps.indexOf(step)}',
        );
        final compact = strokes.map(simplifyTraceStroke).toList();
        expect(
          compact.every(
            (stroke) => stroke.length <= ArtworkLimits.maxPointsPerStroke,
          ),
          isTrue,
        );
        expect(
          TraceValidator(step.path, tolerance: 16).evaluate(compact).complete,
          isTrue,
          reason: '$scene simplified contour ${steps.indexOf(step)}',
        );
      }
    }
  });

  testWidgets('a child traces every duck step, colors and finishes once', (
    tester,
  ) async {
    await tester.binding.setSurfaceSize(const Size(420, 820));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    const level = LevelDefinition(
      id: 'test-duck',
      worldId: 'farm',
      kind: ActivityKind.guidedDraw,
      scene: 'duck',
      variant: 0,
      difficulty: 1,
      title: LocalizedText('Утёнок', 'Үйрек', 'Duck'),
      instruction: LocalizedText('Рисуй', 'Сал', 'Draw'),
      order: 1,
    );
    Map<String, dynamic> draft = {};
    var completions = 0;
    await tester.pumpWidget(
      MaterialApp(
        theme: buildTheme(),
        home: Scaffold(
          body: DrawingActivity(
            config: ActivityConfig(
              level: level,
              language: 'ru',
              reducedMotion: true,
              onChanged: (data) => draft = data,
              onCompleted: (_) => completions++,
              onFeedback: () {},
            ),
          ),
        ),
      ),
    );
    final steps = drawingSteps('duck');
    final canvas = find.byKey(const ValueKey('drawing-canvas'));
    for (var index = 0; index < steps.length; index++) {
      final origin = tester.getTopLeft(canvas);
      final side = tester.getSize(canvas).width;
      for (final metric in steps[index].path.computeMetrics()) {
        if (metric.length < 2) continue;
        final first = metric.getTangentForOffset(0)!.position;
        final gesture = await tester.startGesture(
          origin + first * (side / 400),
        );
        for (var d = 2.0; d < metric.length; d += 3) {
          final point = metric.getTangentForOffset(d)!.position;
          await gesture.moveTo(origin + point * (side / 400));
        }
        await gesture.up();
        await tester.pump();
        if ((draft['step'] as int? ?? 0) > index) break;
      }
      expect(
        draft['step'],
        index + 1,
        reason: 'stage $index must advance only after tracing',
      );
    }
    expect(find.text('Теперь добавь цвета!'), findsOneWidget);
    expect(completions, 0);
    final art = SceneFactory.create('duck');
    final targets = <String, Offset>{};
    for (var y = 40.0; y < 360 && targets.length < 2; y += 8) {
      for (var x = 40.0; x < 360 && targets.length < 2; x += 8) {
        final point = Offset(x, y);
        final hits = art.regions.reversed.where((r) => r.path.contains(point));
        if (hits.isNotEmpty && hits.first.group == 'subject') {
          targets.putIfAbsent(hits.first.id, () => point);
        }
      }
    }
    expect(targets.length, 2);
    final origin = tester.getTopLeft(canvas);
    final side = tester.getSize(canvas).width;
    for (final point in targets.values) {
      await tester.tapAt(origin + point * (side / 400));
      await tester.pump();
    }
    await tester.tap(find.text('Готово!'));
    await tester.pump();
    expect(completions, 1);
    expect(draft['fills'], hasLength(2));
    expect(draft['strokes'], isNotEmpty);
    expect(utf8.encode(jsonEncode(draft)).length, lessThan(300 * 1024));
    expect(tester.takeException(), isNull);
  });

  for (final size in const [Size(320, 480), Size(768, 1024), Size(1024, 768)]) {
    testWidgets(
      'drawing adapts and restores a valid finished contour at $size',
      (tester) async {
        tester.view.physicalSize = size;
        tester.view.devicePixelRatio = 1;
        addTearDown(tester.view.resetPhysicalSize);
        addTearDown(tester.view.resetDevicePixelRatio);
        const level = LevelDefinition(
          id: 'test-resume',
          worldId: 'ocean',
          kind: ActivityKind.guidedDraw,
          scene: 'duck',
          variant: 2,
          difficulty: 4,
          title: LocalizedText('a', 'b', 'c'),
          instruction: LocalizedText('a', 'b', 'c'),
          order: 1,
        );
        final first = drawingSteps('duck').first;
        final strokes = <List<Offset>>[];
        for (final metric in first.path.computeMetrics()) {
          final points = <Offset>[];
          for (var d = 0.0; d < metric.length; d += 2) {
            points.add(metric.getTangentForOffset(d)!.position);
          }
          if (points.length > 1) strokes.add(points);
        }
        await tester.pumpWidget(
          MaterialApp(
            theme: buildTheme(),
            home: Scaffold(
              body: DrawingActivity(
                config: ActivityConfig(
                  level: level,
                  language: 'en',
                  reducedMotion: true,
                  showHint: true,
                  initialData: {
                    'type': 'guidedDraw',
                    'stepStrokes': [encodeTraceStrokes(strokes)],
                  },
                  onChanged: (_) {},
                  onCompleted: (_) {},
                  onFeedback: () {},
                ),
              ),
            ),
          ),
        );
        expect(
          find.text('Step 2 of ${drawingSteps('duck').length}'),
          findsOneWidget,
        );
        expect(tester.takeException(), isNull);
        expect(
          tester
              .getSize(find.byKey(const ValueKey('drawing-canvas')))
              .shortestSide,
          greaterThan(100),
        );
      },
    );
  }

  testWidgets('invalid restored stages cannot skip to coloring', (
    tester,
  ) async {
    const level = LevelDefinition(
      id: 'test-invalid',
      worldId: 'farm',
      kind: ActivityKind.guidedDraw,
      scene: 'duck',
      variant: 0,
      difficulty: 1,
      title: LocalizedText('a', 'b', 'c'),
      instruction: LocalizedText('a', 'b', 'c'),
      order: 1,
    );
    await tester.pumpWidget(
      MaterialApp(
        theme: buildTheme(),
        home: Scaffold(
          body: DrawingActivity(
            config: ActivityConfig(
              level: level,
              language: 'en',
              reducedMotion: true,
              initialData: {
                'type': 'guidedDraw',
                'step': 999,
                'stepStrokes': [[]],
                'fills': {'head': 0xff00ff00},
              },
              onChanged: (_) {},
              onCompleted: (_) => fail('No completion from invalid draft'),
              onFeedback: () {},
            ),
          ),
        ),
      ),
    );
    expect(
      find.text('Step 1 of ${drawingSteps('duck').length}'),
      findsOneWidget,
    );
    expect(find.text('Now add your colors!'), findsNothing);
  });

  for (final size in const [Size(320, 430), Size(844, 310)]) {
    for (final coloring in [false, true]) {
      testWidgets('drawing keeps a usable canvas at $size coloring=$coloring', (
        tester,
      ) async {
        tester.view.physicalSize = size;
        tester.view.devicePixelRatio = 1;
        addTearDown(tester.view.resetPhysicalSize);
        addTearDown(tester.view.resetDevicePixelRatio);
        const level = LevelDefinition(
          id: 'small',
          worldId: 'farm',
          kind: ActivityKind.guidedDraw,
          scene: 'duck',
          variant: 0,
          difficulty: 4,
          title: LocalizedText('a', 'b', 'c'),
          instruction: LocalizedText('a', 'b', 'c'),
          order: 0,
        );
        final completed = <dynamic>[];
        if (coloring) {
          for (final step in drawingSteps('duck')) {
            final strokes = <List<Offset>>[];
            for (final metric in step.path.computeMetrics()) {
              final points = <Offset>[];
              for (var d = 0.0; d < metric.length; d += 4) {
                points.add(metric.getTangentForOffset(d)!.position);
              }
              if (points.length > 1) strokes.add(simplifyTraceStroke(points));
            }
            completed.add(encodeTraceStrokes(strokes));
          }
        }
        await tester.pumpWidget(
          MaterialApp(
            theme: buildTheme(),
            home: Scaffold(
              body: DrawingActivity(
                config: ActivityConfig(
                  level: level,
                  language: 'ru',
                  reducedMotion: true,
                  initialData: {'type': 'guidedDraw', 'stepStrokes': completed},
                  onChanged: (_) {},
                  onCompleted: (_) {},
                  onFeedback: () {},
                ),
              ),
            ),
          ),
        );
        expect(tester.takeException(), isNull);
        if (coloring) expect(find.text('Теперь добавь цвета!'), findsOneWidget);
        expect(
          tester
              .getSize(find.byKey(const ValueKey('drawing-canvas')))
              .shortestSide,
          greaterThanOrEqualTo(220),
        );
      });
    }
  }
}
