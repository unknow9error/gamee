import 'package:flutter/material.dart';

import '../../application/game_controller.dart';
import '../../core/strings.dart';
import '../../core/theme.dart';
import '../../data/catalog.dart';
import '../../domain/models.dart';

/// A child's collection of discoveries. Rewards follow completed activities,
/// so returning to a game never removes a previously earned badge.
class ProgressScreen extends StatelessWidget {
  const ProgressScreen({
    super.key,
    required this.controller,
    required this.onPlay,
  });

  final GameController controller;
  final ValueChanged<LevelDefinition> onPlay;

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: controller,
    builder: (context, _) {
      final language = controller.language;
      final completedMissions = missions
          .where(
            (mission) => controller.missionProgress(mission) >= mission.target,
          )
          .length;
      // Show the next achievable milestone for each skill instead of flooding
      // the child with every future cumulative mission at once.
      final currentMissions = <MissionDefinition>[
        for (final kind in ActivityKind.values) _currentMission(kind),
      ];
      final orderedMissions = [...currentMissions]
        ..sort((a, b) {
          final aDone = controller.missionProgress(a) >= a.target;
          final bDone = controller.missionProgress(b) >= b.target;
          if (aDone == bDone) {
            return missions.indexOf(a).compareTo(missions.indexOf(b));
          }
          return aDone ? 1 : -1;
        });

      return SingleChildScrollView(
        key: const PageStorageKey('discoveries-scroll'),
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 1060),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _CollectionHeader(
                  language: language,
                  completedCount: controller.completedCount,
                  totalStars: controller.totalStars,
                  badgeCount: controller.earnedAchievements.length,
                ),
                const SizedBox(height: 30),
                _SectionTitle(
                  title: textFor(
                    language,
                    'Твои миссии',
                    'Сенің миссияларың',
                    'Your missions',
                  ),
                  subtitle: textFor(
                    language,
                    'Выбирай, что хочется открыть сегодня.',
                    'Бүгін не ашқың келетінін таңда.',
                    'Choose what you want to discover today.',
                  ),
                  count: '$completedMissions / ${missions.length}',
                ),
                const SizedBox(height: 16),
                LayoutBuilder(
                  builder: (context, constraints) {
                    final columns = constraints.maxWidth >= 720 ? 2 : 1;
                    final width =
                        (constraints.maxWidth - (columns - 1) * 14) / columns;
                    return Wrap(
                      spacing: 14,
                      runSpacing: 14,
                      children: orderedMissions.map((mission) {
                        final nextLevel = _nextFor(mission.kind);
                        return SizedBox(
                          width: width,
                          child: _MissionCard(
                            mission: mission,
                            language: language,
                            completed: controller.missionProgress(mission),
                            onPlay: nextLevel == null
                                ? null
                                : () => onPlay(nextLevel),
                          ),
                        );
                      }).toList(),
                    );
                  },
                ),
                const SizedBox(height: 30),
                _SectionTitle(
                  title: textFor(
                    language,
                    'Коллекция значков',
                    'Белгілер жинағы',
                    'Your badge collection',
                  ),
                  subtitle: textFor(
                    language,
                    'Каждый значок — новое умение.',
                    'Әр белгі — жаңа дағды.',
                    'Every badge is a new skill.',
                  ),
                  count:
                      '${controller.earnedAchievements.length} / ${achievements.length}',
                ),
                const SizedBox(height: 16),
                LayoutBuilder(
                  builder: (context, constraints) {
                    final columns = constraints.maxWidth >= 860
                        ? 4
                        : constraints.maxWidth >= 560
                        ? 3
                        : 2;
                    final width =
                        (constraints.maxWidth - (columns - 1) * 12) / columns;
                    return Wrap(
                      spacing: 12,
                      runSpacing: 12,
                      children: achievements.map((achievement) {
                        final count = controller.achievementProgress(
                          achievement,
                        );
                        return SizedBox(
                          width: width,
                          child: _AchievementCard(
                            achievement: achievement,
                            language: language,
                            completed: count,
                          ),
                        );
                      }).toList(),
                    );
                  },
                ),
                const SizedBox(height: 24),
                _Encouragement(language: language),
              ],
            ),
          ),
        ),
      );
    },
  );

  LevelDefinition? _nextFor(ActivityKind kind) {
    LevelDefinition? replay;
    for (final level in levels) {
      if (level.kind != kind || !controller.isUnlocked(level)) continue;
      replay ??= level;
      if (!controller.progress.containsKey(level.id)) return level;
    }
    return replay;
  }

  MissionDefinition _currentMission(ActivityKind kind) {
    final sequence = missions.where((mission) => mission.kind == kind).toList();
    return sequence.firstWhere(
      (mission) => controller.missionProgress(mission) < mission.target,
      orElse: () => sequence.last,
    );
  }
}

class _CollectionHeader extends StatelessWidget {
  const _CollectionHeader({
    required this.language,
    required this.completedCount,
    required this.totalStars,
    required this.badgeCount,
  });

  final String language;
  final int completedCount;
  final int totalStars;
  final int badgeCount;

  @override
  Widget build(BuildContext context) => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(24),
    decoration: BoxDecoration(
      color: AppColors.green,
      borderRadius: BorderRadius.circular(28),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.all(11),
              decoration: const BoxDecoration(
                color: AppColors.lime,
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.auto_awesome_rounded,
                color: AppColors.ink,
                size: 24,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                textFor(
                  language,
                  'Мои открытия',
                  'Менің жаңалықтарым',
                  'My discoveries',
                ),
                style: Theme.of(context).textTheme.headlineMedium
                    ?.copyWith(color: Colors.white),
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        Text(
          textFor(
            language,
            'Рисуй, исследуй и собирай свои маленькие победы.',
            'Сурет сал, зертте және шағын жеңістеріңді жина.',
            'Draw, explore, and collect your little victories.',
          ),
          style: Theme.of(context).textTheme.bodyLarge
              ?.copyWith(color: const Color(0xFFE5EEDD)),
        ),
        const SizedBox(height: 22),
        Wrap(
          spacing: 12,
          runSpacing: 12,
          children: [
            _StatPill(
              icon: Icons.check_circle_outline_rounded,
              value: '$completedCount',
              label: textFor(language, 'открытий', 'жаңалық', 'discoveries'),
            ),
            _StatPill(
              icon: Icons.star_rounded,
              value: '$totalStars',
              label: textFor(language, 'звёзд', 'жұлдыз', 'stars'),
            ),
            _StatPill(
              icon: Icons.workspace_premium_rounded,
              value: '$badgeCount',
              label: textFor(language, 'значков', 'белгі', 'badges'),
            ),
          ],
        ),
      ],
    ),
  );
}

class _StatPill extends StatelessWidget {
  const _StatPill({
    required this.icon,
    required this.value,
    required this.label,
  });
  final IconData icon;
  final String value;
  final String label;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 10),
    decoration: BoxDecoration(
      color: Colors.white.withValues(alpha: 0.13),
      borderRadius: BorderRadius.circular(16),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, color: AppColors.lime, size: 22),
        const SizedBox(width: 7),
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w900,
            fontSize: 18,
          ),
        ),
        const SizedBox(width: 5),
        Flexible(
          child: Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 13,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ],
    ),
  );
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({
    required this.title,
    required this.subtitle,
    required this.count,
  });
  final String title;
  final String subtitle;
  final String count;

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Row(
        children: [
          Expanded(
            child: Text(title, style: Theme.of(context).textTheme.titleLarge),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
            decoration: BoxDecoration(
              color: AppColors.line,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              count,
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12),
            ),
          ),
        ],
      ),
      const SizedBox(height: 5),
      Text(
        subtitle,
        style: const TextStyle(color: AppColors.muted, fontSize: 14),
      ),
    ],
  );
}

class _MissionCard extends StatelessWidget {
  const _MissionCard({
    required this.mission,
    required this.language,
    required this.completed,
    required this.onPlay,
  });
  final MissionDefinition mission;
  final String language;
  final int completed;
  final VoidCallback? onPlay;

  @override
  Widget build(BuildContext context) {
    final done = completed >= mission.target;
    final current = completed.clamp(0, mission.target);
    final progress = mission.target <= 0 ? 1.0 : current / mission.target;
    final color = _activityColor(mission.kind);
    return Container(
      key: ValueKey('mission-${mission.id}'),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: done ? AppColors.green.withValues(alpha: 0.3) : AppColors.line,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: color,
                  borderRadius: BorderRadius.circular(17),
                ),
                child: Icon(
                  _activityIcon(mission.kind),
                  size: 27,
                  color: AppColors.ink,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      activityName(mission.kind, language),
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        color: AppColors.muted,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      mission.title.resolve(language),
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                  ],
                ),
              ),
              if (done)
                const Padding(
                  padding: EdgeInsets.only(left: 6),
                  child: Icon(
                    Icons.check_circle_rounded,
                    color: AppColors.green,
                    size: 24,
                  ),
                ),
            ],
          ),
          const SizedBox(height: 18),
          Semantics(
            label: textFor(
              language,
              'Прогресс миссии',
              'Миссия барысы',
              'Mission progress',
            ),
            value: '$current / ${mission.target}',
            child: LinearProgressIndicator(
              value: progress,
              minHeight: 8,
              borderRadius: BorderRadius.circular(8),
              color: AppColors.green,
              backgroundColor: color.withValues(alpha: 0.55),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: Text(
                  done
                      ? textFor(
                          language,
                          'Миссия выполнена!',
                          'Миссия орындалды!',
                          'Mission complete!',
                        )
                      : '$current / ${mission.target}',
                  style: TextStyle(
                    fontSize: 13,
                    color: done ? AppColors.green : AppColors.muted,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              if (!done)
                TextButton.icon(
                  key: ValueKey('mission-play-${mission.id}'),
                  onPressed: onPlay,
                  style: TextButton.styleFrom(
                    minimumSize: const Size(48, 48),
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    foregroundColor: AppColors.green,
                  ),
                  label: Text(textFor(language, 'Играть', 'Ойнау', 'Play')),
                  icon: const Icon(Icons.arrow_forward_rounded, size: 18),
                  iconAlignment: IconAlignment.end,
                ),
            ],
          ),
        ],
      ),
    );
  }
}

class _AchievementCard extends StatelessWidget {
  const _AchievementCard({
    required this.achievement,
    required this.language,
    required this.completed,
  });
  final AchievementDefinition achievement;
  final String language;
  final int completed;

  @override
  Widget build(BuildContext context) {
    final earned = completed >= achievement.target;
    final count = completed.clamp(0, achievement.target);
    final color = achievement.kind == null
        ? AppColors.yellow
        : _activityColor(achievement.kind!);
    final status = earned
        ? textFor(language, 'Получен', 'Алынды', 'Collected')
        : '$count / ${achievement.target}';
    return Semantics(
      label:
          '${achievement.title.resolve(language)}. ${achievement.description.resolve(language)}. $status',
      child: Container(
        key: ValueKey('achievement-${achievement.id}'),
        constraints: const BoxConstraints(minHeight: 205),
        padding: const EdgeInsets.fromLTRB(14, 20, 14, 16),
        decoration: BoxDecoration(
          color: earned
              ? color.withValues(alpha: 0.32)
              : const Color(0xFFF3F3EC),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: earned ? color : AppColors.line),
        ),
        child: Column(
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                Container(
                  width: 66,
                  height: 66,
                  decoration: BoxDecoration(
                    color: earned ? color : const Color(0xFFE4E8DE),
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white, width: 4),
                  ),
                  child: Icon(
                    achievement.kind == null
                        ? Icons.auto_awesome_rounded
                        : _activityIcon(achievement.kind!),
                    color: earned ? AppColors.ink : const Color(0xFF9CA89A),
                    size: 30,
                  ),
                ),
                Positioned(
                  bottom: -3,
                  right: -2,
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: earned ? AppColors.green : const Color(0xFFD6DED2),
                      shape: BoxShape.circle,
                      border: Border.all(color: AppColors.paper, width: 2),
                    ),
                    child: Icon(
                      earned ? Icons.check_rounded : Icons.lock_outline_rounded,
                      color: Colors.white,
                      size: 13,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 15),
            Text(
              achievement.title.resolve(language),
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w900,
                color: earned ? AppColors.ink : AppColors.muted,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              achievement.description.resolve(language),
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 11,
                height: 1.35,
                color: AppColors.muted,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              status,
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w900,
                color: earned ? AppColors.green : AppColors.muted,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Encouragement extends StatelessWidget {
  const _Encouragement({required this.language});
  final String language;

  @override
  Widget build(BuildContext context) => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(17),
    decoration: BoxDecoration(
      color: AppColors.lime.withValues(alpha: 0.35),
      borderRadius: BorderRadius.circular(20),
    ),
    child: Row(
      children: [
        const Icon(
          Icons.favorite_outline_rounded,
          color: AppColors.green,
          size: 25,
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            textFor(
              language,
              'Учись в своём темпе. Подсказки помогают — звёзды остаются с тобой.',
              'Өз қарқыныңмен үйрен. Көмек алсаң да, жұлдыздарың өзіңде қалады.',
              'Learn at your own pace. Hints help, and your stars stay yours.',
            ),
            style: const TextStyle(
              fontSize: 13,
              color: AppColors.green,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ],
    ),
  );
}

IconData _activityIcon(ActivityKind kind) => switch (kind) {
  ActivityKind.numberColor => Icons.format_color_fill_rounded,
  ActivityKind.freeColor => Icons.palette_outlined,
  ActivityKind.maze => Icons.route_rounded,
  ActivityKind.guidedDraw => Icons.gesture_rounded,
  ActivityKind.hiddenAnimals => Icons.search_rounded,
};

Color _activityColor(ActivityKind kind) => switch (kind) {
  ActivityKind.numberColor => AppColors.blue,
  ActivityKind.freeColor => AppColors.peach,
  ActivityKind.maze => AppColors.lime,
  ActivityKind.guidedDraw => AppColors.lavender,
  ActivityKind.hiddenAnimals => AppColors.yellow,
};
