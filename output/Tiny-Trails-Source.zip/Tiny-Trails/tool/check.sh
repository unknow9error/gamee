#!/usr/bin/env sh
set -eu
flutter analyze
flutter test
