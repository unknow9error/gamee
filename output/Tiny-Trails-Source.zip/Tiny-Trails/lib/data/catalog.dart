import '../domain/models.dart';

/// Content is data: adding a world never changes the game engines or navigation.
const worlds = <WorldDefinition>[
  WorldDefinition(
    id: 'ocean',
    title: LocalizedText('Океан чудес', 'Ғажайып мұхит', 'Wonder ocean'),
    subtitle: LocalizedText(
      'Ныряем за вдохновением',
      'Шабыт іздеп сүңгиміз',
      'Dive into imagination',
    ),
    color: 0xFF398EBA,
    scene: 'whale',
    order: 0,
  ),
  WorldDefinition(
    id: 'forest',
    title: LocalizedText('Лесные истории', 'Орман хикаялары', 'Forest stories'),
    subtitle: LocalizedText(
      'Подружись с лесом',
      'Орманмен достас',
      'Meet your woodland friends',
    ),
    color: 0xFF638A63,
    scene: 'fox',
    order: 1,
  ),
  WorldDefinition(
    id: 'meadow',
    title: LocalizedText('Цветочная поляна', 'Гүлді алаң', 'Blossom meadow'),
    subtitle: LocalizedText(
      'Маленькие открытия каждый день',
      'Күн сайын кішкентай жаңалық',
      'Little things, big discoveries',
    ),
    color: 0xFFAB78AC,
    scene: 'butterfly',
    order: 2,
  ),
  WorldDefinition(
    id: 'farm',
    title: LocalizedText('Солнечная ферма', 'Шуақты ферма', 'Sunny farm'),
    subtitle: LocalizedText(
      'Уютные приключения',
      'Жайлы шытырман оқиғалар',
      'A happy place to explore',
    ),
    color: 0xFFD7A342,
    scene: 'duck',
    order: 3,
  ),
  WorldDefinition(
    id: 'safari',
    title: LocalizedText('Большое сафари', 'Үлкен сафари', 'Grand safari'),
    subtitle: LocalizedText(
      'Вперёд, навстречу друзьям',
      'Достарға қарай алға',
      'Adventure with new friends',
    ),
    color: 0xFFC37A4D,
    scene: 'giraffe',
    order: 4,
  ),
  WorldDefinition(
    id: 'space',
    title: LocalizedText(
      'Звёздная мастерская',
      'Жұлдызды шеберхана',
      'Starlight studio',
    ),
    subtitle: LocalizedText(
      'Воображение без границ',
      'Қиялға шек жоқ',
      'Imagine beyond the stars',
    ),
    color: 0xFF7779B8,
    scene: 'rocket',
    order: 5,
  ),
];

const _worldScenes = <String, List<String>>{
  'ocean': ['whale', 'dolphin', 'turtle', 'whale'],
  'forest': ['fox', 'owl', 'rabbit', 'fox'],
  'meadow': ['butterfly', 'rabbit', 'turtle', 'butterfly'],
  'farm': ['duck', 'cat', 'rabbit', 'duck'],
  'safari': ['giraffe', 'lion', 'turtle', 'giraffe'],
  'space': ['rocket', 'owl', 'cat', 'rocket'],
};

const sceneNames = <String, LocalizedText>{
  'whale': LocalizedText('Кит', 'Кит', 'Whale'),
  'dolphin': LocalizedText('Дельфин', 'Дельфин', 'Dolphin'),
  'duck': LocalizedText('Утёнок', 'Үйрек балапаны', 'Duckling'),
  'turtle': LocalizedText('Черепашка', 'Тасбақа', 'Turtle'),
  'fox': LocalizedText('Лисёнок', 'Түлкі', 'Little fox'),
  'rabbit': LocalizedText('Зайчонок', 'Қоян', 'Bunny'),
  'cat': LocalizedText('Котёнок', 'Марғау', 'Kitten'),
  'butterfly': LocalizedText('Бабочка', 'Көбелек', 'Butterfly'),
  'lion': LocalizedText('Львёнок', 'Арыстан', 'Lion cub'),
  'giraffe': LocalizedText('Жираф', 'Керік', 'Giraffe'),
  'rocket': LocalizedText('Ракета', 'Зымыран', 'Rocket'),
  'owl': LocalizedText('Совёнок', 'Жапалақ', 'Little owl'),
};

const activityNames = <ActivityKind, LocalizedText>{
  ActivityKind.numberColor: LocalizedText(
    'Цвета и числа',
    'Түстер мен сандар',
    'Colors & numbers',
  ),
  ActivityKind.freeColor: LocalizedText(
    'Мастерская цвета',
    'Түс шеберханасы',
    'Color studio',
  ),
  ActivityKind.maze: LocalizedText('Найди дорогу', 'Жолды тап', 'Find the way'),
  ActivityKind.guidedDraw: LocalizedText(
    'Рисуем по шагам',
    'Қадаммен сурет салу',
    'Draw step by step',
  ),
  ActivityKind.hiddenAnimals: LocalizedText(
    'Кто спрятался?',
    'Кім жасырынды?',
    'Who is hiding?',
  ),
};

const _chapterNames = <LocalizedText>[
  LocalizedText('Первое открытие', 'Алғашқы жаңалық', 'First discovery'),
  LocalizedText('Новые секреты', 'Жаңа құпиялар', 'New secrets'),
  LocalizedText('Смелое приключение', 'Батыл саяхат', 'Brave adventure'),
  LocalizedText('Большое мастерство', 'Үлкен шеберлік', 'Creative master'),
];

LocalizedText _title(ActivityKind kind, String scene, int chapter) {
  final animal = sceneNames[scene]!;
  final suffix = _chapterNames[chapter];
  if (kind == ActivityKind.maze) {
    return LocalizedText(
      'Дорога к друзьям · ${chapter + 1}',
      'Достарға апарар жол · ${chapter + 1}',
      'The road to friends · ${chapter + 1}',
    );
  }
  if (kind == ActivityKind.hiddenAnimals) {
    return LocalizedText(
      'Секреты фигур · ${chapter + 1}',
      'Пішіндер құпиясы · ${chapter + 1}',
      'Shape detectives · ${chapter + 1}',
    );
  }
  return LocalizedText(
    '${animal.ru}: ${suffix.ru.toLowerCase()}',
    '${animal.kk}: ${suffix.kk.toLowerCase()}',
    '${animal.en}: ${suffix.en.toLowerCase()}',
  );
}

LocalizedText _instruction(ActivityKind kind, int chapter) => switch (kind) {
  ActivityKind.numberColor => const LocalizedText(
    'Выбери цвет с нужным числом и коснись подходящей области. Прояви спрятанную картинку!',
    'Керекті саны бар түсті таңдап, сәйкес бөлікке түрт. Жасырын суретті аш!',
    'Pick a numbered color, then tap the matching area. Reveal the hidden picture!',
  ),
  ActivityKind.freeColor => const LocalizedText(
    'Выбери любимые цвета. Закрашивай области или рисуй кистью — здесь ты художник!',
    'Сүйікті түстеріңді таңда. Бөліктерді боя немесе қылқаламмен сурет сал — сен суретшісің!',
    'Choose your favorite colors. Fill the shapes or use the brush. You are the artist!',
  ),
  ActivityKind.maze => const LocalizedText(
    'Проведи друга по дороге к цели. Держись дорожки и обходи места ремонта.',
    'Досыңды жолмен мақсатқа жеткіз. Жолдан шықпай, жөндеу жерлерін айналып өт.',
    'Guide your friend along the road to the goal. Stay on the path and avoid roadworks.',
  ),
  ActivityKind.guidedDraw => const LocalizedText(
    'Обводи подсвеченные линии по порядку. Шаг за шагом получится твой рисунок!',
    'Жарқыраған сызықтарды ретімен бастыр. Қадам сайын өз суретің пайда болады!',
    'Trace the highlighted lines in order. Build your own drawing, one step at a time!',
  ),
  ActivityKind.hiddenAnimals => const LocalizedText(
    'Внимательно рассмотри фигуры. Найди спрятанных друзей и раскрась их части.',
    'Пішіндерге мұқият қара. Жасырын достарды тауып, олардың бөліктерін боя.',
    'Look closely at the shapes. Find the hidden friends and color their pieces.',
  ),
};

/// Four chapters per world. Engines consume both [LevelDefinition.variant] and
/// [LevelDefinition.difficulty]; these are 120 exercises over 12 art scenes,
/// not a claim of 120 separately illustrated pictures.
final levels = List<LevelDefinition>.unmodifiable([
  for (final world in worlds)
    for (var chapter = 0; chapter < 4; chapter++)
      for (final kind in ActivityKind.values)
        LevelDefinition(
          id: '${world.id}_${kind.name}_${chapter + 1}',
          worldId: world.id,
          kind: kind,
          scene: _worldScenes[world.id]![chapter],
          variant: chapter,
          difficulty: chapter + 1,
          title: _title(kind, _worldScenes[world.id]![chapter], chapter),
          instruction: _instruction(kind, chapter),
          order: chapter * ActivityKind.values.length + kind.index,
        ),
]);

final levelIndex = Map<String, LevelDefinition>.unmodifiable({
  for (final level in levels) level.id: level,
});

List<LevelDefinition> levelsForWorld(String worldId) =>
    levels.where((level) => level.worldId == worldId).toList(growable: false);

const achievements = <AchievementDefinition>[
  AchievementDefinition(
    id: 'first_step',
    title: LocalizedText(
      'Первое открытие',
      'Алғашқы жаңалық',
      'First discovery',
    ),
    description: LocalizedText(
      'Заверши первое задание',
      'Алғашқы тапсырманы аяқта',
      'Finish your first activity',
    ),
    symbol: 'spark',
    target: 1,
  ),
  AchievementDefinition(
    id: 'explorer',
    title: LocalizedText('Исследователь', 'Зерттеуші', 'Explorer'),
    description: LocalizedText(
      'Заверши 10 разных заданий',
      '10 түрлі тапсырманы аяқта',
      'Finish 10 different activities',
    ),
    symbol: 'compass',
    target: 10,
  ),
  AchievementDefinition(
    id: 'adventurer',
    title: LocalizedText(
      'Искатель приключений',
      'Шытырман іздеуші',
      'Adventurer',
    ),
    description: LocalizedText(
      'Заверши 30 разных заданий',
      '30 түрлі тапсырманы аяқта',
      'Finish 30 different activities',
    ),
    symbol: 'flag',
    target: 30,
  ),
  AchievementDefinition(
    id: 'master',
    title: LocalizedText(
      'Мастер открытий',
      'Жаңалық шебері',
      'Discovery master',
    ),
    description: LocalizedText(
      'Заверши 60 разных заданий',
      '60 түрлі тапсырманы аяқта',
      'Finish 60 different activities',
    ),
    symbol: 'crown',
    target: 60,
  ),
  AchievementDefinition(
    id: 'all_worlds',
    title: LocalizedText(
      'Всё возможно!',
      'Бәрі мүмкін!',
      'Anything is possible!',
    ),
    description: LocalizedText(
      'Заверши все 120 заданий',
      'Барлық 120 тапсырманы аяқта',
      'Finish all 120 activities',
    ),
    symbol: 'planet',
    target: 120,
  ),
  AchievementDefinition(
    id: 'number_first',
    title: LocalizedText(
      'Цветная находка',
      'Түрлі түсті олжа',
      'Color discovery',
    ),
    description: LocalizedText(
      'Открой картинку по числам',
      'Сандармен суретті аш',
      'Reveal a number picture',
    ),
    symbol: 'palette',
    target: 1,
    kind: ActivityKind.numberColor,
  ),
  AchievementDefinition(
    id: 'number_master',
    title: LocalizedText('Друзья чисел', 'Сандар достары', 'Number friends'),
    description: LocalizedText(
      'Пройди 12 раскрасок по числам',
      'Сандармен 12 суретті боя',
      'Complete 12 number pictures',
    ),
    symbol: 'palette',
    target: 12,
    kind: ActivityKind.numberColor,
  ),
  AchievementDefinition(
    id: 'artist_first',
    title: LocalizedText('Юный художник', 'Жас суретші', 'Young artist'),
    description: LocalizedText(
      'Создай первую раскраску',
      'Алғашқы боямаңды жаса',
      'Create your first coloring',
    ),
    symbol: 'brush',
    target: 1,
    kind: ActivityKind.freeColor,
  ),
  AchievementDefinition(
    id: 'artist_master',
    title: LocalizedText('Мир в цвете', 'Түрлі түсті әлем', 'A world of color'),
    description: LocalizedText(
      'Создай 12 раскрасок',
      '12 бояма жаса',
      'Create 12 colorings',
    ),
    symbol: 'brush',
    target: 12,
    kind: ActivityKind.freeColor,
  ),
  AchievementDefinition(
    id: 'maze_first',
    title: LocalizedText('Верная дорожка', 'Дұрыс жол', 'On the right track'),
    description: LocalizedText(
      'Найди первую дорогу',
      'Алғашқы жолды тап',
      'Find your first route',
    ),
    symbol: 'route',
    target: 1,
    kind: ActivityKind.maze,
  ),
  AchievementDefinition(
    id: 'maze_master',
    title: LocalizedText('Следопыт', 'Із кесуші', 'Trailblazer'),
    description: LocalizedText(
      'Пройди 12 лабиринтов',
      '12 лабиринттен өт',
      'Complete 12 mazes',
    ),
    symbol: 'route',
    target: 12,
    kind: ActivityKind.maze,
  ),
  AchievementDefinition(
    id: 'draw_first',
    title: LocalizedText('Волшебная линия', 'Сиқырлы сызық', 'Magic line'),
    description: LocalizedText(
      'Нарисуй первого друга по шагам',
      'Алғашқы досыңды қадаммен сал',
      'Draw your first friend step by step',
    ),
    symbol: 'pencil',
    target: 1,
    kind: ActivityKind.guidedDraw,
  ),
  AchievementDefinition(
    id: 'draw_master',
    title: LocalizedText('Уверенная рука', 'Сенімді қол', 'Steady hand'),
    description: LocalizedText(
      'Заверши 12 рисунков по шагам',
      'Қадаммен 12 сурет сал',
      'Complete 12 guided drawings',
    ),
    symbol: 'pencil',
    target: 12,
    kind: ActivityKind.guidedDraw,
  ),
  AchievementDefinition(
    id: 'detective_first',
    title: LocalizedText('Зоркий глаз', 'Қырағы көз', 'Eagle eyes'),
    description: LocalizedText(
      'Найди спрятанных друзей',
      'Жасырын достарды тап',
      'Find the hidden friends',
    ),
    symbol: 'search',
    target: 1,
    kind: ActivityKind.hiddenAnimals,
  ),
  AchievementDefinition(
    id: 'detective_master',
    title: LocalizedText('Главный сыщик', 'Бас іздеуші', 'Super detective'),
    description: LocalizedText(
      'Заверши 12 поисков в фигурах',
      'Пішіндерден 12 рет іздеп тап',
      'Complete 12 shape searches',
    ),
    symbol: 'search',
    target: 12,
    kind: ActivityKind.hiddenAnimals,
  ),
];

const _missionTargets = [1, 3, 6, 12, 24];
const _missionVerbs = <ActivityKind, LocalizedText>{
  ActivityKind.numberColor: LocalizedText(
    'Раскрась по числам',
    'Сандармен боя',
    'Color by number',
  ),
  ActivityKind.freeColor: LocalizedText(
    'Создай раскраски',
    'Боямалар жаса',
    'Create colorings',
  ),
  ActivityKind.maze: LocalizedText(
    'Найди дороги',
    'Жолдарды тап',
    'Find the routes',
  ),
  ActivityKind.guidedDraw: LocalizedText(
    'Нарисуй по шагам',
    'Қадаммен сурет сал',
    'Draw step by step',
  ),
  ActivityKind.hiddenAnimals: LocalizedText(
    'Раскрой секреты фигур',
    'Пішіндер құпиясын аш',
    'Discover shape secrets',
  ),
};

/// Permanent, cumulative missions: no deadlines, lost streaks or penalties.
final missions = List<MissionDefinition>.unmodifiable([
  for (final kind in ActivityKind.values)
    for (var i = 0; i < _missionTargets.length; i++)
      MissionDefinition(
        id: '${kind.name}_mission_${i + 1}',
        title: LocalizedText(
          '${_missionVerbs[kind]!.ru} · ${_missionTargets[i]}',
          '${_missionVerbs[kind]!.kk} · ${_missionTargets[i]}',
          '${_missionVerbs[kind]!.en} · ${_missionTargets[i]}',
        ),
        kind: kind,
        target: _missionTargets[i],
      ),
]);
