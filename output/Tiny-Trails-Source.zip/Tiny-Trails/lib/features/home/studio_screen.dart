import 'package:flutter/material.dart';

import '../../application/game_controller.dart';
import '../../core/strings.dart';
import '../../core/theme.dart';
import '../../data/catalog.dart';
import '../../domain/models.dart';
import '../../shared/art/scene_illustration.dart';
import '../../shared/widgets/common.dart';
import 'artwork_preview.dart';

class StudioScreen extends StatelessWidget {
  const StudioScreen({
    super.key,
    required this.controller,
    required this.onPlay,
  });
  final GameController controller;
  final ValueChanged<LevelDefinition> onPlay;

  String _t(String ru, String kk, String en) =>
      textFor(controller.language, ru, kk, en);

  @override
  Widget build(BuildContext context) {
    final creativeLevels = levels
        .where(
          (level) =>
              level.kind == ActivityKind.freeColor &&
              controller.isUnlocked(level),
        )
        .toList();
    final artworks = controller.artworks
        .where((art) => levelIndex.containsKey(art.levelId))
        .toList();
    return LayoutBuilder(
      builder: (context, box) {
        final wide = box.maxWidth > 650;
        final grid = SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: wide ? 4 : 2,
          mainAxisSpacing: 13,
          crossAxisSpacing: 13,
          childAspectRatio: .95,
        );
        return SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(wide ? 32 : 22, 18, wide ? 32 : 22, 30),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 1150),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _t(
                      'Твоя мастерская',
                      'Сенің шеберханаң',
                      'Your little studio',
                    ),
                    style: Theme.of(context).textTheme.headlineLarge,
                  ),
                  const SizedBox(height: 9),
                  Text(
                    _t(
                      'У каждого рисунка есть своя история.',
                      'Әр суреттің өз хикаясы бар.',
                      'Every picture has a story.',
                    ),
                    style: const TextStyle(color: AppColors.muted),
                  ),
                  SectionTitle(
                    _t('Альбом художника', 'Суретші альбомы', 'My art album'),
                    trailing: Text(
                      '${artworks.length}',
                      style: const TextStyle(color: AppColors.muted),
                    ),
                  ),
                  if (artworks.isEmpty)
                    _emptyAlbum()
                  else
                    GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: artworks.length,
                      gridDelegate: grid,
                      itemBuilder: (context, index) =>
                          _artworkCard(context, artworks[index]),
                    ),
                  SectionTitle(
                    _t(
                      'Добавим красок?',
                      'Түстер қосайық па?',
                      'Make something colorful',
                    ),
                  ),
                  GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: creativeLevels.length,
                    gridDelegate: grid,
                    itemBuilder: (context, index) {
                      final level = creativeLevels[index];
                      return SurfaceCard(
                        color: activityColor(ActivityKind.freeColor)
                            .withValues(alpha: .30),
                        padding: const EdgeInsets.all(10),
                        onTap: () => onPlay(level),
                        child: Column(
                          children: [
                            Expanded(
                              child: SceneIllustration(
                                scene: level.scene,
                                variant: level.variant,
                              ),
                            ),
                            Text(
                              sceneNames[level.scene]!.resolve(
                                controller.language,
                              ),
                              style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            const SizedBox(height: 5),
                            Text(
                              activityName(level.kind, controller.language),
                              style: const TextStyle(
                                color: AppColors.muted,
                                fontSize: 10,
                              ),
                            ),
                            const SizedBox(height: 5),
                          ],
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _emptyAlbum() => SurfaceCard(
    color: AppColors.peach.withValues(alpha: .35),
    child: Row(
      children: [
        const Icon(
          Icons.collections_outlined,
          size: 40,
          color: AppColors.green,
        ),
        const SizedBox(width: 18),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                _t(
                  'Здесь будут твои шедевры',
                  'Мұнда сенің туындыларың болады',
                  'A home for your masterpieces',
                ),
                style: const TextStyle(
                  fontWeight: FontWeight.w900,
                  fontSize: 16,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                _t(
                  'Закончи раскраску или рисунок — мы бережно сохраним его в альбоме.',
                  'Сурет не бояуды аяқта — оны альбомда сақтаймыз.',
                  'Finish a drawing or coloring page and we’ll keep it in your album.',
                ),
                style: const TextStyle(color: AppColors.muted, fontSize: 12),
              ),
            ],
          ),
        ),
      ],
    ),
  );

  Widget _artworkCard(BuildContext context, Artwork artwork) {
    final level = levelIndex[artwork.levelId]!;
    return SurfaceCard(
      padding: const EdgeInsets.all(10),
      border: true,
      onTap: () => _showArtwork(context, artwork, level),
      child: Column(
        children: [
          Expanded(
            child: ArtworkPreview(level: level, data: artwork.data),
          ),
          const SizedBox(height: 7),
          Text(
            sceneNames[level.scene]!.resolve(controller.language),
            style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13),
          ),
        ],
      ),
    );
  }

  void _showArtwork(
    BuildContext context,
    Artwork artwork,
    LevelDefinition level,
  ) {
    showDialog<void>(
      context: context,
      builder: (dialogContext) => Dialog(
        backgroundColor: AppColors.paper,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 650),
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          sceneNames[level.scene]!.resolve(controller.language),
                          style: Theme.of(context).textTheme.titleLarge,
                        ),
                      ),
                      IconButton(
                        onPressed: () => Navigator.of(dialogContext).pop(),
                        tooltip: _t('Закрыть', 'Жабу', 'Close'),
                        icon: const Icon(Icons.close_rounded),
                      ),
                    ],
                  ),
                  AspectRatio(
                    aspectRatio: 1,
                    child: ArtworkPreview(level: level, data: artwork.data),
                  ),
                  const SizedBox(height: 14),
                  FilledButton.icon(
                    onPressed: () {
                      Navigator.of(dialogContext).pop();
                      onPlay(level);
                    },
                    icon: const Icon(Icons.brush_outlined),
                    label: Text(
                      _t('Нарисовать ещё', 'Тағы сурет салу', 'Create another'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
