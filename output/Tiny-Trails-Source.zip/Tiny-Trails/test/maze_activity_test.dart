import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:tiny_trails/core/theme.dart';
import 'package:tiny_trails/domain/models.dart';
import 'package:tiny_trails/features/play/activity_config.dart';
import 'package:tiny_trails/features/play/engines/maze_engine.dart';
import 'package:tiny_trails/features/play/maze_activity.dart';

const _level = LevelDefinition(
  id: 'maze-test',
  worldId: 'ocean',
  kind: ActivityKind.maze,
  scene: 'whale',
  variant: 0,
  difficulty: 1,
  title: LocalizedText('Дорога', 'Жол', 'Road'),
  instruction: LocalizedText('Веди', 'Жүр', 'Go'),
  order: 0,
);

void main() {
  testWidgets('a persisted arrival recovers completion once after rebuilding', (
    tester,
  ) async {
    final network = MazeNetwork.generate(seed: 'ocean-0', difficulty: 1);
    final saved = {
      'version': 1,
      'type': 'maze',
      'route': network.routeToGoal(network.start),
    };
    var completions = 0;
    Widget app(String language) => MaterialApp(
      theme: buildTheme(),
      home: Scaffold(
        body: MazeActivity(
          config: ActivityConfig(
            level: _level,
            language: language,
            initialData: saved,
            onChanged: (_) {},
            onCompleted: (data) {
              completions++;
              expect(data['route'], saved['route']);
            },
            onFeedback: () {},
          ),
        ),
      ),
    );
    await tester.pumpWidget(app('ru'));
    expect(completions, 1);
    await tester.pumpWidget(app('kk'));
    await tester.pump();
    expect(completions, 1);
    expect(tester.takeException(), isNull);
  });
  testWidgets('dragging follows a road through the real gesture recognizer', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(320, 480);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final saves = <Map<String, dynamic>>[];
    await tester.pumpWidget(
      MaterialApp(
        theme: buildTheme(),
        home: Scaffold(
          body: MazeActivity(
            config: ActivityConfig(
              level: _level,
              language: 'en',
              onChanged: saves.add,
              onCompleted: (_) {},
              onFeedback: () {},
            ),
          ),
        ),
      ),
    );
    final maze = MazeNetwork.generate(seed: 'ocean-0', difficulty: 1);
    final next = maze.routeToGoal(maze.start)[1];
    final road = maze.roadBetween(maze.start, next)!;
    final map = tester.getRect(find.byKey(const ValueKey('maze-canvas')));
    Offset point(Offset p) => map.topLeft + p * (map.width / 400);
    final gesture = await tester.startGesture(point(maze.nodes[maze.start]));
    for (var i = 1; i <= 30; i++) {
      await gesture.moveTo(
        point(road.point(road.a == maze.start ? i / 30 : 1 - i / 30)),
      );
      await tester.pump();
    }
    await gesture.up();
    await tester.pump();
    expect(saves.last['route'], [maze.start, next]);
  });
  testWidgets(
    'maze tap route validates each junction and saves only legal progress',
    (tester) async {
      tester.view.physicalSize = const Size(390, 700);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      var completions = 0;
      final saves = <Map<String, dynamic>>[];
      await tester.pumpWidget(
        MaterialApp(
          theme: buildTheme(),
          home: Scaffold(
            body: SafeArea(
              child: MazeActivity(
                config: ActivityConfig(
                  level: _level,
                  language: 'ru',
                  onChanged: saves.add,
                  onCompleted: (_) => completions++,
                  onFeedback: () {},
                ),
              ),
            ),
          ),
        ),
      );
      final maze = MazeNetwork.generate(seed: 'ocean-0', difficulty: 1);
      final map = tester.getRect(find.byKey(const ValueKey('maze-canvas')));
      Offset point(int node) =>
          map.topLeft + maze.nodes[node] * (map.width / 400);
      await tester.tapAt(point(maze.goal));
      await tester.pump();
      expect(completions, 0);
      expect(saves, isEmpty);
      for (final node in maze.routeToGoal(maze.start).skip(1)) {
        await tester.tapAt(point(node));
        await tester.pump();
      }
      expect(completions, 1);
      expect(saves.last['route'], maze.routeToGoal(maze.start));
      expect(tester.takeException(), isNull);
    },
  );
  for (final size in const [
    Size(320, 430),
    Size(844, 310),
    Size(320, 480),
    Size(768, 1024),
    Size(1024, 768),
  ]) {
    testWidgets('maze adapts to $size without overflow', (tester) async {
      tester.view.physicalSize = size;
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      await tester.pumpWidget(
        MaterialApp(
          theme: buildTheme(),
          home: Scaffold(
            body: MazeActivity(
              config: ActivityConfig(
                level: _level,
                language: 'kk',
                onChanged: (_) {},
                onCompleted: (_) {},
                onFeedback: () {},
                showHint: true,
              ),
            ),
          ),
        ),
      );
      expect(tester.takeException(), isNull);
      expect(
        tester.getSize(find.byKey(const ValueKey('maze-canvas'))).shortestSide,
        greaterThanOrEqualTo(220),
      );
    });
  }
}
