import 'dart:async';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/services.dart';

/// Optional, local feedback. A missing audio device or speech engine must never
/// interrupt an activity or prevent progress from being saved.
///
/// The two original PCM assets are synthesized bell tones. Speech is delegated
/// to the platform's installed text-to-speech voices; no network API is used.
class FeedbackService {
  static const _speechChannel = MethodChannel('tiny_trails/speech');
  static const _tapInterval = Duration(milliseconds: 110);

  AudioPlayer? _tapPlayer;
  AudioPlayer? _successPlayer;
  DateTime? _lastTap;
  bool _disposed = false;
  int _speechRevision = 0;

  /// Reports whether the selected language has an installed offline voice.
  /// The written hint remains available when previews or devices lack TTS.
  Future<bool> isSpeechAvailable(String language) async {
    if (_disposed || !const {'ru', 'kk', 'en'}.contains(language)) return false;
    try {
      return await _speechChannel
              .invokeMethod<bool>('isAvailable', {'language': language})
              .timeout(const Duration(seconds: 5)) ??
          false;
    } on MissingPluginException {
      return false;
    } on PlatformException {
      return false;
    } on TimeoutException {
      return false;
    }
  }

  Future<void> success({required bool sound, required bool haptics}) async {
    if (_disposed) return;
    await Future.wait<void>([
      if (sound) _playSuccess(),
      if (haptics) _haptic(HapticFeedback.mediumImpact),
    ]);
  }

  Future<void> tap({required bool sound, required bool haptics}) async {
    if (_disposed) return;
    final now = DateTime.now();
    final previous = _lastTap;
    if (previous != null && now.difference(previous) < _tapInterval) return;
    _lastTap = now;
    await Future.wait<void>([
      if (sound) _playTap(),
      if (haptics) _haptic(HapticFeedback.selectionClick),
    ]);
  }

  /// Replaces any currently spoken hint through the platform implementation.
  /// Passing [enabled] as false also stops an already playing hint, so turning
  /// voice off in settings takes effect immediately on the next service call.
  Future<void> speak(
    String text,
    String language, {
    required bool enabled,
  }) async {
    if (_disposed) return;
    final revision = ++_speechRevision;
    try {
      await _speechChannel.invokeMethod<bool>('stop');
      if (!enabled || revision != _speechRevision || _disposed) return;
      final cleanedText = text.trim();
      if (cleanedText.isEmpty) return;
      final supportedLanguage = switch (language) {
        'kk' => 'kk',
        'en' => 'en',
        _ => 'ru',
      };
      await _speechChannel.invokeMethod<bool>('speak', {
        'text': cleanedText.substring(0, cleanedText.length.clamp(0, 1000)),
        'language': supportedLanguage,
      });
    } on MissingPluginException {
      // Web previews and devices without TTS keep the written hint available.
    } on PlatformException {
      // An unavailable voice is optional; gameplay remains fully usable.
    }
  }

  Future<void> _playTap() async {
    try {
      final player = _tapPlayer ??= AudioPlayer();
      await player.play(AssetSource('audio/tap.wav'), volume: .32);
    } on Exception {
      // Audio interruption, an unavailable device, or an unsupported preview.
    }
  }

  Future<void> _playSuccess() async {
    try {
      // Keep the short tap and success sounds separate, so rapid touches do not
      // cut off a completion melody.
      final player = _successPlayer ??= AudioPlayer();
      await player.play(AssetSource('audio/success.wav'), volume: .48);
    } on Exception {
      // Feedback is deliberately independent from the completion transaction.
    }
  }

  Future<void> _haptic(Future<void> Function() action) async {
    try {
      await action();
    } on MissingPluginException {
      // Some tablets and local previews do not provide haptic feedback.
    } on PlatformException {
      // Device-level haptics may be disabled or unavailable.
    }
  }

  /// Safe to call more than once. Pending native operations are allowed to
  /// finish cleanup without making the app's synchronous dispose hook async.
  void dispose() {
    if (_disposed) return;
    _disposed = true;
    _speechRevision++;
    final tapPlayer = _tapPlayer;
    final successPlayer = _successPlayer;
    _tapPlayer = null;
    _successPlayer = null;
    unawaited(_release(tapPlayer));
    unawaited(_release(successPlayer));
    unawaited(_stopSpeech());
  }

  Future<void> _release(AudioPlayer? player) async {
    if (player == null) return;
    try {
      await player.dispose();
    } on Exception {
      // A platform player can already have been released by an interruption.
    }
  }

  Future<void> _stopSpeech() async {
    try {
      await _speechChannel.invokeMethod<bool>('stop');
    } on MissingPluginException {
      // No native speech channel in previews.
    } on PlatformException {
      // The system speech service may already have shut down.
    }
  }
}
