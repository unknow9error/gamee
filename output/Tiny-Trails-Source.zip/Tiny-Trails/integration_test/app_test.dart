import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:tiny_trails/application/game_controller.dart';
import 'package:tiny_trails/data/catalog.dart';
import 'package:tiny_trails/data/progress_store.dart';
import 'package:tiny_trails/domain/models.dart';
import 'package:tiny_trails/features/play/engines/maze_engine.dart';
import 'package:tiny_trails/main.dart';
import 'package:tiny_trails/shared/art/art_scene.dart';

// Real platform storage, isolated from the child's ordinary saved game.
class _QaStore implements ProgressStore {
  final _platform = PreferencesProgressStore();
  @override
  Future<String?> read(String key) => _platform.read('integration.$key');
  @override
  Future<void> write(String key, String value) =>
      _platform.write('integration.$key', value);
}

Future<void> _tapArt(WidgetTester tester, String key, Offset point) async {
  final rect = tester.getRect(find.byKey(ValueKey(key)));
  await tester.tapAt(rect.topLeft + point * (rect.width / 400));
  await tester.pump();
}

Future<void> _next(WidgetTester tester) async {
  await tester.pumpAndSettle();
  await tester.tap(find.text('Дальше играть'));
  await tester.pumpAndSettle();
}

Offset _exposed(ArtScene scene, Set<String> ids) {
  for (var y = 4.0; y < 396; y += 3) {
    for (var x = 4.0; x < 396; x += 3) {
      final point = Offset(x, y);
      final hit = scene.regions.reversed
          .where((region) => region.path.contains(point))
          .firstOrNull;
      if (hit != null && ids.contains(hit.id)) return point;
    }
  }
  throw StateError('No exposed region for requested subject');
}

void main() {
  final binding = IntegrationTestWidgetsFlutterBinding.ensureInitialized();
  // Native runners can launch this target directly when host device discovery
  // is unavailable. The result comes from the test framework's real assertions.
  unawaited(
    binding.allTestsPassed.future.then((passed) async {
      await File('${Directory.systemTemp.path}/tiny-trails-qa-result.json')
          .writeAsString(
            jsonEncode({
              'passed': passed,
              'suite': 'five_activity_native',
              'platform': Platform.operatingSystem,
            }),
            flush: true,
          );
    }),
  );

  testWidgets(
    'all five real activities award once and persist through a new controller',
    (tester) async {
      final store = _QaStore();
      final controller = await GameController.load(store: store);
      await controller.resetProgress();
      await controller.setLanguage('ru');
      await controller.setReducedMotion(true);
      await controller.setSound(false);
      await controller.setHaptics(false);
      await controller.finishOnboarding();
      for (final kind in ActivityKind.values) {
        await controller.markTutorialSeen(kind);
      }
      await tester.pumpWidget(TinyTrailsApp(controller: controller));
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const Key('continue-adventure')));
      await tester.pumpAndSettle();

      final number = levels.first;
      final numberedArt = SceneFactory.create(
        number.scene,
        variant: number.variant,
        segmented: true,
      );
      for (final region in numberedArt.regions) {
        await tester.tap(
          find.byKey(
            ValueKey(
              'color-swatch-${numberPalette[region.number]!.toARGB32()}',
            ),
          ),
        );
        await tester.pump();
        await _tapArt(tester, 'color-canvas', region.labelPoint);
      }
      await tester.tap(find.byKey(const Key('color-finish')));
      await _next(tester);
      expect(controller.completedCount, 1);

      final free = levels.firstWhere(
        (level) => level.kind == ActivityKind.freeColor,
      );
      final freeArt = SceneFactory.create(free.scene, variant: free.variant);
      for (final region in freeArt.regions.take(3)) {
        await _tapArt(tester, 'color-canvas', region.labelPoint);
      }
      await tester.tap(find.byKey(const Key('color-finish')));
      await _next(tester);
      expect(controller.completedCount, 2);

      final mazeLevel = levels.firstWhere(
        (level) => level.kind == ActivityKind.maze,
      );
      final maze = MazeNetwork.generate(
        seed: '${mazeLevel.worldId}-${mazeLevel.variant}',
        difficulty: mazeLevel.difficulty,
      );
      for (final node in maze.routeToGoal(maze.start).skip(1)) {
        await _tapArt(tester, 'maze-canvas', maze.nodes[node]);
      }
      await _next(tester);
      expect(controller.completedCount, 3);

      final drawing = levels.firstWhere(
        (level) => level.kind == ActivityKind.guidedDraw,
      );
      final steps = drawingSteps(drawing.scene);
      for (var stepIndex = 0; stepIndex < steps.length; stepIndex++) {
        for (final metric in steps[stepIndex].path.computeMetrics()) {
          if (find
              .text('Шаг ${stepIndex + 1} из ${steps.length}')
              .evaluate()
              .isEmpty) {
            break;
          }
          if (metric.length < 2) continue;
          final rect = tester.getRect(find.byKey(const Key('drawing-canvas')));
          Offset screen(Offset point) =>
              rect.topLeft + point * (rect.width / 400);
          final gesture = await tester.startGesture(
            screen(metric.getTangentForOffset(0)!.position),
          );
          for (var distance = 2.0; distance < metric.length; distance += 3) {
            await gesture.moveTo(
              screen(metric.getTangentForOffset(distance)!.position),
            );
          }
          await gesture.up();
          await tester.pump();
        }
      }
      expect(find.text('Теперь добавь цвета!'), findsOneWidget);
      final drawingArt = SceneFactory.create(
        drawing.scene,
        variant: drawing.variant,
      );
      for (final region
          in drawingArt.regions
              .where((region) => region.group == 'subject')
              .take(2)) {
        await _tapArt(
          tester,
          'drawing-canvas',
          _exposed(drawingArt, {region.id}),
        );
      }
      await tester.tap(find.text('Готово!'));
      await _next(tester);
      expect(controller.completedCount, 4);

      final hidden = levels.firstWhere(
        (level) => level.kind == ActivityKind.hiddenAnimals,
      );
      final hiddenArt = SceneFactory.create(
        hidden.scene,
        variant: hidden.variant,
        geometric: true,
        worldId: hidden.worldId,
      );
      for (final animal in hiddenArt.hiddenAnimals) {
        await _tapArt(
          tester,
          'hidden-canvas',
          _exposed(hiddenArt, animal.regionIds.toSet()),
        );
      }
      for (final animal in hiddenArt.hiddenAnimals) {
        await tester.tap(find.byKey(ValueKey('hidden-target-${animal.id}')));
        await tester.pump();
        for (final regionId in animal.regionIds) {
          await _tapArt(
            tester,
            'hidden-canvas',
            _exposed(hiddenArt, {regionId}),
          );
        }
      }
      await tester.tap(find.byKey(const Key('hidden-finish')));
      await tester.pumpAndSettle();
      expect(controller.completedCount, 5);
      expect(controller.totalStars, 15);
      expect(controller.artworks.length, 4);
      expect(controller.isUnlocked(levels[5]), isTrue);
      await controller.flush();
      final restarted = await GameController.load(store: store);
      expect(restarted.completedCount, 5);
      expect(restarted.totalStars, 15);
      expect(restarted.artworks.length, 4);
      expect(
        restarted.earnedAchievements.map((achievement) => achievement.id),
        contains('first_step'),
      );
      final speech = await const MethodChannel('tiny_trails/speech')
          .invokeMethod<bool>('isAvailable', {'language': 'en'});
      expect(speech, isA<bool>());
      expect(tester.takeException(), isNull);
      await tester.pumpWidget(const SizedBox());
      controller.dispose();
      restarted.dispose();
    },
  );
}
