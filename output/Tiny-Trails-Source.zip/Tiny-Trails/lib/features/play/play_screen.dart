import 'dart:async';

import 'package:flutter/material.dart';

import '../../application/game_controller.dart';
import '../../core/feedback_service.dart';
import '../../core/strings.dart';
import '../../core/theme.dart';
import '../../data/catalog.dart';
import '../../domain/models.dart';
import '../../shared/widgets/activity_tutorial.dart';
import '../../shared/widgets/celebration.dart';
import '../../shared/widgets/common.dart';
import 'activity_config.dart';
import 'color_activity.dart';
import 'drawing_activity.dart';
import 'hidden_activity.dart';
import 'maze_activity.dart';

class PlayScreen extends StatefulWidget {
  const PlayScreen({super.key, required this.controller, required this.level});
  final GameController controller;
  final LevelDefinition level;
  @override
  State<PlayScreen> createState() => _PlayScreenState();
}

class _PlayScreenState extends State<PlayScreen> with WidgetsBindingObserver {
  final _feedback = FeedbackService();
  Map<String, dynamic>? _draft;
  Map<String, dynamic>? _pendingCompletion;
  Timer? _saveTimer;
  bool _hint = false;
  bool _completing = false;
  bool _checkingVoice = false;
  String? _saveError;
  GameController get _controller => widget.controller;
  String _t(String ru, String kk, String en) =>
      textFor(_controller.language, ru, kk, en);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _draft = _controller.draftFor(widget.level.id);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted && !_controller.hasSeenTutorial(widget.level.kind)) {
        unawaited(_showTutorial());
      }
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed) {
      unawaited(_save());
      unawaited(_feedback.speak('', _controller.language, enabled: false));
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _saveTimer?.cancel();
    // Route disposal runs while the widget tree is locked. Persist after that
    // phase so notifying the app controller cannot rebuild an unmounting tree.
    if (!_completing) {
      unawaited(Future<void>.microtask(_save));
    }
    _feedback.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    _saveTimer?.cancel();
    final data = _draft;
    if (data == null || _completing) return;
    try {
      await _controller.saveDraft(widget.level.id, data);
      if (mounted && _saveError != null && _pendingCompletion == null) {
        setState(() => _saveError = null);
      }
    } on Exception {
      if (mounted) {
        setState(
          () => _saveError = _t(
            'Не удалось сохранить рисунок. Попробуй ещё раз.',
            'Суретті сақтау мүмкін болмады. Қайта байқап көр.',
            'Could not save your drawing. Please try again.',
          ),
        );
      }
    }
  }

  void _changed(Map<String, dynamic> data) {
    _draft = data;
    _saveTimer?.cancel();
    _saveTimer = Timer(
      const Duration(milliseconds: 450),
      () => unawaited(_save()),
    );
  }

  Future<void> _showTutorial() async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: AppColors.paper,
      showDragHandle: true,
      builder: (sheetContext) => ActivityTutorial(
        kind: widget.level.kind,
        language: _controller.language,
        reducedMotion: _controller.reducedMotion,
        onDismiss: () => Navigator.of(sheetContext).pop(),
      ),
    );
    await _controller.markTutorialSeen(widget.level.kind);
  }

  Future<void> _listen() async {
    if (_checkingVoice) return;
    if (!_controller.voice) {
      _message(
        _t(
          'Голосовые подсказки можно включить в настройках.',
          'Дауыстық кеңестерді баптаулардан қосуға болады.',
          'You can turn on spoken hints in Settings.',
        ),
      );
      return;
    }
    _checkingVoice = true;
    final available = await _feedback.isSpeechAvailable(_controller.language);
    _checkingVoice = false;
    if (!mounted) return;
    if (!available) {
      _message(
        _t(
          'Для озвучки нужен установленный голос этого языка. Пока прочитай подсказку на экране.',
          'Дыбыстау үшін осы тілдің дауысы орнатылуы керек. Әзірге экрандағы кеңесті оқы.',
          'Install a voice for this language in your device settings. The written hint is always here.',
        ),
      );
      return;
    }
    await _feedback.speak(
      widget.level.instruction.resolve(_controller.language),
      _controller.language,
      enabled: true,
    );
  }

  void _message(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _completed(Map<String, dynamic> data) async {
    if (_completing) return;
    setState(() {
      _completing = true;
      _saveError = null;
    });
    _pendingCompletion = data;
    _saveTimer?.cancel();
    try {
      final reward = await _controller.completeLevel(
        widget.level,
        artwork: widget.level.kind == ActivityKind.maze ? null : data,
      );
      _pendingCompletion = null;
      await _feedback.success(
        sound: _controller.sound,
        haptics: _controller.haptics,
      );
      if (!mounted) return;
      await showCelebration(
        context,
        level: widget.level,
        reward: reward,
        language: _controller.language,
        reducedMotion: _controller.reducedMotion,
        onNext: _nextLevel,
        onHome: () => Navigator.of(context).popUntil((route) => route.isFirst),
      );
    } on Exception {
      if (mounted) {
        setState(() {
          _completing = false;
          _saveError = _t(
            'Результат пока не сохранён. Твоя работа здесь — попробуй ещё раз.',
            'Нәтиже әлі сақталмады. Жұмысың осында — қайта байқап көр.',
            'Your result hasn’t been saved yet. Your work is still here. Please try again.',
          );
        });
      }
    }
  }

  void _nextLevel() {
    final next = levels
        .where(
          (level) =>
              level.worldId == widget.level.worldId &&
              level.order > widget.level.order &&
              _controller.isUnlocked(level) &&
              !_controller.progress.containsKey(level.id),
        )
        .firstOrNull;
    if (next == null) {
      Navigator.of(context).pop();
    } else {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute<void>(
          builder: (_) => PlayScreen(controller: _controller, level: next),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: _controller,
    builder: (context, _) {
      final level = widget.level;
      final landscape = MediaQuery.sizeOf(context).aspectRatio > 1.35;
      final config = ActivityConfig(
        level: level,
        language: _controller.language,
        initialData: _draft,
        onChanged: _changed,
        onCompleted: (data) => unawaited(_completed(data)),
        onFeedback: () => unawaited(
          _feedback.tap(sound: _controller.sound, haptics: _controller.haptics),
        ),
        reducedMotion:
            _controller.reducedMotion ||
            MediaQuery.disableAnimationsOf(context),
        showHint: _hint,
      );
      final error = _saveError ?? _controller.persistenceError;
      return PopScope(
        canPop: !_completing,
        child: Scaffold(
          appBar: AppBar(
            toolbarHeight: 48,
            titleSpacing: 0,
            leading: IconButton(
              tooltip: _t('Сохранить и выйти', 'Сақтап шығу', 'Save and leave'),
              icon: const Icon(Icons.close_rounded),
              onPressed: _completing
                  ? null
                  : () async {
                      await _save();
                      if (context.mounted) {
                        Navigator.of(context).pop();
                      }
                    },
            ),
            title: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  activityName(level.kind, _controller.language),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                Text(
                  '${_t('УРОВЕНЬ', 'ДЕҢГЕЙ', 'LEVEL')} ${level.order + 1} / 20',
                  style: const TextStyle(
                    fontSize: 9,
                    color: AppColors.muted,
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
            actions: [
              IconButton(
                tooltip: _t(
                  'Послушать задание',
                  'Тапсырманы тыңдау',
                  'Listen to the task',
                ),
                onPressed: _listen,
                icon: const Icon(Icons.volume_up_outlined, size: 21),
              ),
              IconButton(
                tooltip: _t('Подсказка', 'Көмек', 'Hint'),
                onPressed: () => setState(() => _hint = !_hint),
                icon: Icon(
                  _hint
                      ? Icons.lightbulb_rounded
                      : Icons.lightbulb_outline_rounded,
                  size: 21,
                ),
              ),
              IconButton(
                tooltip: _t('Как играть', 'Қалай ойнау керек', 'How to play'),
                onPressed: _showTutorial,
                icon: const Icon(Icons.help_outline_rounded, size: 21),
              ),
            ],
          ),
          body: SafeArea(
            top: false,
            child: Column(
              children: [
                if (!landscape)
                  Padding(
                    padding: const EdgeInsets.fromLTRB(14, 1, 14, 7),
                    child: Row(
                      children: [
                        Container(
                          width: 29,
                          height: 29,
                          decoration: BoxDecoration(
                            color: activityColor(level.kind),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Icon(activityIcon(level.kind), size: 17),
                        ),
                        const SizedBox(width: 9),
                        Expanded(
                          child: Text(
                            level.instruction.resolve(_controller.language),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 11, height: 1.3),
                          ),
                        ),
                      ],
                    ),
                  ),
                if (error != null)
                  Material(
                    color: AppColors.yellow.withValues(alpha: .4),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              error,
                              maxLines: 3,
                              style: const TextStyle(fontSize: 11),
                            ),
                          ),
                          TextButton(
                            onPressed: () {
                              final pending = _pendingCompletion;
                              if (pending != null) {
                                unawaited(_completed(pending));
                              } else {
                                unawaited(_save());
                              }
                            },
                            child: Text(_t('Повторить', 'Қайталау', 'Retry')),
                          ),
                        ],
                      ),
                    ),
                  ),
                Expanded(
                  child: AbsorbPointer(
                    absorbing: _completing,
                    child: switch (level.kind) {
                      ActivityKind.numberColor ||
                      ActivityKind.freeColor => ColorActivity(config: config),
                      ActivityKind.maze => MazeActivity(config: config),
                      ActivityKind.guidedDraw => DrawingActivity(
                        config: config,
                      ),
                      ActivityKind.hiddenAnimals => HiddenActivity(
                        config: config,
                      ),
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}
