enum ActivityKind { numberColor, freeColor, maze, guidedDraw, hiddenAnimals }

class LocalizedText {
  const LocalizedText(this.ru, this.kk, this.en);
  final String ru;
  final String kk;
  final String en;
  String resolve(String language) => switch (language) {
    'kk' => kk,
    'en' => en,
    _ => ru,
  };
}

class WorldDefinition {
  const WorldDefinition({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.scene,
    required this.order,
  });
  final String id;
  final LocalizedText title;
  final LocalizedText subtitle;
  final int color;
  final String scene;
  final int order;
}

class LevelDefinition {
  const LevelDefinition({
    required this.id,
    required this.worldId,
    required this.kind,
    required this.scene,
    required this.variant,
    required this.difficulty,
    required this.title,
    required this.instruction,
    required this.order,
  });
  final String id;
  final String worldId;
  final ActivityKind kind;
  final String scene;
  final int variant;
  final int difficulty;
  final LocalizedText title;
  final LocalizedText instruction;
  final int order;
}

class LevelProgress {
  const LevelProgress({
    required this.stars,
    required this.completedAt,
    this.attempts = 1,
  });
  final int stars;
  final DateTime completedAt;
  final int attempts;
  Map<String, dynamic> toJson() => {
    'stars': stars,
    'completedAt': completedAt.toIso8601String(),
    'attempts': attempts,
  };
  factory LevelProgress.fromJson(Map<String, dynamic> json) => LevelProgress(
    stars: (json['stars'] as num).toInt().clamp(1, 3),
    completedAt: DateTime.parse(json['completedAt'] as String),
    attempts: (json['attempts'] as num?)?.toInt() ?? 1,
  );
}

class Artwork {
  const Artwork({
    required this.levelId,
    required this.createdAt,
    required this.data,
  });
  final String levelId;
  final DateTime createdAt;
  final Map<String, dynamic> data;
  Map<String, dynamic> toJson() => {
    'levelId': levelId,
    'createdAt': createdAt.toIso8601String(),
    'data': data,
  };
  factory Artwork.fromJson(Map<String, dynamic> json) => Artwork(
    levelId: json['levelId'] as String,
    createdAt: DateTime.parse(json['createdAt'] as String),
    data: Map<String, dynamic>.from(json['data'] as Map),
  );
}

class AchievementDefinition {
  const AchievementDefinition({
    required this.id,
    required this.title,
    required this.description,
    required this.symbol,
    required this.target,
    this.kind,
  });
  final String id;
  final LocalizedText title;
  final LocalizedText description;
  final String symbol;
  final int target;
  final ActivityKind? kind;
}

class MissionDefinition {
  const MissionDefinition({
    required this.id,
    required this.title,
    required this.kind,
    required this.target,
  });
  final String id;
  final LocalizedText title;
  final ActivityKind kind;
  final int target;
}

class CompletionReward {
  const CompletionReward({
    required this.stars,
    required this.newAchievements,
    required this.firstCompletion,
  });
  final int stars;
  final List<AchievementDefinition> newAchievements;
  final bool firstCompletion;
}
