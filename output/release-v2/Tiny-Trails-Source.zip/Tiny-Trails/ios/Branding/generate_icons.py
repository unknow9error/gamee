"""Recreate the original Tiny Trails vector-style fox mark with Pillow.

The app has no runtime dependency on Pillow. Artwork is authored here as paths,
not sourced from the workbook photographs or a stock icon set.
"""

import json
from pathlib import Path

from PIL import Image, ImageDraw


ROOT = Path(__file__).resolve().parents[2]
PAPER = "#FFFBF3"
INK = "#293F39"
GREEN = "#467A5B"
ORANGE = "#EFA66A"
CREAM = "#FFF3D9"


def curve(start, *segments):
    points = [start]
    for segment in segments:
        a = points[-1]
        if len(segment) == 2:
            points.append(segment)
            continue
        b, c, d = segment
        for sample in range(1, 25):
            t = sample / 24
            u = 1 - t
            points.append((u**3*a[0] + 3*u*u*t*b[0] + 3*u*t*t*c[0] + t**3*d[0],
                           u**3*a[1] + 3*u*u*t*b[1] + 3*u*t*t*c[1] + t**3*d[1]))
    return points


def render(size=1024, background=True):
    image = Image.new("RGBA", (1024, 1024), PAPER if background else (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)
    if background:
        draw.ellipse((127, 133, 897, 903), fill="#DAEC9C")
        draw.ellipse((154, 159, 870, 875), fill=GREEN)
    draw.polygon(curve((267, 253), ((331, 263), (365, 300), (409, 360)),
                       ((467, 342), (550, 340), (596, 360)),
                       ((645, 292), (694, 257), (749, 253)), (743, 533),
                       ((733, 648), (638, 747), (506, 785)),
                       ((365, 749), (275, 645), (267, 533))), fill=ORANGE)
    draw.polygon(curve((305, 306), ((344, 321), (365, 345), (387, 375)), (306, 435)), fill="#D88056")
    draw.polygon(curve((711, 306), ((675, 323), (650, 349), (628, 375)), (710, 435)), fill="#D88056")
    draw.polygon(curve((273, 489), ((351, 458), (442, 521), (506, 610)),
                       ((574, 521), (668, 457), (739, 489)),
                       ((729, 625), (631, 715), (506, 755)),
                       ((380, 715), (283, 621), (273, 489))), fill=CREAM)
    draw.ellipse((364, 478, 398, 524), fill=INK)
    draw.ellipse((614, 478, 648, 524), fill=INK)
    draw.ellipse((371, 482, 381, 494), fill="white")
    draw.ellipse((621, 482, 631, 494), fill="white")
    draw.ellipse((329, 552, 391, 579), fill="#F0C1A5")
    draw.ellipse((620, 552, 682, 579), fill="#F0C1A5")
    draw.polygon(curve((471, 609), ((484, 591), (526, 591), (540, 609)),
                       ((541, 627), (521, 645), (506, 648)),
                       ((490, 646), (472, 628), (471, 609))), fill=INK)
    draw.line(curve((506, 644), (506, 666), ((495, 688), (472, 690), (462, 675))), fill=INK, width=9)
    draw.line(curve((506, 666), ((518, 689), (541, 688), (551, 675))), fill=INK, width=9)
    # A little drawing pencil, angled beside the fox's right cheek.
    draw.polygon([(688, 729), (748, 750), (841, 489), (781, 467)], fill="#F8DC82")
    draw.polygon([(688, 729), (689, 799), (748, 750)], fill=CREAM)
    draw.polygon([(689, 799), (713, 779), (689, 767)], fill=INK)
    draw.polygon([(781, 467), (841, 489), (852, 459), (792, 437)], fill="#E0DAF6")
    draw.line([(718, 739), (810, 480)], fill="#D9A94F", width=7)
    # Sparkles balance the silhouette at small sizes.
    for x, y, radius in [(214, 416, 31), (785, 301, 28), (265, 730, 18)]:
        draw.polygon([(x, y-radius), (x+radius*.28, y-radius*.28), (x+radius, y),
                      (x+radius*.28, y+radius*.28), (x, y+radius),
                      (x-radius*.28, y+radius*.28), (x-radius, y),
                      (x-radius*.28, y-radius*.28)], fill="#F8DC82")
    return image.resize((size, size), Image.Resampling.LANCZOS)


def main():
    icon = render()
    app_icons = ROOT / "ios/Runner/Assets.xcassets/AppIcon.appiconset"
    manifest = json.loads((app_icons / "Contents.json").read_text())
    for item in manifest["images"]:
        logical_size = float(item["size"].split("x")[0])
        scale = float(item["scale"].removesuffix("x"))
        pixels = round(logical_size * scale)
        icon.resize((pixels, pixels), Image.Resampling.LANCZOS).convert("RGB").save(app_icons / item["filename"])
    for density, pixels in {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}.items():
        icon.resize((pixels, pixels), Image.Resampling.LANCZOS).save(ROOT / f"android/app/src/main/res/mipmap-{density}/ic_launcher.png")
    splash = ROOT / "ios/Runner/Assets.xcassets/LaunchImage.imageset"
    for scale, filename in [(1, "LaunchImage.png"), (2, "LaunchImage@2x.png"), (3, "LaunchImage@3x.png")]:
        canvas = Image.new("RGBA", (168*scale, 185*scale), (0, 0, 0, 0))
        mark = render(168*scale, background=False)
        canvas.alpha_composite(mark, (0, 8*scale))
        canvas.save(splash / filename)


if __name__ == "__main__":
    main()
