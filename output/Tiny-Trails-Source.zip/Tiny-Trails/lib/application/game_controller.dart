import 'dart:convert';

import 'package:flutter/foundation.dart';

import '../data/catalog.dart';
import '../data/artwork_codec.dart';
import '../data/progress_store.dart';
import '../domain/artwork_limits.dart';
import '../domain/models.dart';

class GameController extends ChangeNotifier {
  GameController._(this._store, this._now) {
    // A backup must describe a previously committed state, including the
    // initial empty state, never the first still-uncommitted completion.
    _lastGoodSnapshot = _snapshot();
  }

  factory GameController.forTest({
    ProgressStore? store,
    DateTime Function()? now,
  }) => GameController._(store ?? MemoryProgressStore(), now ?? DateTime.now);

  factory GameController.inMemory() => GameController.forTest();

  static const storageKey = 'tiny_trails.state.v1';
  static const backupKey = 'tiny_trails.state.backup.v1';
  static const _schemaVersion = 1;
  static const _maxSnapshotLength = 16 * 1024 * 1024;

  final ProgressStore _store;
  final DateTime Function() _now;
  Future<void> _writeQueue = Future<void>.value();
  Future<void> _completionQueue = Future<void>.value();
  _PendingWrite? _pendingWrite;
  bool _writing = false;
  String? _lastGoodSnapshot;
  bool _unsupportedVersion = false;
  bool _disposed = false;
  int _revision = 0;
  int _persistedRevision = 0;
  int _resetGeneration = 0;
  int? _backupResetRevision;

  String _language = 'ru';
  bool _sound = true;
  bool _voice = true;
  bool _haptics = true;
  bool _reducedMotion = false;
  bool _onboardingComplete = false;
  _PersistenceIssue? _persistenceIssue;
  final Map<String, LevelProgress> _progress = {};
  final Map<String, Map<String, dynamic>> _drafts = {};
  final List<Artwork> _artworks = [];
  final Set<ActivityKind> _seenTutorials = {};

  String get language => _language;
  bool get sound => _sound;
  bool get voice => _voice;
  bool get haptics => _haptics;
  bool get reducedMotion => _reducedMotion;
  bool get onboardingComplete => _onboardingComplete;
  String? get persistenceError => switch (_persistenceIssue) {
    null => null,
    _PersistenceIssue.newerVersion => const LocalizedText(
      'Это сохранение создано в новой версии приложения.',
      'Бұл сақтау қолданбаның жаңа нұсқасында жасалған.',
      'This save was created by a newer app version.',
    ).resolve(_language),
    _PersistenceIssue.recoveredBackup => const LocalizedText(
      'Прогресс восстановлен из резервной копии.',
      'Прогресс сақтық көшірмеден қалпына келтірілді.',
      'Progress was restored from the backup.',
    ).resolve(_language),
    _PersistenceIssue.loadFailed => const LocalizedText(
      'Не удалось прочитать сохранение на этом устройстве.',
      'Бұл құрылғыдағы сақталған деректер оқылмады.',
      'Saved progress could not be read on this device.',
    ).resolve(_language),
    _PersistenceIssue.partialRecovery => const LocalizedText(
      'Сохранение восстановлено. Некоторые повреждённые записи пропущены.',
      'Сақталған деректер қалпына келтірілді. Зақымданған жазбалар өткізілді.',
      'Progress was recovered. Some damaged entries were skipped.',
    ).resolve(_language),
    _PersistenceIssue.saveFailed => const LocalizedText(
      'Не удалось сохранить прогресс. Проверьте свободное место на устройстве.',
      'Прогресс сақталмады. Құрылғыдағы бос орынды тексеріңіз.',
      'Progress could not be saved. Check the available space on this device.',
    ).resolve(_language),
    _PersistenceIssue.fullStorage => const LocalizedText(
      'Хранилище рисунков заполнено. Новые изменения пока доступны только в этом сеансе.',
      'Суреттер қоймасы толды. Жаңа өзгерістер әзірше осы сеанста ғана сақталады.',
      'Artwork storage is full. New changes are kept in this session only.',
    ).resolve(_language),
  };
  Map<String, LevelProgress> get progress => Map.unmodifiable(_progress);
  Map<String, Map<String, dynamic>> get drafts => Map.unmodifiable({
    for (final entry in _drafts.entries) entry.key: _copyData(entry.value),
  });
  List<Artwork> get artworks => List.unmodifiable(
    _artworks.map(
      (artwork) => Artwork(
        levelId: artwork.levelId,
        createdAt: artwork.createdAt,
        data: _copyData(artwork.data),
      ),
    ),
  );
  int get totalStars =>
      _progress.values.fold(0, (total, item) => total + item.stars);
  int get completedCount => _progress.length;
  List<AchievementDefinition> get earnedAchievements => achievements
      .where(
        (achievement) => achievementProgress(achievement) >= achievement.target,
      )
      .toList(growable: false);
  LevelDefinition get nextLevel => levels.firstWhere(
    (level) => !_progress.containsKey(level.id) && isUnlocked(level),
    orElse: () => levels.first,
  );

  /// Reading never prints payloads, platform exceptions or personal data.
  static Future<GameController> load({
    ProgressStore? store,
    DateTime Function()? now,
  }) async {
    final controller = GameController._(
      store ?? PreferencesProgressStore(),
      now ?? DateTime.now,
    );
    String? primary;
    try {
      primary = await controller._store.read(storageKey);
      if (primary == null) {
        final backup = await controller._store.read(backupKey);
        if (backup == null) return controller;
        controller._restore(backup);
        controller._lastGoodSnapshot = controller._snapshot();
        controller._persistenceIssue = _PersistenceIssue.recoveredBackup;
        return controller;
      }
      controller._restore(primary);
      controller._lastGoodSnapshot = controller._snapshot();
    } on _UnsupportedVersion {
      // Keep the unknown version intact instead of silently destroying it.
      controller._unsupportedVersion = true;
      controller._persistenceIssue = _PersistenceIssue.newerVersion;
    } catch (_) {
      try {
        final backup = await controller._store.read(backupKey);
        if (backup != null) {
          controller._restore(backup);
          controller._lastGoodSnapshot = controller._snapshot();
          controller._persistenceIssue = _PersistenceIssue.recoveredBackup;
        } else {
          controller._persistenceIssue = _PersistenceIssue.loadFailed;
        }
      } on _UnsupportedVersion {
        controller._unsupportedVersion = true;
        controller._persistenceIssue = _PersistenceIssue.newerVersion;
      } catch (_) {
        controller._persistenceIssue = _PersistenceIssue.loadFailed;
      }
    }
    return controller;
  }

  Future<void> setLanguage(String value) {
    if (!const {'ru', 'kk', 'en'}.contains(value)) {
      throw ArgumentError.value(value, 'value', 'Unsupported language');
    }
    _language = value;
    return _changed();
  }

  Future<void> setSound(bool value) {
    _sound = value;
    return _changed();
  }

  Future<void> setVoice(bool value) {
    _voice = value;
    return _changed();
  }

  Future<void> setHaptics(bool value) {
    _haptics = value;
    return _changed();
  }

  Future<void> setReducedMotion(bool value) {
    _reducedMotion = value;
    return _changed();
  }

  Future<void> finishOnboarding() {
    _onboardingComplete = true;
    return _changed();
  }

  bool hasSeenTutorial(ActivityKind kind) => _seenTutorials.contains(kind);

  Future<void> markTutorialSeen(ActivityKind kind) {
    _seenTutorials.add(kind);
    return _changed();
  }

  Map<String, dynamic>? draftFor(String levelId) {
    final draft = _drafts[levelId];
    return draft == null ? null : _copyData(draft);
  }

  Future<void> saveDraft(String levelId, Map<String, dynamic> data) {
    _requireLevel(levelId);
    final encoded = _validatedArtwork(data);
    _drafts[levelId] = encoded;
    return _changed();
  }

  Future<CompletionReward> completeLevel(
    LevelDefinition level, {
    int stars = 3,
    Map<String, dynamic>? artwork,
  }) {
    final requestedGeneration = _resetGeneration;
    final operation = _completionQueue.then(
      (_) => _completeLevelTransaction(
        level,
        stars: stars,
        artwork: artwork,
        requestedGeneration: requestedGeneration,
      ),
    );
    // One failed completion must not poison the next explicit retry.
    _completionQueue = operation.then<void>((_) {}, onError: (Object _) {});
    return operation;
  }

  Future<CompletionReward> _completeLevelTransaction(
    LevelDefinition level, {
    required int stars,
    required Map<String, dynamic>? artwork,
    required int requestedGeneration,
  }) async {
    if (requestedGeneration != _resetGeneration) {
      throw CompletionPersistenceException(
        const LocalizedText(
          'Прогресс был сброшен. Открой задание ещё раз.',
          'Прогресс тазартылды. Тапсырманы қайта аш.',
          'Progress was reset. Open the activity again.',
        ).resolve(_language),
      );
    }
    final canonical = _requireLevel(level.id);
    if (!isUnlocked(canonical)) throw StateError('Level is locked');
    // Validate before changing anything: a malformed drawing cannot partly
    // award a level or erase a valid draft.
    final safeArtwork = artwork == null ? null : _validatedArtwork(artwork);
    final previous = _progress[level.id];
    final previousDraft = _drafts[level.id];
    final previousArtworkIndex = _artworks.indexWhere(
      (item) => item.levelId == level.id,
    );
    final previousArtwork = previousArtworkIndex < 0
        ? null
        : _artworks[previousArtworkIndex];
    final generation = _resetGeneration;
    final earnedBefore = earnedAchievements.map((item) => item.id).toSet();
    final awardedStars = stars.clamp(1, 3);
    final bestStars = previous == null
        ? awardedStars
        : (awardedStars > previous.stars ? awardedStars : previous.stars);
    final now = _now();
    _progress[level.id] = LevelProgress(
      stars: bestStars,
      completedAt: previous?.completedAt ?? now,
      attempts: (previous?.attempts ?? 0) + 1,
    );
    _drafts.remove(level.id);
    if (safeArtwork != null) {
      _artworks.removeWhere((item) => item.levelId == level.id);
      _artworks.insert(
        0,
        Artwork(levelId: level.id, createdAt: now, data: safeArtwork),
      );
    }
    final newlyEarned = earnedAchievements
        .where((item) => !earnedBefore.contains(item.id))
        .toList(growable: false);
    final completionRevision = _revision + 1;
    await _changed();
    if (generation != _resetGeneration) {
      throw CompletionPersistenceException(
        const LocalizedText(
          'Прогресс был сброшен. Открой задание ещё раз.',
          'Прогресс тазартылды. Тапсырманы қайта аш.',
          'Progress was reset. Open the activity again.',
        ).resolve(_language),
      );
    }
    if (_persistedRevision < completionRevision) {
      // Only this transaction is rolled back; concurrent settings and drafts
      // for other levels remain intact. Keep the finished work for a retry.
      if (previous == null) {
        _progress.remove(level.id);
      } else {
        _progress[level.id] = previous;
      }
      _artworks.removeWhere((item) => item.levelId == level.id);
      if (previousArtwork != null) {
        _artworks.insert(
          previousArtworkIndex.clamp(0, _artworks.length),
          previousArtwork,
        );
      }
      if (safeArtwork != null) {
        _drafts.putIfAbsent(level.id, () => safeArtwork);
      } else if (previousDraft != null) {
        _drafts.putIfAbsent(level.id, () => previousDraft);
      }
      final issue = _persistenceIssue ?? _PersistenceIssue.saveFailed;
      // A rollback snapshot contains the retained draft, never an award.
      await _changed();
      _persistenceIssue ??= issue;
      _notify();
      throw CompletionPersistenceException(persistenceError!);
    }
    return CompletionReward(
      stars: bestStars,
      newAchievements: newlyEarned,
      firstCompletion: previous == null,
    );
  }

  bool isUnlocked(LevelDefinition level) {
    final canonical = levelIndex[level.id];
    if (canonical == null) return false;
    final chapter = canonical.order ~/ ActivityKind.values.length;
    if (chapter == 0) return true;
    final previousChapter = levels.where(
      (candidate) =>
          candidate.worldId == canonical.worldId &&
          candidate.order ~/ ActivityKind.values.length == chapter - 1,
    );
    return previousChapter
                .where((candidate) => _progress.containsKey(candidate.id))
                .length >=
            3 &&
        isUnlocked(previousChapter.first);
  }

  int completedForKind(ActivityKind kind) =>
      _progress.keys.where((id) => levelIndex[id]?.kind == kind).length;

  int achievementProgress(AchievementDefinition achievement) =>
      achievement.kind == null
      ? completedCount
      : completedForKind(achievement.kind!);

  int missionProgress(MissionDefinition mission) =>
      completedForKind(mission.kind).clamp(0, mission.target);

  /// An explicitly confirmed reset affects learning data, never preferences.
  Future<void> resetProgress() {
    _resetGeneration++;
    _progress.clear();
    _drafts.clear();
    _artworks.clear();
    _seenTutorials.clear();
    _unsupportedVersion = false;
    return _changed(resetBackup: true);
  }

  /// Lets lifecycle handlers and tests wait for all preceding writes.
  Future<void> flush() => _writeQueue;

  /// Retries the current draft/settings state, without inventing completion.
  Future<void> retryPersistence() async {
    final revision = _revision + 1;
    await _changed();
    if (_persistedRevision < revision) {
      throw CompletionPersistenceException(
        persistenceError ??
            const LocalizedText(
              'Не удалось сохранить прогресс.',
              'Прогресс сақталмады.',
              'Progress could not be saved.',
            ).resolve(_language),
      );
    }
  }

  LevelDefinition _requireLevel(String id) =>
      levelIndex[id] ??
      (throw ArgumentError.value(id, 'levelId', 'Unknown level'));

  Future<void> _changed({bool resetBackup = false}) {
    final revision = ++_revision;
    if (resetBackup) _backupResetRevision = revision;
    if (_unsupportedVersion) {
      _notify();
      return Future.value();
    }
    final snapshot = _snapshot();
    if (snapshot.length > _maxSnapshotLength) {
      _persistenceIssue = _PersistenceIssue.fullStorage;
      _notify();
      return _writeQueue;
    }
    // Keep only the newest waiting snapshot, rather than retaining a full
    // gallery for every brush stroke while the platform finishes a write.
    _pendingWrite = _PendingWrite(
      snapshot,
      revision,
      resetBackup || (_pendingWrite?.resetBackup ?? false),
    );
    if (!_writing) {
      _writing = true;
      _writeQueue = _drainWrites();
    }
    _notify();
    return _writeQueue;
  }

  Future<void> _drainWrites() async {
    while (_pendingWrite != null) {
      final write = _pendingWrite!;
      _pendingWrite = null;
      try {
        final shouldResetBackup =
            write.resetBackup ||
            (_backupResetRevision != null &&
                write.revision >= _backupResetRevision!);
        await _store.write(
          backupKey,
          shouldResetBackup
              ? write.snapshot
              : (_lastGoodSnapshot ?? write.snapshot),
        );
        await _store.write(storageKey, write.snapshot);
        _lastGoodSnapshot = write.snapshot;
        _persistedRevision = write.revision;
        if (_backupResetRevision != null &&
            write.revision >= _backupResetRevision!) {
          _backupResetRevision = null;
        }
        if (write.revision == _revision && _persistenceIssue != null) {
          _persistenceIssue = null;
          _notify();
        }
      } catch (_) {
        if (write.revision == _revision) {
          _persistenceIssue = _PersistenceIssue.saveFailed;
          _notify();
        }
      }
    }
    _writing = false;
  }

  String _snapshot() => jsonEncode({
    'version': _schemaVersion,
    'settings': {
      'language': _language,
      'sound': _sound,
      'voice': _voice,
      'haptics': _haptics,
      'reducedMotion': _reducedMotion,
      'onboardingComplete': _onboardingComplete,
    },
    'progress': {
      for (final entry in _progress.entries) entry.key: entry.value.toJson(),
    },
    'drafts': _drafts,
    'artworks': _artworks.map((item) => item.toJson()).toList(),
    'seenTutorials': _seenTutorials.map((kind) => kind.name).toList(),
  });

  void _restore(String encoded) {
    if (encoded.length > _maxSnapshotLength) {
      throw const FormatException('Snapshot exceeds limit');
    }
    final decoded = jsonDecode(encoded);
    if (decoded is! Map<String, dynamic>) {
      throw const FormatException('Invalid snapshot');
    }
    final version = decoded['version'];
    if (version is num && version.isFinite && version > _schemaVersion) {
      throw _UnsupportedVersion();
    }
    if (version is! int || version != _schemaVersion) {
      throw const FormatException('Invalid snapshot version');
    }
    final settings = decoded['settings'];
    if (settings is! Map<String, dynamic>) {
      throw const FormatException('Missing settings');
    }
    final restoredProgress = <String, LevelProgress>{};
    final restoredDrafts = <String, Map<String, dynamic>>{};
    final restoredArtworks = <Artwork>[];
    var recovered = false;
    final storedProgress = decoded['progress'];
    if (storedProgress is Map<String, dynamic>) {
      for (final entry in storedProgress.entries.take(levels.length)) {
        if (!levelIndex.containsKey(entry.key)) continue;
        try {
          final value = Map<String, dynamic>.from(entry.value as Map);
          final stars = value['stars'];
          final attempts = value['attempts'] ?? 1;
          if (stars is! int ||
              stars < 1 ||
              stars > 3 ||
              attempts is! int ||
              attempts < 1 ||
              attempts > 1000000) {
            throw const FormatException('Invalid progress');
          }
          restoredProgress[entry.key] = LevelProgress.fromJson(value);
        } catch (_) {
          recovered = true;
        }
      }
    } else if (storedProgress != null) {
      recovered = true;
    }
    final storedDrafts = decoded['drafts'];
    if (storedDrafts is Map<String, dynamic>) {
      for (final entry in storedDrafts.entries.take(levels.length)) {
        if (!levelIndex.containsKey(entry.key)) continue;
        try {
          restoredDrafts[entry.key] = _validatedArtwork(
            Map<String, dynamic>.from(entry.value as Map),
          );
        } catch (_) {
          recovered = true;
        }
      }
    } else if (storedDrafts != null) {
      recovered = true;
    }
    final storedArtworks = decoded['artworks'];
    if (storedArtworks is List) {
      final seenIds = <String>{};
      for (final value in storedArtworks.take(levels.length)) {
        try {
          final item = Artwork.fromJson(
            Map<String, dynamic>.from(value as Map),
          );
          if (!levelIndex.containsKey(item.levelId) ||
              !seenIds.add(item.levelId)) {
            continue;
          }
          restoredArtworks.add(
            Artwork(
              levelId: item.levelId,
              createdAt: item.createdAt,
              data: _validatedArtwork(item.data),
            ),
          );
        } catch (_) {
          recovered = true;
        }
      }
    } else if (storedArtworks != null) {
      recovered = true;
    }
    // Commit only after parsing the outer document. Broken entries are isolated.
    _language = const {'ru', 'kk', 'en'}.contains(settings['language'])
        ? settings['language'] as String
        : 'ru';
    _sound = settings['sound'] is bool ? settings['sound'] as bool : true;
    _voice = settings['voice'] is bool ? settings['voice'] as bool : true;
    _haptics = settings['haptics'] is bool ? settings['haptics'] as bool : true;
    _reducedMotion = settings['reducedMotion'] is bool
        ? settings['reducedMotion'] as bool
        : false;
    _onboardingComplete = settings['onboardingComplete'] is bool
        ? settings['onboardingComplete'] as bool
        : false;
    _progress
      ..clear()
      ..addAll(restoredProgress);
    _drafts
      ..clear()
      ..addAll(restoredDrafts);
    _artworks
      ..clear()
      ..addAll(restoredArtworks);
    final seenTutorials = decoded['seenTutorials'];
    _seenTutorials.clear();
    if (seenTutorials is List) {
      _seenTutorials.addAll(
        ActivityKind.values.where((kind) => seenTutorials.contains(kind.name)),
      );
    }
    if (recovered) _persistenceIssue = _PersistenceIssue.partialRecovery;
  }

  static Map<String, dynamic> _copyData(Map<String, dynamic> data) =>
      Map<String, dynamic>.from(jsonDecode(jsonEncode(data)) as Map);

  static Map<String, dynamic> _validatedArtwork(Map<String, dynamic> data) {
    var nodes = 0;
    var nodeLimit = 2000000;
    void validate(Object? value, int depth) {
      if (++nodes > nodeLimit || depth > 12) {
        throw const FormatException('Artwork is too complex');
      }
      if (value == null || value is bool || value is String) return;
      if (value is num && value.isFinite) return;
      if (value is List) {
        for (final item in value) {
          validate(item, depth + 1);
        }
        return;
      }
      if (value is Map && value.keys.every((key) => key is String)) {
        for (final item in value.values) {
          validate(item, depth + 1);
        }
        return;
      }
      throw const FormatException('Artwork must contain finite JSON values');
    }

    validate(data, 0);
    final compact = compactBrushArtwork(data);
    nodes = 0;
    nodeLimit = ArtworkLimits.maxArtworkNodes;
    validate(compact, 0);
    final encoded = jsonEncode(compact);
    if (utf8.encode(encoded).length > ArtworkLimits.maxArtworkBytes) {
      throw const FormatException('Artwork exceeds storage limit');
    }
    return Map<String, dynamic>.from(jsonDecode(encoded) as Map);
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }
}

class _UnsupportedVersion implements Exception {}

/// Completion was not committed. The game keeps the work and can retry the
/// same call; no stars, artwork replacement or achievement is retained.
class CompletionPersistenceException implements Exception {
  const CompletionPersistenceException(this.message);
  final String message;
  @override
  String toString() => message;
}

enum _PersistenceIssue {
  newerVersion,
  recoveredBackup,
  loadFailed,
  partialRecovery,
  saveFailed,
  fullStorage,
}

class _PendingWrite {
  const _PendingWrite(this.snapshot, this.revision, this.resetBackup);
  final String snapshot;
  final int revision;
  final bool resetBackup;
}
