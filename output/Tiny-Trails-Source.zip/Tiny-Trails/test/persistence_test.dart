import 'dart:async';
import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:tiny_trails/application/game_controller.dart';
import 'package:tiny_trails/data/catalog.dart';
import 'package:tiny_trails/data/progress_store.dart';
import 'package:tiny_trails/domain/models.dart';

class FailingStore extends MemoryProgressStore {
  bool fail = true;
  int activeWrites = 0;
  int maxConcurrentWrites = 0;

  @override
  Future<void> write(String key, String value) async {
    activeWrites++;
    if (activeWrites > maxConcurrentWrites) maxConcurrentWrites = activeWrites;
    try {
      await Future<void>.delayed(Duration.zero);
      if (fail) throw StateError('Synthetic write failure');
      await super.write(key, value);
    } finally {
      activeWrites--;
    }
  }
}

class GatedStore extends MemoryProgressStore {
  final gate = Completer<void>();
  int writes = 0;

  @override
  Future<void> write(String key, String value) async {
    writes++;
    if (writes == 1) await gate.future;
    await super.write(key, value);
  }
}

void main() {
  test(
    'settings, tutorial, progress, draft and artwork survive a restart',
    () async {
      final store = MemoryProgressStore();
      final controller = await GameController.load(store: store);
      await controller.setLanguage('kk');
      await controller.setSound(false);
      await controller.setVoice(false);
      await controller.setHaptics(false);
      await controller.setReducedMotion(true);
      await controller.finishOnboarding();
      await controller.markTutorialSeen(ActivityKind.numberColor);
      await controller.completeLevel(
        levels[0],
        artwork: {
          'fills': {'a': 2},
        },
      );
      await controller.saveDraft(levels[1].id, {
        'fills': {'b': 3},
      });
      final restored = await GameController.load(store: store);
      expect(restored.language, 'kk');
      expect(restored.sound, isFalse);
      expect(restored.voice, isFalse);
      expect(restored.haptics, isFalse);
      expect(restored.reducedMotion, isTrue);
      expect(restored.onboardingComplete, isTrue);
      expect(restored.hasSeenTutorial(ActivityKind.numberColor), isTrue);
      expect(restored.completedCount, 1);
      expect(restored.totalStars, 3);
      expect(restored.artworks.single.data, {
        'fills': {'a': 2},
      });
      expect(restored.draftFor(levels[1].id), {
        'fills': {'b': 3},
      });
      expect(restored.persistenceError, isNull);
    },
  );

  test(
    'a damaged primary snapshot recovers the previous committed snapshot',
    () async {
      final store = MemoryProgressStore();
      final controller = await GameController.load(store: store);
      await controller.completeLevel(levels[0]);
      await controller.completeLevel(levels[1]);
      store.values[GameController.storageKey] = '{broken';
      final restored = await GameController.load(store: store);
      expect(restored.completedCount, 1);
      expect(restored.progress.containsKey(levels[0].id), isTrue);
      expect(restored.persistenceError, isNotNull);
    },
  );

  test('a missing primary can recover a backup too', () async {
    final store = MemoryProgressStore();
    final controller = await GameController.load(store: store);
    await controller.completeLevel(levels[0]);
    await controller.completeLevel(levels[1]);
    store.values.remove(GameController.storageKey);
    final restored = await GameController.load(store: store);
    expect(restored.completedCount, 1);
    expect(restored.persistenceError, isNotNull);
  });

  test(
    'a corrupted individual record does not discard valid progress',
    () async {
      final store = MemoryProgressStore();
      final controller = await GameController.load(store: store);
      await controller.completeLevel(levels[0]);
      final json = jsonDecode(
        store.values[GameController.storageKey]!,
      ) as Map<String, dynamic>;
      (json['progress'] as Map)[levels[1].id] = {
        'stars': 999,
        'completedAt': 'bad',
      };
      store.values[GameController.storageKey] = jsonEncode(json);
      final restored = await GameController.load(store: store);
      expect(restored.completedCount, 1);
      expect(restored.progress.containsKey(levels[0].id), isTrue);
      expect(restored.persistenceError, isNotNull);
    },
  );

  test('unknown schema is preserved until an explicit reset', () async {
    const futureSnapshot = '{"version":99,"settings":{}}';
    final store = MemoryProgressStore({
      GameController.storageKey: futureSnapshot,
    });
    final controller = await GameController.load(store: store);
    expect(controller.persistenceError, isNotNull);
    await controller.setLanguage('en');
    expect(store.values[GameController.storageKey], futureSnapshot);
    await controller.resetProgress();
    expect(jsonDecode(store.values[GameController.storageKey]!)['version'], 1);
    expect(controller.language, 'en');
  });

  test(
    'reset clears learning data and tutorials but preserves preferences',
    () async {
      final store = MemoryProgressStore();
      final controller = await GameController.load(store: store);
      await controller.setLanguage('en');
      await controller.setSound(false);
      await controller.finishOnboarding();
      await controller.markTutorialSeen(ActivityKind.freeColor);
      await controller.completeLevel(levels[0], artwork: {'fills': {}});
      await controller.saveDraft(levels[1].id, {'fills': {}});
      await controller.resetProgress();
      final restored = await GameController.load(store: store);
      expect(restored.progress, isEmpty);
      expect(restored.drafts, isEmpty);
      expect(restored.artworks, isEmpty);
      expect(restored.earnedAchievements, isEmpty);
      expect(restored.hasSeenTutorial(ActivityKind.freeColor), isFalse);
      expect(restored.onboardingComplete, isTrue);
      expect(restored.language, 'en');
      expect(restored.sound, isFalse);
    },
  );

  test('writes stay ordered and errors are visible, then clear after a successful retry', () async {
    final store = FailingStore();
    final controller = await GameController.load(store: store);
    await expectLater(
      controller.completeLevel(
        levels[0],
        artwork: {
          'fills': {'a': 4},
        },
      ),
      throwsA(isA<CompletionPersistenceException>()),
    );
    expect(controller.persistenceError, isNotNull);
    expect(controller.completedCount, 0);
    expect(controller.earnedAchievements, isEmpty);
    expect(controller.draftFor(levels[0].id), {
      'fills': {'a': 4},
    });
    store.fail = false;
    await Future.wait([
      controller.setLanguage('kk'),
      controller.setSound(false),
      controller.setVoice(false),
    ]);
    expect(store.maxConcurrentWrites, 1);
    expect(controller.persistenceError, isNull);
    final reward = await controller.completeLevel(
      levels[0],
      artwork: controller.draftFor(levels[0].id),
    );
    expect(reward.stars, 3);
    expect(reward.firstCompletion, isTrue);
    expect(
      reward.newAchievements.map((item) => item.id),
      contains('first_step'),
    );
    final restored = await GameController.load(store: store);
    expect(restored.completedCount, 1);
    expect(restored.language, 'kk');
    expect(restored.sound, isFalse);
    expect(restored.voice, isFalse);
  });

  test('rapid changes coalesce to one waiting snapshot and flush keeps the latest state', () async {
    final store = GatedStore();
    final controller = await GameController.load(store: store);
    final writes = <Future<void>>[];
    for (var i = 0; i < 100; i++) {
      writes.add(controller.saveDraft(levels.first.id, {'point': i}));
    }
    expect(store.writes, 1);
    store.gate.complete();
    await Future.wait(writes);
    await controller.flush();
    expect(store.writes, 4);
    final restored = await GameController.load(store: store);
    expect(restored.draftFor(levels.first.id), {'point': 99});
  });

  test(
    'confirmed reset removes old learning data from the backup as well',
    () async {
      final store = MemoryProgressStore();
      final controller = await GameController.load(store: store);
      await controller.completeLevel(
        levels.first,
        artwork: {
          'fills': {'body': 1},
        },
      );
      await controller.resetProgress();
      store.values[GameController.storageKey] = 'broken';
      final restored = await GameController.load(store: store);
      expect(restored.progress, isEmpty);
      expect(restored.artworks, isEmpty);
    },
  );

  test('missing and malformed versions recover completed progress from a valid backup', () async {
    final seedStore = MemoryProgressStore();
    final controller = await GameController.load(store: seedStore);
    await controller.completeLevel(levels.first);
    await controller.setLanguage('en');
    for (final version in [null, 'bad', -1, 1.0]) {
      final store = MemoryProgressStore(seedStore.values);
      store.values[GameController.storageKey] = jsonEncode({
        'version': ?version,
        'settings': {},
      });
      final restored = await GameController.load(store: store);
      expect(restored.completedCount, 1, reason: 'version=$version');
      expect(restored.persistenceError, contains('резервной копии'));
    }
  });

  test('failed replay restores the previous award and painting, then retries without duplicate rewards', () async {
    final store = FailingStore()..fail = false;
    final controller = await GameController.load(store: store);
    await controller.completeLevel(
      levels.first,
      artwork: {
        'fills': {'body': 1},
      },
    );
    store.fail = true;
    await expectLater(
      controller.completeLevel(
        levels.first,
        stars: 1,
        artwork: {
          'fills': {'body': 2},
        },
      ),
      throwsA(isA<CompletionPersistenceException>()),
    );
    expect(controller.progress[levels.first.id]!.attempts, 1);
    expect(controller.totalStars, 3);
    expect(controller.artworks.single.data['fills']['body'], 1);
    expect(controller.draftFor(levels.first.id)!['fills']['body'], 2);
    final restartedAfterFailure = await GameController.load(store: store);
    expect(restartedAfterFailure.totalStars, 3);
    expect(restartedAfterFailure.artworks.single.data['fills']['body'], 1);
    store.fail = false;
    final reward = await controller.completeLevel(
      levels.first,
      artwork: controller.draftFor(levels.first.id),
    );
    expect(reward.firstCompletion, isFalse);
    expect(reward.newAchievements, isEmpty);
    expect(controller.progress[levels.first.id]!.attempts, 2);
    expect(controller.artworks.single.data['fills']['body'], 2);
  });

  test('completion remains committed when settings change during its pending write', () async {
    final store = GatedStore();
    final controller = await GameController.load(store: store);
    final completion = controller.completeLevel(levels.first);
    await Future<void>.delayed(Duration.zero);
    final language = controller.setLanguage('en');
    final sound = controller.setSound(false);
    store.gate.complete();
    final reward = await completion;
    await Future.wait([language, sound]);
    expect(reward.firstCompletion, isTrue);
    final restored = await GameController.load(store: store);
    expect(restored.completedCount, 1);
    expect(restored.language, 'en');
    expect(restored.sound, isFalse);
  });

  test(
    'reset while completion is being written cannot resurrect a reward',
    () async {
      final store = GatedStore();
      final controller = await GameController.load(store: store);
      final completion = controller.completeLevel(levels.first);
      final assertion = expectLater(
        completion,
        throwsA(isA<CompletionPersistenceException>()),
      );
      await Future<void>.delayed(Duration.zero);
      final reset = controller.resetProgress();
      store.gate.complete();
      await reset;
      await assertion;
      expect(controller.completedCount, 0);
      final restored = await GameController.load(store: store);
      expect(restored.completedCount, 0);
    },
  );
}
