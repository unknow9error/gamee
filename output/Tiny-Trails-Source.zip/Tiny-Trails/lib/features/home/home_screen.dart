import 'package:flutter/material.dart';

import '../../application/game_controller.dart';
import '../../core/strings.dart';
import '../../core/theme.dart';
import '../../data/catalog.dart';
import '../../domain/models.dart';
import '../../shared/art/scene_illustration.dart';
import '../../shared/widgets/common.dart';
import 'world_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.controller, required this.onPlay});
  final GameController controller;
  final ValueChanged<LevelDefinition> onPlay;
  @override
  Widget build(BuildContext context) {
    final c = controller;
    final lang = c.language;
    return LayoutBuilder(
      builder: (context, constraints) {
        final wide = constraints.maxWidth > 650;
        return SingleChildScrollView(
          key: const PageStorageKey('home-scroll'),
          padding: EdgeInsets.symmetric(
            horizontal: wide ? 32 : 22,
            vertical: 15,
          ),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 1150),
              child: Entrance(
                disabled: c.reducedMotion,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      textFor(
                        lang,
                        'ИГРАЕМ. РИСУЕМ. РАСТЁМ.',
                        'ОЙНАЙМЫЗ. САЛАМЫЗ. ӨСЕМІЗ.',
                        'PLAY. CREATE. GROW.',
                      ),
                      style: const TextStyle(
                        color: AppColors.green,
                        fontSize: 10,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.6,
                      ),
                    ),
                    const SizedBox(height: 9),
                    Text(
                      textFor(
                        lang,
                        'Мир открытий\nначинается с тебя',
                        'Жаңалықтар әлемі\nсенен басталады',
                        'A little wonder.\nA big adventure.',
                      ),
                      style: Theme.of(context).textTheme.displaySmall
                          ?.copyWith(fontSize: wide ? 40 : 32),
                    ),
                    const SizedBox(height: 21),
                    _ContinueCard(controller: c, onPlay: onPlay),
                    SectionTitle(
                      textFor(
                        lang,
                        'Куда отправимся?',
                        'Қайда барамыз?',
                        'Where shall we go?',
                      ),
                      trailing: Text(
                        textFor(
                          lang,
                          '6 миров · 120 игр',
                          '6 әлем · 120 ойын',
                          '6 worlds · 120 games',
                        ),
                        style: const TextStyle(
                          color: AppColors.muted,
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                    GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: wide ? 3 : 2,
                        mainAxisSpacing: 14,
                        crossAxisSpacing: 14,
                        childAspectRatio: wide ? 1.18 : 0.87,
                      ),
                      itemCount: worlds.length,
                      itemBuilder: (context, index) =>
                          _WorldCard(world: worlds[index], controller: c),
                    ),
                    SectionTitle(
                      textFor(
                        lang,
                        'Одно маленькое открытие',
                        'Бір кішкентай жаңалық',
                        'One little discovery',
                      ),
                    ),
                    SurfaceCard(
                      color: const Color(0xFFF0ECFA),
                      onTap: () => onPlay(
                        levels.firstWhere(
                          (l) => l.kind == ActivityKind.guidedDraw,
                        ),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 54,
                            height: 54,
                            decoration: BoxDecoration(
                              color: Colors.white.withValues(alpha: .7),
                              borderRadius: BorderRadius.circular(18),
                            ),
                            child: const Icon(
                              Icons.gesture_rounded,
                              color: Color(0xFF8871BA),
                              size: 30,
                            ),
                          ),
                          const SizedBox(width: 15),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  textFor(
                                    lang,
                                    'А если я не умею рисовать?',
                                    'Сурет сала алмасам ше?',
                                    'What if I can’t draw?',
                                  ),
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w900,
                                    fontSize: 15,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  textFor(
                                    lang,
                                    'Фини покажет, шаг за шагом',
                                    'Фини қадамдап көрсетеді',
                                    'Fini will show you, step by step',
                                  ),
                                  style: const TextStyle(
                                    color: AppColors.muted,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const Icon(Icons.arrow_forward_rounded, size: 20),
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),
                    Center(
                      child: Text(
                        textFor(
                          lang,
                          'Каждое открытие — маленькая победа ♡',
                          'Әрбір жаңалық — кішкентай жеңіс ♡',
                          'Every discovery is a little victory ♡',
                        ),
                        style: const TextStyle(
                          color: AppColors.muted,
                          fontSize: 11,
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _ContinueCard extends StatelessWidget {
  const _ContinueCard({required this.controller, required this.onPlay});
  final GameController controller;
  final ValueChanged<LevelDefinition> onPlay;
  @override
  Widget build(BuildContext context) {
    final lang = controller.language;
    final level = controller.nextLevel;
    return SurfaceCard(
      color: AppColors.lime,
      padding: EdgeInsets.zero,
      child: LayoutBuilder(
        builder: (context, box) {
          final compact = box.maxWidth < 370;
          return SizedBox(
            height: 215,
            child: Stack(
              children: [
                Positioned(
                  right: -30,
                  bottom: -70,
                  child: Container(
                    width: 240,
                    height: 220,
                    decoration: BoxDecoration(
                      color: const Color(0xFFCCDF8C),
                      borderRadius: BorderRadius.circular(120),
                    ),
                  ),
                ),
                Positioned(
                  right: compact ? -16 : 10,
                  top: 12,
                  bottom: 0,
                  width: compact ? 145 : 185,
                  child: SceneIllustration(
                    scene: 'fox',
                    size: 185,
                    subjectOnly: true,
                  ),
                ),
                Positioned(
                  left: 22,
                  top: 21,
                  bottom: 21,
                  width: compact ? 185 : 230,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Icon(
                            Icons.auto_awesome_rounded,
                            size: 15,
                            color: AppColors.green,
                          ),
                          const SizedBox(width: 6),
                          Text(
                            textFor(
                              lang,
                              'ТВОЁ ПРИКЛЮЧЕНИЕ',
                              'СЕНІҢ ОЙЫНЫҢ',
                              'YOUR NEXT ADVENTURE',
                            ),
                            style: const TextStyle(
                              fontSize: 9,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1,
                              color: AppColors.green,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Text(
                        controller.completedCount == 0
                            ? textFor(
                                lang,
                                'Привет! Я Фини.\nПоиграем?',
                                'Сәлем! Мен Фини.\nОйнаймыз ба?',
                                'Hi, I’m Fini.\nLet’s play!',
                              )
                            : level.title.resolve(lang),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.w900,
                          height: 1.18,
                        ),
                      ),
                      const SizedBox(height: 7),
                      Text(
                        activityName(level.kind, lang),
                        style: const TextStyle(
                          fontSize: 12,
                          color: AppColors.green,
                        ),
                      ),
                      const Spacer(),
                      FilledButton.icon(
                        key: const Key('continue-adventure'),
                        onPressed: () => onPlay(level),
                        icon: const Icon(Icons.play_arrow_rounded, size: 20),
                        label: Text(
                          textFor(
                            lang,
                            controller.completedCount == 0
                                ? 'Начать'
                                : 'Продолжить',
                            controller.completedCount == 0
                                ? 'Бастау'
                                : 'Жалғастыру',
                            controller.completedCount == 0
                                ? 'Let’s begin'
                                : 'Continue',
                          ),
                        ),
                        style: FilledButton.styleFrom(
                          minimumSize: const Size(140, 47),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _WorldCard extends StatelessWidget {
  const _WorldCard({required this.world, required this.controller});
  final WorldDefinition world;
  final GameController controller;
  @override
  Widget build(BuildContext context) {
    final count = levels
        .where(
          (l) => l.worldId == world.id && controller.progress.containsKey(l.id),
        )
        .length;
    final lang = controller.language;
    final tint = Color.alphaBlend(
      Color(world.color).withValues(alpha: .18),
      AppColors.paper,
    );
    return SurfaceCard(
      color: tint,
      padding: EdgeInsets.zero,
      onTap: () => Navigator.of(context).push(
        MaterialPageRoute<void>(
          builder: (_) => WorldScreen(world: world, controller: controller),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Stack(
              children: [
                Positioned.fill(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(8, 0, 8, 0),
                    child: SceneIllustration(scene: world.scene),
                  ),
                ),
                Positioned(
                  right: 10,
                  top: 10,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 7,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: .8),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      '$count / 20',
                      style: const TextStyle(
                        fontSize: 9,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 0, 10, 13),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        world.title.resolve(lang),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        world.subtitle.resolve(lang),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 10,
                          color: AppColors.muted,
                        ),
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.arrow_forward_rounded, size: 17),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
