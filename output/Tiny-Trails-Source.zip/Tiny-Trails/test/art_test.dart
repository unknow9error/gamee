import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:tiny_trails/data/catalog.dart';
import 'package:tiny_trails/shared/art/art_scene.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUpAll(() async {
    final loader = FontLoader('Nunito')
      ..addFont(rootBundle.load('assets/fonts/Nunito.ttf'));
    await loader.load();
  });
  test('Every catalog task points to authored artwork', () {
    for (final level in levels) {
      expect(SceneFactory.sceneNames, contains(level.scene), reason: level.id);
    }
  });
  test('Every illustrated scene offers reachable real fill regions', () {
    for (final name in SceneFactory.sceneNames) {
      for (var variant = 0; variant < 4; variant++) {
        final scene = SceneFactory.create(name, variant: variant);
        expect(scene.regions.length, greaterThanOrEqualTo(12), reason: name);
        expect(
          scene.regions.map((r) => r.id).toSet().length,
          scene.regions.length,
          reason: name,
        );
        for (final region in scene.regions) {
          expect(
            region.path.getBounds().left,
            greaterThanOrEqualTo(0),
            reason: '$name ${region.id}',
          );
          expect(
            region.path.getBounds().right,
            lessThanOrEqualTo(400),
            reason: '$name ${region.id}',
          );
          expect(
            region.path.contains(region.labelPoint),
            isTrue,
            reason: 'Label outside $name ${region.id}: ${region.labelPoint}',
          );
          expect(region.number, inInclusiveRange(6, 12));
          // A closed path must retain some area accessible to real taps.
          var reachable = false;
          final index = scene.regions.indexOf(region);
          expect(
            scene.regions
                .skip(index + 1)
                .any((r) => r.path.contains(region.labelPoint)),
            isFalse,
            reason: 'Covered label $name ${region.id}',
          );
          for (
            var x = region.path.getBounds().left + 1;
            x < region.path.getBounds().right;
            x += 3
          ) {
            for (
              var y = region.path.getBounds().top + 1;
              y < region.path.getBounds().bottom;
              y += 3
            ) {
              final point = Offset(x, y);
              if (region.path.contains(point) &&
                  !scene.regions
                      .skip(index + 1)
                      .any((r) => r.path.contains(point))) {
                reachable = true;
                break;
              }
            }
            if (reachable) break;
          }
          expect(
            reachable,
            isTrue,
            reason: 'Covered fill region $name ${region.id}',
          );
        }
        final steps = drawingSteps(name);
        expect(steps.length, inInclusiveRange(4, 6));
        expect(steps.every((s) => s.path.computeMetrics().isNotEmpty), isTrue);
      }
    }
  });
  test('Number scenes split large paths into reachable curved parts', () {
    for (final name in SceneFactory.sceneNames) {
      for (var variant = 0; variant < 4; variant++) {
        final base = SceneFactory.create(name, variant: variant);
        final scene = SceneFactory.create(
          name,
          variant: variant,
          segmented: true,
        );
        expect(
          scene.regions.length,
          greaterThan(base.regions.length),
          reason: '$name $variant',
        );
        expect(
          scene.regions.map((r) => r.id).toSet().length,
          scene.regions.length,
        );
        for (final region in scene.regions) {
          expect(
            region.path.contains(region.labelPoint),
            isTrue,
            reason: 'Number label $name $variant ${region.id}',
          );
          expect(
            scene.regions
                .where((r) => r.path.contains(region.labelPoint))
                .length,
            1,
            reason: 'Number label overlap $name $variant ${region.id}',
          );
        }
      }
    }
  });
  test('Guided drawing teaches head then beak and excludes scenic details', () {
    final duck = drawingSteps('duck');
    expect(duck[0].path.getBounds().center.dy, lessThan(190));
    expect(duck[1].path.getBounds().right, lessThan(140));
    expect(duck[2].path.getBounds().center.dy, greaterThan(230));
    final rocketDetails = drawingSteps('rocket').last.path.getBounds();
    // The planet ring at x277..352 is scenery, not an anatomical drawing step.
    expect(rocketDetails.right, lessThan(230));
    expect(rocketDetails.left, greaterThan(170));
  });
  test('24 themed hidden worksheets are distinct, complete partitions', () {
    const worldIds = ['ocean', 'forest', 'meadow', 'farm', 'safari', 'space'];
    final signatures = <String>{};
    for (final worldId in worldIds) {
      for (var variant = 0; variant < 4; variant++) {
        // Same scene deliberately verifies that worldId owns the composition.
        final scene = SceneFactory.create(
          'fox',
          variant: variant,
          geometric: true,
          worldId: worldId,
        );
        expect(scene.hiddenAnimals.length, 3);
        expect(
          scene.regions.map((r) => r.id).toSet().length,
          scene.regions.length,
        );
        signatures.add(
          scene.hiddenAnimals.map((a) => '${a.id}@${a.anchor}').join(';'),
        );
        for (final animal in scene.hiddenAnimals) {
          expect(animal.regionIds.length, greaterThanOrEqualTo(6));
          expect(
            animal.regionIds.every(
              (id) => scene.regions.any((r) => r.id == id),
            ),
            isTrue,
          );
          expect(
            scene.regions.any(
              (r) => r.group == animal.id && r.path.contains(animal.anchor),
            ),
            isTrue,
          );
        }
        for (final region in scene.regions) {
          expect(region.path.contains(region.labelPoint), isTrue);
          final bounds = region.path.getBounds();
          expect(bounds.left, greaterThanOrEqualTo(21.99));
          expect(bounds.top, greaterThanOrEqualTo(21.99));
          expect(bounds.right, lessThanOrEqualTo(378.01));
          expect(bounds.bottom, lessThanOrEqualTo(378.01));
        }
        // Every interior sample belongs to precisely one actual paint region.
        for (var x = 22.37; x < 378; x += 7) {
          for (var y = 22.37; y < 378; y += 7) {
            expect(
              scene.regions.where((r) => r.path.contains(Offset(x, y))).length,
              1,
              reason: '$worldId $variant partition at $x,$y',
            );
          }
        }
      }
    }
    expect(signatures.length, 24);
    final ocean = SceneFactory.create('fox', geometric: true, worldId: 'ocean');
    final forest = SceneFactory.create(
      'fox',
      geometric: true,
      worldId: 'forest',
    );
    expect(ocean.hiddenAnimals.map((a) => a.id).toSet(), {
      'whale',
      'dolphin',
      'turtle',
    });
    expect(forest.hiddenAnimals.map((a) => a.id).toSet(), {
      'fox',
      'rabbit',
      'owl',
    });
  });
  test('Render original illustration contact sheet', () async {
    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder);
    canvas.drawColor(Colors.white, BlendMode.src);
    for (var i = 0; i < SceneFactory.sceneNames.length; i++) {
      canvas.save();
      canvas.translate((i % 4) * 240.0, (i ~/ 4) * 265.0);
      ArtScenePainter(
        scene: SceneFactory.create(SceneFactory.sceneNames[i]),
        colored: true,
      ).paint(canvas, const Size(240, 240));
      final tp = TextPainter(
        text: TextSpan(
          text: SceneFactory.sceneNames[i],
          style: const TextStyle(
            color: Colors.black,
            fontSize: 16,
            fontFamily: 'Nunito',
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, const Offset(15, 242));
      canvas.restore();
    }
    final picture = recorder.endRecording();
    final image = await picture.toImage(960, 795);
    final data = await image.toByteData(format: ui.ImageByteFormat.png);
    await File('${Directory.systemTemp.path}/tiny-trails-art-sheet.png')
        .writeAsBytes(data!.buffer.asUint8List());
    image.dispose();
    picture.dispose();
  });
  test('Render curved number worksheet', () async {
    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder);
    canvas.drawColor(Colors.white, BlendMode.src);
    ArtScenePainter(
      scene: SceneFactory.create('dolphin', variant: 3, segmented: true),
      showNumbers: true,
    ).paint(canvas, const Size(800, 800));
    final picture = recorder.endRecording();
    final image = await picture.toImage(800, 800);
    final data = await image.toByteData(format: ui.ImageByteFormat.png);
    await File('${Directory.systemTemp.path}/tiny-trails-number-scene.png')
        .writeAsBytes(data!.buffer.asUint8List());
    image.dispose();
    picture.dispose();
  });
}
