import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:tiny_trails/application/game_controller.dart';
import 'package:tiny_trails/core/theme.dart';
import 'package:tiny_trails/data/catalog.dart';
import 'package:tiny_trails/data/progress_store.dart';
import 'package:tiny_trails/features/settings/settings_screen.dart';

void main() {
  Future<void> showSettings(
    WidgetTester tester,
    GameController controller,
  ) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: buildTheme(),
        home: SettingsScreen(controller: controller),
      ),
    );
    await tester.pumpAndSettle();
  }

  Future<void> openGate(WidgetTester tester) async {
    final open = find.byKey(const ValueKey('open-parent-area'));
    await tester.ensureVisible(open);
    await tester.tap(open);
    await tester.pumpAndSettle();
  }

  Future<void> solveGate(WidgetTester tester) async {
    final expression = tester
        .widgetList<Text>(find.byType(Text))
        .map((widget) => widget.data ?? '')
        .firstWhere((text) => RegExp(r'^\d+ × \d+ = \?$').hasMatch(text));
    final values = RegExp(r'\d+')
        .allMatches(expression)
        .map((match) => int.parse(match.group(0)!))
        .toList();
    await tester.enterText(
      find.byKey(const ValueKey('parent-gate-answer')),
      '${values[0] * values[1]}',
    );
    await tester.tap(find.byKey(const ValueKey('parent-gate-submit')));
    await tester.pumpAndSettle();
  }

  testWidgets('language changes all settings copy immediately', (tester) async {
    final controller = GameController.forTest();
    addTearDown(controller.dispose);
    await showSettings(tester, controller);
    await tester.tap(find.byKey(const ValueKey('language-en')));
    await tester.pumpAndSettle();
    expect(controller.language, 'en');
    expect(find.text('Settings'), findsOneWidget);
    expect(find.text('Spoken hints'), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('language-kk')));
    await tester.pumpAndSettle();
    expect(controller.language, 'kk');
    expect(find.text('Баптаулар'), findsOneWidget);
    expect(find.text('Дауыстық кеңестер'), findsOneWidget);
  });

  testWidgets('wrong parent answer cannot expose destructive action', (
    tester,
  ) async {
    final controller = GameController.forTest();
    addTearDown(controller.dispose);
    await controller.completeLevel(levels.first);
    await showSettings(tester, controller);
    expect(find.byKey(const ValueKey('reset-progress')), findsNothing);
    await openGate(tester);
    await tester.enterText(
      find.byKey(const ValueKey('parent-gate-answer')),
      '0',
    );
    await tester.tap(find.byKey(const ValueKey('parent-gate-submit')));
    await tester.pumpAndSettle();
    expect(find.text('Попробуйте ещё раз'), findsOneWidget);
    expect(find.byKey(const ValueKey('reset-progress')), findsNothing);
    expect(controller.completedCount, 1);
  });

  testWidgets('all preference switches persist after reopening', (tester) async {
    final store = MemoryProgressStore();
    final controller = GameController.forTest(store: store);
    addTearDown(controller.dispose);
    await showSettings(tester, controller);
    for (final setting in ['sound', 'voice', 'haptics', 'reduced-motion']) {
      final toggle = find.byKey(ValueKey('setting-$setting'));
      await tester.ensureVisible(toggle);
      await tester.tap(toggle);
      await tester.pumpAndSettle();
    }
    await controller.flush();
    final restored = await GameController.load(store: store);
    addTearDown(restored.dispose);
    expect(restored.sound, isFalse);
    expect(restored.voice, isFalse);
    expect(restored.haptics, isFalse);
    expect(restored.reducedMotion, isTrue);
  });

  testWidgets('parent gate and second confirmation protect learning data', (
    tester,
  ) async {
    final controller = GameController.forTest();
    addTearDown(controller.dispose);
    await controller.setLanguage('en');
    await controller.setSound(false);
    await controller.completeLevel(levels.first);
    await showSettings(tester, controller);
    await openGate(tester);
    await solveGate(tester);
    final reset = find.byKey(const ValueKey('reset-progress'));
    await tester.ensureVisible(reset);
    await tester.tap(reset);
    await tester.pumpAndSettle();
    expect(controller.completedCount, 1);
    await tester.tap(find.text('Keep them'));
    await tester.pumpAndSettle();
    expect(controller.completedCount, 1);
    await tester.tap(reset);
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('confirm-reset-progress')));
    await tester.pumpAndSettle();
    expect(controller.completedCount, 0);
    expect(controller.language, 'en');
    expect(controller.sound, isFalse);
  });

  testWidgets('settings fits small phone and enlarged text', (tester) async {
    tester.view.physicalSize = const Size(320, 568);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final controller = GameController.forTest();
    addTearDown(controller.dispose);
    await tester.pumpWidget(
      MaterialApp(
        theme: buildTheme(),
        builder: (context, child) => MediaQuery(
          data: MediaQuery.of(context)
              .copyWith(textScaler: const TextScaler.linear(1.3)),
          child: child!,
        ),
        home: SettingsScreen(controller: controller),
      ),
    );
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
    await tester.scrollUntilVisible(
      find.byKey(const ValueKey('open-parent-area')),
      200,
      scrollable: find.byType(Scrollable).first,
    );
    expect(tester.takeException(), isNull);
  });
}
