import 'dart:async';

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:tiny_trails/core/feedback_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const speech = MethodChannel('tiny_trails/speech');
  final messenger =
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
  final calls = <MethodCall>[];
  setUp(() {
    calls.clear();
    messenger.setMockMethodCallHandler(speech, (call) async {
      calls.add(call);
      return true;
    });
  });
  tearDown(() {
    messenger.setMockMethodCallHandler(speech, null);
  });
  test('availability queries the selected installed voice', () async {
    final feedback = FeedbackService();
    expect(await feedback.isSpeechAvailable('kk'), isTrue);
    expect(calls.single.method, 'isAvailable');
    expect(calls.single.arguments, {'language': 'kk'});
    messenger.setMockMethodCallHandler(speech, (call) async => false);
    expect(await feedback.isSpeechAvailable('ru'), isFalse);
    feedback.dispose();
  });
  test(
    'unavailable or invalid speech stays a safe capability result',
    () async {
      final feedback = FeedbackService();
      expect(await feedback.isSpeechAvailable('fr'), isFalse);
      expect(calls, isEmpty);
      messenger.setMockMethodCallHandler(speech, (call) async {
        throw PlatformException(code: 'engine_unavailable');
      });
      expect(await feedback.isSpeechAvailable('ru'), isFalse);
      messenger.setMockMethodCallHandler(speech, null);
      expect(await feedback.isSpeechAvailable('en'), isFalse);
      feedback.dispose();
      expect(await feedback.isSpeechAvailable('en'), isFalse);
    },
  );
  test('speech text respects both native platform length limits', () async {
    final feedback = FeedbackService();
    await feedback.speak('a' * 1400, 'en', enabled: true);
    expect((calls.last.arguments as Map)['text'].length, 1000);
    feedback.dispose();
  });
  test(
    'voice hints replace previous speech and disabled voice stops it',
    () async {
      final feedback = FeedbackService();
      await feedback.speak('  Нарисуй круг  ', 'kk', enabled: true);
      expect(calls.map((e) => e.method), ['stop', 'speak']);
      expect(calls.last.arguments, {'text': 'Нарисуй круг', 'language': 'kk'});
      await feedback.speak('Should stay silent', 'en', enabled: false);
      expect(calls.last.method, 'stop');
      expect(calls.where((e) => e.method == 'speak').length, 1);
      feedback.dispose();
    },
  );
  test(
    'a later request cancels a stale hint waiting for native stop',
    () async {
      final stop = Completer<void>();
      var stopCount = 0;
      messenger.setMockMethodCallHandler(speech, (call) async {
        calls.add(call);
        if (call.method == 'stop' && ++stopCount == 1) await stop.future;
        return true;
      });
      final feedback = FeedbackService();
      final old = feedback.speak('old', 'ru', enabled: true);
      await Future<void>.delayed(Duration.zero);
      await feedback.speak('new', 'en', enabled: true);
      stop.complete();
      await old;
      final spoken = calls.where((e) => e.method == 'speak').toList();
      expect(spoken.length, 1);
      expect((spoken.single.arguments as Map)['text'], 'new');
      feedback.dispose();
    },
  );
  test(
    'missing speech plugin and disabled sound/haptics do not break game',
    () async {
      messenger.setMockMethodCallHandler(speech, null);
      final feedback = FeedbackService();
      await feedback.speak('hint', 'ru', enabled: true);
      await feedback.tap(sound: false, haptics: false);
      await feedback.success(sound: false, haptics: false);
      feedback.dispose();
      feedback.dispose();
      await feedback.speak('disposed', 'ru', enabled: true);
    },
  );
}
