import 'dart:math' as math;

import 'package:flutter/gestures.dart';

import 'package:flutter/material.dart';

import '../../core/strings.dart';
import '../../core/theme.dart';
import 'activity_config.dart';
import 'engines/maze_engine.dart';

class MazeActivity extends StatefulWidget {
  const MazeActivity({super.key, required this.config});
  final ActivityConfig config;
  @override
  State<MazeActivity> createState() => _MazeActivityState();
}

class _MazeActivityState extends State<MazeActivity> {
  late MazeNetwork _network;
  late MazeSession _session;
  bool _completedSent = false;
  bool _blockedMessage = false;
  ActivityConfig get config => widget.config;
  String t(String ru, String kk, String en) =>
      textFor(config.language, ru, kk, en);

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  @override
  void didUpdateWidget(covariant MazeActivity oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.config.level.id != config.level.id) _initialize();
  }

  void _initialize() {
    _network = MazeNetwork.generate(
      seed: '${config.level.worldId}-${config.level.variant}',
      difficulty: config.level.difficulty,
    );
    _session = MazeSession(_network, saved: config.initialData);
    _completedSent = false;
    // The final junction may have been persisted just before the app stopped,
    // before its completion reward was committed. Recover that transaction.
    final levelId = config.level.id;
    if (_session.isComplete) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted || config.level.id != levelId) return;
        _finishIfNeeded();
      });
    }
  }

  void _finishIfNeeded() {
    if (_session.isComplete && !_completedSent) {
      _completedSent = true;
      config.onCompleted(_session.toJson());
    }
  }

  void _accept(MazeMove move) {
    if (move == MazeMove.ignored) return;
    setState(() => _blockedMessage = move == MazeMove.blocked);
    if (move == MazeMove.arrived || move == MazeMove.completed) {
      config.onFeedback();
      config.onChanged(_session.toJson());
    }
    if (move == MazeMove.completed) _finishIfNeeded();
  }

  void _tapNode(int node) => _accept(_session.tapNode(node));
  void _undo() {
    setState(() {
      _session.undo();
      _blockedMessage = false;
      _completedSent = false;
    });
    config.onChanged(_session.toJson());
  }

  void _reset() {
    setState(() {
      _session.reset();
      _blockedMessage = false;
      _completedSent = false;
    });
    config.onChanged(_session.toJson());
  }

  @override
  Widget build(BuildContext context) {
    final status = Padding(
      padding: const EdgeInsets.fromLTRB(8, 0, 8, 10),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: AppColors.yellow.withValues(alpha: .48),
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Icon(Icons.route_rounded, color: AppColors.green),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              _blockedMessage
                  ? t(
                      'Здесь ремонт. Попробуй другую дорогу!',
                      'Мұнда жөндеу жүріп жатыр. Басқа жолды көр!',
                      'Road works here. Try another way!',
                    )
                  : t(
                      'Веди автобус или нажимай на точки дороги.',
                      'Автобусты жүргіз немесе жол нүктелерін бас.',
                      'Drag the bus or tap the road dots.',
                    ),
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ),
        ],
      ),
    );
    final board = Expanded(
      child: LayoutBuilder(
        builder: (context, constraints) {
          final side = math.min(constraints.maxWidth, constraints.maxHeight);
          return Center(
            child: SizedBox(
              width: side,
              height: side,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: const Color(0xFFEBF2DC),
                  borderRadius: BorderRadius.circular(28),
                  border: Border.all(color: Colors.white, width: 5),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0x0D304A37),
                      offset: Offset(0, 8),
                      blurRadius: 20,
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(24),
                  child: LayoutBuilder(
                    builder: (context, mapConstraints) {
                      final scale = mapConstraints.maxWidth / 400;
                      Offset point(Offset local) => local / scale;
                      final neighbors = _network
                          .roadsFrom(_session.current)
                          .map((r) => r.other(_session.current))
                          .toList();
                      return GestureDetector(
                        key: const ValueKey('maze-canvas'),
                        behavior: HitTestBehavior.opaque,
                        dragStartBehavior: DragStartBehavior.down,
                        onTapUp: (details) {
                          final location = point(details.localPosition);
                          for (
                            var node = 0;
                            node < _network.nodes.length;
                            node++
                          ) {
                            if ((_network.nodes[node] - location).distance <
                                25) {
                              _tapNode(node);
                              break;
                            }
                          }
                        },
                        onPanStart: (details) => setState(() {
                          _session.beginDrag(point(details.localPosition));
                        }),
                        onPanUpdate: (details) => _accept(
                          _session.dragTo(point(details.localPosition)),
                        ),
                        onPanEnd: (_) => setState(_session.endDrag),
                        onPanCancel: () => setState(_session.endDrag),
                        child: Stack(
                          children: [
                            Positioned.fill(
                              child: CustomPaint(
                                painter: MazeScenePainter(
                                  network: _network,
                                  route: List<int>.of(_session.route),
                                  bus: _session.busPosition,
                                  hint: config.showHint,
                                  activeRoad: _session.activeRoad,
                                  edgeProgress: _session.edgeProgress,
                                  schoolLabel: t('ШКОЛА', 'МЕКТЕП', 'SCHOOL'),
                                  worldId: config.level.worldId,
                                ),
                              ),
                            ),
                            for (var i = 0; i < neighbors.length; i++)
                              Positioned(
                                left:
                                    _network.nodes[neighbors[i]].dx * scale -
                                    24,
                                top:
                                    _network.nodes[neighbors[i]].dy * scale -
                                    24,
                                width: 48,
                                height: 48,
                                child: Semantics(
                                  button: true,
                                  label: t(
                                    'Проехать по дороге ${i + 1}',
                                    '${i + 1}-жолмен жүру',
                                    'Take road ${i + 1}',
                                  ),
                                  child: GestureDetector(
                                    behavior: HitTestBehavior.opaque,
                                    onTap: () => _tapNode(neighbors[i]),
                                    child: const SizedBox.expand(),
                                  ),
                                ),
                              ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
    final actions = Wrap(
      alignment: WrapAlignment.center,
      spacing: 10,
      runSpacing: 2,
      crossAxisAlignment: WrapCrossAlignment.center,
      children: [
        OutlinedButton.icon(
          key: const ValueKey('maze-undo'),
          onPressed: _session.route.length > 1 ? _undo : null,
          icon: const Icon(Icons.undo_rounded, size: 20),
          label: Text(t('Назад', 'Артқа', 'Undo')),
          style: OutlinedButton.styleFrom(minimumSize: const Size(48, 48)),
        ),
        OutlinedButton.icon(
          key: const ValueKey('maze-restart'),
          onPressed: _session.route.length > 1 || _session.isDragging
              ? _reset
              : null,
          icon: const Icon(Icons.refresh_rounded, size: 20),
          label: Text(t('Сначала', 'Қайтадан', 'Restart')),
          style: OutlinedButton.styleFrom(minimumSize: const Size(48, 48)),
        ),
        Text(
          t('Без спешки ☀', 'Асықпай ойна ☀', 'Take your time ☀'),
          style: Theme.of(context).textTheme.bodySmall
              ?.copyWith(color: AppColors.muted),
        ),
      ],
    );
    return LayoutBuilder(
      builder: (context, constraints) {
        // In short landscape windows the controls use a side rail so the
        // drawing area keeps the full available height.
        final sideRail =
            constraints.maxWidth >= 620 && constraints.maxHeight <= 450;
        if (sideRail) {
          return Row(
            children: [
              board,
              const SizedBox(width: 12),
              SizedBox(
                width: 220,
                child: Center(
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [status, const SizedBox(height: 14), actions],
                    ),
                  ),
                ),
              ),
            ],
          );
        }
        return Column(
          children: [status, board, const SizedBox(height: 10), actions],
        );
      },
    );
  }
}

/// Original village artwork remains vector-sharp on phones and tablets.
class MazeScenePainter extends CustomPainter {
  MazeScenePainter({
    required this.network,
    required this.route,
    required this.bus,
    this.hint = false,
    this.activeRoad,
    this.edgeProgress = 0,
    this.schoolLabel = 'SCHOOL',
    this.worldId = 'forest',
  });
  final MazeNetwork network;
  final List<int> route;
  final Offset bus;
  final bool hint;
  final MazeRoad? activeRoad;
  final double edgeProgress;
  final String schoolLabel;
  final String worldId;

  static const _green = Color(0xFF6E9F72);
  static const _ink = Color(0xFF3D5747);
  void _path(Canvas c, Path p, Color color, double width) => c.drawPath(
    p,
    Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..strokeWidth = width,
  );

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / 400, size.height / 400);
    canvas.clipRect(const Rect.fromLTWH(0, 0, 400, 400));
    final background = worldId == 'space'
        ? const Color(0xFFE8E6F6)
        : worldId == 'ocean'
        ? const Color(0xFFE4F0E8)
        : worldId == 'safari'
        ? const Color(0xFFF3EACC)
        : const Color(0xFFEBF2DC);
    canvas.drawColor(background, BlendMode.srcOver);
    final patchPaint = Paint()
      ..color = const Color(0xFFD5E6BA).withValues(alpha: .55);
    canvas.drawOval(const Rect.fromLTWH(-45, 265, 170, 180), patchPaint);
    canvas.drawOval(const Rect.fromLTWH(230, 95, 200, 250), patchPaint);
    canvas.drawOval(
      const Rect.fromLTWH(120, -55, 220, 150),
      Paint()..color = Colors.white.withValues(alpha: .3),
    );
    // The river is scenery, not another traversable road.
    final river = Path()
      ..moveTo(-20, 366)
      ..cubicTo(80, 343, 170, 398, 255, 370)
      ..cubicTo(330, 345, 366, 360, 420, 340);
    _path(canvas, river, const Color(0xFFB2D8DF), 23);
    _path(canvas, river, const Color(0xFFD8EEF0), 2);
    _tree(canvas, const Offset(27, 39), .9);
    _tree(canvas, const Offset(71, 36), .7);
    _tree(canvas, const Offset(366, 208), .7);
    _tree(canvas, const Offset(30, 224), .6);
    _tree(canvas, const Offset(350, 370), .9);
    _bush(canvas, const Offset(177, 365), 1);
    _bush(canvas, const Offset(387, 88), .9);
    // Little village homes sit between the roads, avoiding their touch targets.
    final columns = network.nodes.where((n) => n.dy < 105).length;
    for (var y = 0; y < 3; y++) {
      for (var x = 0; x < columns - 1; x++) {
        final a = network.nodes[y * columns + x];
        final b = network.nodes[(y + 1) * columns + x + 1];
        final p = (a + b) / 2;
        if ((x + y) % 3 == 1) {
          _tree(canvas, p, .58);
          _bush(canvas, p + const Offset(17, 9), .5);
        } else {
          _house(
            canvas,
            p,
            (x + y).isEven ? const Color(0xFFE6B991) : const Color(0xFFC5B8DD),
          );
        }
      }
    }
    for (final road in network.roads) {
      _path(canvas, road.path, const Color(0xFFD5DFCD), 28);
      _path(canvas, road.path, const Color(0xFFFFFEF8), 23);
      _dash(canvas, road.path, const Color(0xFFD8DCCA), 1.5, 5, 7);
    }
    for (var i = 1; i < route.length; i++) {
      final road = network.roadBetween(route[i - 1], route[i]);
      if (road != null) _path(canvas, road.path, const Color(0xFF80B397), 7);
    }
    if (activeRoad != null && edgeProgress > 0) {
      final metric = activeRoad!.path.computeMetrics().first;
      final forward = route.last == activeRoad!.a;
      final p = forward
          ? metric.extractPath(0, metric.length * edgeProgress)
          : metric.extractPath(
              metric.length * (1 - edgeProgress),
              metric.length,
            );
      _path(canvas, p, const Color(0xFF80B397), 7);
    }
    for (final road in network.roads.where((r) => r.blocked)) {
      final center = road.point(.5);
      _barrier(canvas, center, road.from.dx == road.to.dx ? math.pi / 2 : 0);
    }
    if (hint && route.last != network.goal) {
      final solution = network.routeToGoal(route.last);
      if (solution.length > 1) {
        final road = network.roadBetween(solution[0], solution[1])!;
        _dash(canvas, road.path, const Color(0xFFE9B849), 5, 4, 8);
      }
    }
    for (final road in network.roadsFrom(route.last)) {
      final point = network.nodes[road.other(route.last)];
      canvas.drawCircle(point, 10, Paint()..color = const Color(0xFFCCE2BA));
      canvas.drawCircle(point, 4, Paint()..color = _green);
    }
    _school(canvas, network.nodes[network.goal] - const Offset(0, 48));
    _bus(canvas, bus);
    // Tiny meadow details make a calm, inhabited illustration.
    for (final p in const [
      Offset(116, 27),
      Offset(219, 53),
      Offset(26, 291),
      Offset(287, 351),
      Offset(118, 344),
    ]) {
      _flower(canvas, p);
    }
    canvas.restore();
  }

  void _dash(
    Canvas canvas,
    Path path,
    Color color,
    double width,
    double dash,
    double gap,
  ) {
    for (final metric in path.computeMetrics()) {
      for (
        var distance = 0.0;
        distance < metric.length;
        distance += dash + gap
      ) {
        _path(
          canvas,
          metric.extractPath(
            distance,
            math.min(distance + dash, metric.length),
          ),
          color,
          width,
        );
      }
    }
  }

  void _tree(Canvas c, Offset p, double scale) {
    c.save();
    c.translate(p.dx, p.dy);
    c.scale(scale);
    c.drawRRect(
      RRect.fromRectAndRadius(
        const Rect.fromLTWH(-3, -7, 6, 30),
        const Radius.circular(3),
      ),
      Paint()..color = const Color(0xFF9C8A68),
    );
    c.drawOval(const Rect.fromLTWH(-17, -30, 34, 42), Paint()..color = _green);
    c.drawOval(
      const Rect.fromLTWH(-13, -31, 22, 31),
      Paint()..color = const Color(0xFF8AB181),
    );
    c.restore();
  }

  void _bush(Canvas c, Offset p, double scale) {
    c.save();
    c.translate(p.dx, p.dy);
    c.scale(scale);
    final paint = Paint()..color = const Color(0xFF96B781);
    c.drawCircle(const Offset(-12, 0), 11, paint);
    c.drawCircle(const Offset(0, -5), 13, paint);
    c.drawCircle(const Offset(13, 0), 10, paint);
    c.drawRect(const Rect.fromLTWH(-18, 0, 37, 8), paint);
    c.restore();
  }

  void _house(Canvas c, Offset p, Color color) {
    c.save();
    c.translate(p.dx, p.dy);
    c.drawOval(
      const Rect.fromLTWH(-23, 15, 47, 8),
      Paint()..color = const Color(0x19768B63),
    );
    c.drawRRect(
      RRect.fromRectAndRadius(
        const Rect.fromLTWH(-17, -10, 34, 29),
        const Radius.circular(3),
      ),
      Paint()..color = color,
    );
    c.drawPath(
      Path()
        ..moveTo(-23, -9)
        ..lineTo(0, -28)
        ..lineTo(23, -9)
        ..close(),
      Paint()..color = const Color(0xFF6D8374),
    );
    c.drawRect(
      const Rect.fromLTWH(7, -25, 5, 11),
      Paint()..color = const Color(0xFF6D8374),
    );
    c.drawRRect(
      RRect.fromRectAndRadius(
        const Rect.fromLTWH(-4, 5, 8, 14),
        const Radius.circular(2),
      ),
      Paint()..color = const Color(0xFFF6F2D9),
    );
    for (final x in [-11.0, 7.0]) {
      c.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(x, -5, 6, 7),
          const Radius.circular(1),
        ),
        Paint()..color = const Color(0xFFF9F6E7),
      );
    }
    c.restore();
  }

  void _barrier(Canvas c, Offset p, double angle) {
    c.save();
    c.translate(p.dx, p.dy);
    c.rotate(angle);
    c.drawRect(
      const Rect.fromLTWH(-11, -6, 3, 17),
      Paint()..color = const Color(0xFF8A896F),
    );
    c.drawRect(
      const Rect.fromLTWH(8, -6, 3, 17),
      Paint()..color = const Color(0xFF8A896F),
    );
    c.drawRRect(
      RRect.fromRectAndRadius(
        const Rect.fromLTWH(-18, -9, 36, 12),
        const Radius.circular(3),
      ),
      Paint()..color = const Color(0xFFF7D78C),
    );
    c.save();
    c.clipRRect(
      RRect.fromRectAndRadius(
        const Rect.fromLTWH(-18, -9, 36, 12),
        const Radius.circular(3),
      ),
    );
    for (var x = -22.0; x < 26; x += 12) {
      c.drawPath(
        Path()
          ..moveTo(x, -9)
          ..lineTo(x + 6, -9)
          ..lineTo(x - 1, 3)
          ..lineTo(x - 7, 3)
          ..close(),
        Paint()..color = const Color(0xFFD99570),
      );
    }
    c.restore();
    c.restore();
  }

  void _school(Canvas c, Offset p) {
    c.save();
    c.translate(p.dx - 5, p.dy);
    c.drawRRect(
      RRect.fromRectAndRadius(
        const Rect.fromLTWH(-39, -15, 78, 45),
        const Radius.circular(4),
      ),
      Paint()..color = const Color(0xFFDAAE8D),
    );
    c.drawRect(
      const Rect.fromLTWH(-13, -27, 26, 57),
      Paint()..color = const Color(0xFFE9C5A3),
    );
    c.drawPath(
      Path()
        ..moveTo(-19, -26)
        ..lineTo(0, -43)
        ..lineTo(19, -26)
        ..close(),
      Paint()..color = const Color(0xFF728F7D),
    );
    c.drawRect(
      const Rect.fromLTWH(-42, -19, 29, 6),
      Paint()..color = const Color(0xFF728F7D),
    );
    c.drawRect(
      const Rect.fromLTWH(13, -19, 29, 6),
      Paint()..color = const Color(0xFF728F7D),
    );
    c.drawRRect(
      RRect.fromRectAndRadius(
        const Rect.fromLTWH(-7, 9, 14, 21),
        const Radius.circular(3),
      ),
      Paint()..color = _ink,
    );
    for (final x in [-30.0, -20.0, 20.0, 30.0]) {
      for (final y in [-5.0, 10.0]) {
        c.drawRRect(
          RRect.fromRectAndRadius(
            Rect.fromCenter(center: Offset(x, y), width: 6, height: 9),
            const Radius.circular(1),
          ),
          Paint()..color = const Color(0xFFFFF7E3),
        );
      }
    }
    c.drawCircle(
      const Offset(0, -20),
      5,
      Paint()..color = const Color(0xFFFFF7E3),
    );
    _path(
      c,
      Path()
        ..moveTo(0, -23)
        ..lineTo(0, -20)
        ..lineTo(3, -20),
      _ink,
      1,
    );
    final text = TextPainter(
      text: TextSpan(
        text: schoolLabel,
        style: const TextStyle(
          fontFamily: 'Nunito',
          fontSize: 6,
          fontWeight: FontWeight.w900,
          color: _ink,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: 70);
    text.paint(c, Offset(-text.width / 2, -5));
    c.restore();
  }

  void _bus(Canvas c, Offset p) {
    c.save();
    c.translate(p.dx, p.dy);
    c.drawOval(
      const Rect.fromLTWH(-22, 15, 45, 8),
      Paint()..color = const Color(0x24728B69),
    );
    c.drawRRect(
      RRect.fromRectAndRadius(
        const Rect.fromLTWH(-22, -16, 43, 32),
        const Radius.circular(9),
      ),
      Paint()..color = const Color(0xFFF2C95F),
    );
    c.drawRRect(
      RRect.fromRectAndRadius(
        const Rect.fromLTWH(8, -6, 20, 22),
        const Radius.circular(7),
      ),
      Paint()..color = const Color(0xFFF2C95F),
    );
    for (final x in [-14.0, -3.0, 8.0]) {
      c.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(x, -11, 8, 11),
          const Radius.circular(3),
        ),
        Paint()..color = const Color(0xFFE9F4EC),
      );
    }
    c.drawCircle(const Offset(-12, 16), 7, Paint()..color = _ink);
    c.drawCircle(const Offset(16, 16), 7, Paint()..color = _ink);
    c.drawCircle(
      const Offset(-12, 16),
      3,
      Paint()..color = const Color(0xFFD2DDC4),
    );
    c.drawCircle(
      const Offset(16, 16),
      3,
      Paint()..color = const Color(0xFFD2DDC4),
    );
    c.drawCircle(
      const Offset(23, 6),
      3,
      Paint()..color = const Color(0xFFFFF4CE),
    );
    _path(
      c,
      Path()
        ..moveTo(20, 11)
        ..quadraticBezierTo(24, 14, 27, 10),
      _ink,
      1.5,
    );
    c.restore();
  }

  void _flower(Canvas c, Offset p) {
    _path(
      c,
      Path()
        ..moveTo(p.dx, p.dy + 5)
        ..lineTo(p.dx, p.dy - 2),
      const Color(0xFF8EAF73),
      1.5,
    );
    for (var i = 0; i < 5; i++) {
      final a = i * math.pi * 2 / 5;
      c.drawCircle(
        p + Offset(math.cos(a), math.sin(a)) * 2.5,
        2.2,
        Paint()..color = const Color(0xFFF8D78C),
      );
    }
    c.drawCircle(p, 1.8, Paint()..color = const Color(0xFFD4AB5D));
  }

  @override
  bool shouldRepaint(covariant MazeScenePainter oldDelegate) =>
      oldDelegate.network != network ||
      oldDelegate.bus != bus ||
      oldDelegate.route.length != route.length ||
      oldDelegate.hint != hint ||
      oldDelegate.edgeProgress != edgeProgress ||
      oldDelegate.schoolLabel != schoolLabel;
}
