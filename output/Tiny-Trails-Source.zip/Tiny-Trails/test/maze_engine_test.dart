
import 'package:flutter_test/flutter_test.dart';
import 'package:tiny_trails/features/play/engines/maze_engine.dart';

void main() {
  group('connected road networks', () {
    test('all 24 catalog maze configurations have a legal route to school', () {
      for (final world in [
        'ocean',
        'forest',
        'meadow',
        'farm',
        'safari',
        'space',
      ]) {
        for (var variant = 0; variant < 4; variant++) {
          final maze = MazeNetwork.generate(
            seed: '$world-$variant',
            difficulty: variant + 1,
          );
          expect(maze.roads.any((r) => r.blocked), isTrue);
          for (var node = 0; node < maze.nodes.length; node++) {
            final route = maze.routeToGoal(node);
            expect(route.first, node);
            expect(route.last, maze.goal);
            for (var i = 1; i < route.length; i++) {
              expect(
                maze.roadBetween(route[i - 1], route[i])?.blocked,
                isFalse,
              );
            }
          }
        }
      }
    });
    test('stable seed reproduces roads and worlds produce varied routes', () {
      final a = MazeNetwork.generate(seed: 'ocean-0', difficulty: 1);
      final b = MazeNetwork.generate(seed: 'ocean-0', difficulty: 1);
      expect(a.nodes, b.nodes);
      expect(
        a.roads.map((r) => '${r.key}:${r.blocked}'),
        b.roads.map((r) => '${r.key}:${r.blocked}'),
      );
      final signatures = <String>{};
      for (final seed in ['ocean-0', 'forest-0', 'space-0', 'farm-0']) {
        final maze = MazeNetwork.generate(seed: seed, difficulty: 1);
        signatures.add(
          maze.roads.map((r) => '${r.key}:${r.blocked}').join(','),
        );
      }
      expect(signatures.length, greaterThan(2));
    });
    test(
      'higher difficulty uses more intersections and construction works',
      () {
        final easy = MazeNetwork.generate(seed: 'a', difficulty: 1);
        final hard = MazeNetwork.generate(seed: 'a', difficulty: 4);
        expect(hard.nodes.length, greaterThan(easy.nodes.length));
        expect(
          hard.roads.where((r) => r.blocked).length,
          greaterThan(easy.roads.where((r) => r.blocked).length),
        );
      },
    );
  });
  group('valid traversal', () {
    late MazeNetwork maze;
    late MazeSession session;
    setUp(() {
      maze = MazeNetwork.generate(seed: 'forest-1', difficulty: 2);
      session = MazeSession(maze);
    });
    test('cannot jump directly to school or start dragging away from bus', () {
      expect(session.tapNode(maze.goal), MazeMove.ignored);
      expect(session.beginDrag(maze.nodes[maze.goal]), isFalse);
      expect(session.current, maze.start);
      expect(session.isComplete, isFalse);
    });
    test('a blocked road never becomes traversable', () {
      final endpoints = maze.roads
          .where((r) => r.blocked)
          .expand((r) => [(r.a, r.b), (r.b, r.a)])
          .firstWhere(
            (e) => !_route(maze, maze.start, e.$1).contains(maze.goal),
          );
      final route = _route(maze, maze.start, endpoints.$1);
      for (final node in route.skip(1)) {
        session.tapNode(node);
      }
      expect(session.tapNode(endpoints.$2), MazeMove.blocked);
      expect(session.current, endpoints.$1);
    });
    test('off-road pointer motion does not move the bus', () {
      expect(session.beginDrag(session.busPosition), isTrue);
      final original = session.busPosition;
      expect(session.dragTo(const Offset(399, 399)), MazeMove.ignored);
      expect(session.busPosition, original);
      expect(session.route, [maze.start]);
    });
    test('continuous tracing follows each quadratic road and completes only at school', () {
      final route = maze.routeToGoal(maze.start);
      expect(session.beginDrag(session.busPosition), isTrue);
      for (var i = 1; i < route.length; i++) {
        final road = maze.roadBetween(route[i - 1], route[i])!;
        final forward = route[i - 1] == road.a;
        for (var sample = 1; sample <= 20; sample++) {
          final t = sample / 20;
          session.dragTo(road.point(forward ? t : 1 - t));
        }
        expect(session.current, route[i]);
        expect(session.isComplete, i == route.length - 1);
      }
    });
    test('tap access, undo, save and resume preserve a legal route', () {
      final route = maze.routeToGoal(maze.start);
      session.tapNode(route[1]);
      session.tapNode(route[2]);
      final resumed = MazeSession(maze, saved: session.toJson());
      expect(resumed.route, route.take(3));
      resumed.undo();
      expect(resumed.current, route[1]);
      resumed.reset();
      expect(resumed.route, [maze.start]);
    });
    test(
      'corrupt or forged saved route stops before an invalid connection',
      () {
        final route = maze.routeToGoal(maze.start);
        final restored = MazeSession(
          maze,
          saved: {
            'route': [maze.start, route[1], -1, maze.goal],
          },
        );
        expect(restored.route, [maze.start, route[1]]);
        expect(restored.isComplete, isFalse);
        final forged = MazeSession(
          maze,
          saved: {
            'route': [maze.goal],
          },
        );
        expect(forged.current, maze.start);
      },
    );
  });
}

List<int> _route(MazeNetwork maze, int from, int target) {
  final queue = <int>[from];
  final previous = <int, int?>{from: null};
  for (var i = 0; i < queue.length && !previous.containsKey(target); i++) {
    for (final edge in maze.roadsFrom(queue[i])) {
      final next = edge.other(queue[i]);
      if (!previous.containsKey(next)) {
        previous[next] = queue[i];
        queue.add(next);
      }
    }
  }
  final route = [target];
  while (route.last != from) {
    route.add(previous[route.last]!);
  }
  return route.reversed.toList();
}
