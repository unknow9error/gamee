import 'package:flutter/material.dart';

import '../../application/game_controller.dart';
import '../../core/strings.dart';
import '../../core/theme.dart';
import '../../domain/models.dart';
import '../../shared/widgets/common.dart';
import '../play/play_screen.dart';
import '../progress/progress_screen.dart';
import '../settings/settings_screen.dart';
import 'home_screen.dart';
import 'studio_screen.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key, required this.controller});
  final GameController controller;
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _tab = 0;
  void _play(LevelDefinition level) => Navigator.of(context).push(
    MaterialPageRoute<void>(
      builder: (_) => PlayScreen(controller: widget.controller, level: level),
    ),
  );

  @override
  Widget build(BuildContext context) {
    final c = widget.controller;
    final lang = c.language;
    final wide = MediaQuery.sizeOf(context).width >= 900;
    final labels = [
      textFor(lang, 'Приключения', 'Шытырман', 'Adventures'),
      textFor(lang, 'Мастерская', 'Шеберхана', 'My studio'),
      textFor(lang, 'Награды', 'Марапаттар', 'Rewards'),
    ];
    final icons = [
      Icons.explore_outlined,
      Icons.brush_outlined,
      Icons.emoji_events_outlined,
    ];
    final pages = [
      HomeScreen(controller: c, onPlay: _play),
      StudioScreen(controller: c, onPlay: _play),
      ProgressScreen(controller: c, onPlay: _play),
    ];
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.fromLTRB(
                wide ? 36 : 22,
                12,
                wide ? 36 : 18,
                10,
              ),
              child: Row(
                children: [
                  Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(
                      color: AppColors.green,
                      borderRadius: BorderRadius.circular(13),
                    ),
                    child: const Icon(
                      Icons.spa_rounded,
                      color: AppColors.lime,
                      size: 25,
                    ),
                  ),
                  const SizedBox(width: 10),
                  const Expanded(
                    child: Text(
                      'tiny trails',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 23,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -1,
                      ),
                    ),
                  ),
                  StarCount(count: c.totalStars),
                  const SizedBox(width: 5),
                  IconButton(
                    tooltip: textFor(
                      lang,
                      'Настройки',
                      'Баптаулар',
                      'Settings',
                    ),
                    onPressed: () => Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => SettingsScreen(controller: c),
                      ),
                    ),
                    icon: const Icon(Icons.settings_outlined),
                  ),
                ],
              ),
            ),
            if (c.persistenceError != null)
              MaterialBanner(
                content: Text(c.persistenceError!),
                actions: [
                  TextButton(
                    onPressed: c.retryPersistence,
                    child: Text(
                      textFor(
                        lang,
                        'Повторить сохранение',
                        'Қайта сақтау',
                        'Retry saving',
                      ),
                    ),
                  ),
                ],
              ),
            Expanded(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  if (wide)
                    NavigationRail(
                      selectedIndex: _tab,
                      onDestinationSelected: (v) => setState(() => _tab = v),
                      backgroundColor: AppColors.paper,
                      labelType: NavigationRailLabelType.all,
                      destinations: List.generate(
                        3,
                        (i) => NavigationRailDestination(
                          icon: Icon(icons[i]),
                          label: Text(labels[i]),
                        ),
                      ),
                    ),
                  Expanded(
                    child: IndexedStack(index: _tab, children: pages),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: wide
          ? null
          : NavigationBar(
              height: 76,
              backgroundColor: AppColors.paper,
              indicatorColor: AppColors.lime,
              selectedIndex: _tab,
              onDestinationSelected: (value) => setState(() => _tab = value),
              destinations: List.generate(
                3,
                (i) => NavigationDestination(
                  icon: Icon(icons[i]),
                  label: labels[i],
                ),
              ),
            ),
    );
  }
}
