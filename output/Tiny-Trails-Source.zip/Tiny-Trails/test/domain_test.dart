import 'package:flutter_test/flutter_test.dart';
import 'package:tiny_trails/application/game_controller.dart';
import 'package:tiny_trails/data/catalog.dart';
import 'package:tiny_trails/domain/models.dart';
import 'package:tiny_trails/domain/artwork_limits.dart';

void main() {
  group('content contract', () {
    test('six worlds cover all engines across four progressive chapters', () {
      expect(worlds.length, 6);
      expect(levels.length, 120);
      expect(levels.map((item) => item.id).toSet().length, levels.length);
      expect(achievements.length, greaterThanOrEqualTo(12));
      for (final world in worlds) {
        final content = levelsForWorld(world.id);
        expect(content.length, 20);
        expect(
          content.map((item) => item.order).toSet(),
          Set.of(List.generate(20, (i) => i)),
        );
        for (final kind in ActivityKind.values) {
          final activities = content.where((item) => item.kind == kind);
          expect(activities.length, 4);
          expect(activities.map((item) => item.difficulty).toSet(), {
            1,
            2,
            3,
            4,
          });
          expect(activities.map((item) => item.variant).toSet(), {0, 1, 2, 3});
        }
      }
    });

    test('all user-facing catalog text is present in all three languages', () {
      final copy = <LocalizedText>[
        for (final world in worlds) ...[world.title, world.subtitle],
        for (final level in levels) ...[level.title, level.instruction],
        for (final achievement in achievements) ...[
          achievement.title,
          achievement.description,
        ],
        for (final mission in missions) mission.title,
      ];
      for (final text in copy) {
        for (final language in ['ru', 'kk', 'en']) {
          expect(text.resolve(language).trim(), isNotEmpty);
        }
      }
    });
  });

  test('each world starts with all five engines and unlocks one chapter after three completions', () async {
    final controller = GameController.inMemory();
    for (final world in worlds) {
      final content = levelsForWorld(world.id);
      expect(content.take(5).every(controller.isUnlocked), isTrue);
      expect(content.skip(5).any(controller.isUnlocked), isFalse);
    }
    final content = levelsForWorld('ocean');
    for (final level in content.take(2)) {
      await controller.completeLevel(level);
    }
    expect(controller.isUnlocked(content[5]), isFalse);
    await controller.completeLevel(content[2]);
    expect(content.skip(5).take(5).every(controller.isUnlocked), isTrue);
    expect(controller.isUnlocked(content[10]), isFalse);
    expect(() => controller.completeLevel(content[15]), throwsStateError);
  });

  test(
    'replays preserve best stars and never duplicate achievements or paintings',
    () async {
      final controller = GameController.inMemory();
      final level = levels.first;
      final first = await controller.completeLevel(
        level,
        artwork: {
          'fills': {'body': 7},
        },
      );
      expect(first.firstCompletion, isTrue);
      expect(
        first.newAchievements.map((item) => item.id),
        contains('first_step'),
      );
      final replay = await controller.completeLevel(
        level,
        stars: 1,
        artwork: {
          'fills': {'body': 9},
        },
      );
      expect(replay.firstCompletion, isFalse);
      expect(replay.newAchievements, isEmpty);
      expect(controller.totalStars, 3);
      expect(controller.completedCount, 1);
      expect(controller.progress[level.id]!.attempts, 2);
      expect(controller.artworks.length, 1);
      expect(controller.artworks.single.data['fills']['body'], 9);
    },
  );

  test('draft input and returned copies cannot mutate owned state', () async {
    final controller = GameController.inMemory();
    final input = <String, dynamic>{
      'points': [
        [0.2, 0.4],
      ],
    };
    await controller.saveDraft(levels.first.id, input);
    (input['points'] as List).clear();
    final draft = controller.draftFor(levels.first.id)!;
    expect(draft['points'], hasLength(1));
    (draft['points'] as List).clear();
    expect(controller.draftFor(levels.first.id)!['points'], hasLength(1));
  });

  test('invalid drawing and unknown level leave progress unchanged', () async {
    final controller = GameController.inMemory();
    expect(
      () => controller.saveDraft(levels.first.id, {'x': double.nan}),
      throwsFormatException,
    );
    expect(() => controller.saveDraft('not-a-level', {}), throwsArgumentError);
    await expectLater(
      controller.completeLevel(levels.first, artwork: {'x': Object()}),
      throwsFormatException,
    );
    expect(controller.completedCount, 0);
    expect(controller.artworks, isEmpty);
  });

  test('ordinary oversampled brush strokes compact and survive save and completion', () async {
    final controller = GameController.inMemory();
    final payload = <String, dynamic>{
      'version': 1,
      'strokes': List.generate(
        20,
        (_) => {
          'color': 0xFFEA7563,
          'width': 12.0,
          'points': List.generate(1100, (i) => [i / 1100, .5]),
        },
      ),
    };
    await controller.saveDraft(levels[1].id, payload);
    final compact = controller.draftFor(levels[1].id)!;
    final strokes = compact['strokes'] as List;
    expect(strokes, hasLength(20));
    expect(
      strokes.fold<int>(
        0,
        (sum, stroke) => sum + (stroke['points'] as List).length,
      ),
      lessThanOrEqualTo(ArtworkLimits.maxTotalBrushPoints),
    );
    for (final stroke in strokes) {
      final points = stroke['points'] as List;
      expect(points.first, [0.0, .5]);
      expect(points.last[0], closeTo(1099 / 1100, .0001));
    }
    final reward = await controller.completeLevel(levels[1], artwork: payload);
    expect(reward.firstCompletion, isTrue);
    expect(controller.artworks.single.data['strokes'], hasLength(20));
  });
}
