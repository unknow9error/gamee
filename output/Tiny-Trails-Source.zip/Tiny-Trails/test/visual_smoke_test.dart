import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:tiny_trails/application/game_controller.dart';
import 'package:tiny_trails/core/strings.dart';
import 'package:tiny_trails/data/catalog.dart';
import 'package:tiny_trails/domain/models.dart';
import 'package:tiny_trails/main.dart';
import 'package:tiny_trails/shared/art/art_scene.dart';

const _captureFixtures = bool.fromEnvironment('CAPTURE_FIXTURES');
const _captureKey = ValueKey('visual-smoke-app');

String _canvasKey(ActivityKind kind) => switch (kind) {
  ActivityKind.numberColor || ActivityKind.freeColor => 'color-canvas',
  ActivityKind.maze => 'maze-canvas',
  ActivityKind.guidedDraw => 'drawing-canvas',
  ActivityKind.hiddenAnimals => 'hidden-canvas',
};

Future<void> _capture(WidgetTester tester, String name) async {
  if (!_captureFixtures) return;
  await tester.pump();
  await tester.runAsync(() async {
    final boundary = tester.renderObject<RenderRepaintBoundary>(
      find.byKey(_captureKey),
    );
    final image = await boundary.toImage(pixelRatio: 2);
    final bytes = await image.toByteData(format: ui.ImageByteFormat.png);
    final output = File('output/qa/fixture-$name.png');
    await output.parent.create(recursive: true);
    await output.writeAsBytes(bytes!.buffer.asUint8List());
    image.dispose();
  });
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUpAll(() async {
    // Real bundled typography makes these source renders useful for checking
    // wrapping and hierarchy. Ahem fallback would hide actual layout defects.
    await (FontLoader(
      'Nunito',
    )..addFont(rootBundle.load('assets/fonts/Nunito.ttf'))).load();
    await (FontLoader(
      'MaterialIcons',
    )..addFont(rootBundle.load('fonts/MaterialIcons-Regular.otf'))).load();
  });

  testWidgets('onboarding, themed map, all games, and rotation remain usable', (
    tester,
  ) async {
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(390, 844);
    addTearDown(tester.view.resetDevicePixelRatio);
    addTearDown(tester.view.resetPhysicalSize);
    final semantics = tester.ensureSemantics();
    try {
      final controller = GameController.inMemory();
      await controller.setReducedMotion(true);
      await controller.setSound(false);
      await controller.setHaptics(false);
      await controller.setVoice(false);
      for (final kind in ActivityKind.values) {
        await controller.markTutorialSeen(kind);
      }
      await tester.pumpWidget(
        RepaintBoundary(
          key: _captureKey,
          child: TinyTrailsApp(controller: controller),
        ),
      );
      await tester.pumpAndSettle();
      expect(find.byKey(const Key('onboarding-next')), findsOneWidget);
      await _capture(tester, 'onboarding-phone');
      for (var page = 0; page < 3; page++) {
        await tester.tap(find.byKey(const Key('onboarding-next')));
        await tester.pumpAndSettle();
      }
      expect(controller.onboardingComplete, isTrue);
      expect(find.byKey(const Key('continue-adventure')), findsOneWidget);
      await _capture(tester, 'home-phone');

      tester.view.physicalSize = const Size(1024, 768);
      await tester.pumpAndSettle();
      expect(find.byType(NavigationRail), findsOneWidget);
      await _capture(tester, 'home-tablet');
      tester.view.physicalSize = const Size(390, 844);
      await tester.pumpAndSettle();

      await tester.tap(find.text(worlds.first.title.ru));
      await tester.pumpAndSettle();
      for (final kind in ActivityKind.values) {
        final level = levels.firstWhere((level) => level.kind == kind);
        final label = '${level.order + 1}. ${activityName(kind, 'ru')}';
        final levelButton = find.byWidgetPredicate(
          (widget) => widget is Semantics && widget.properties.label == label,
        );
        await tester.ensureVisible(levelButton);
        await tester.tap(levelButton);
        await tester.pumpAndSettle();
        final canvas = find.byKey(ValueKey(_canvasKey(kind)));
        expect(canvas, findsOneWidget);
        await _capture(tester, 'play-${kind.name}-phone');
        expect(
          tester.getSize(canvas).shortestSide,
          greaterThanOrEqualTo(250),
          reason: '${kind.name} needs enough room for actual finger input.',
        );
        tester.view.physicalSize = const Size(844, 390);
        await tester.pumpAndSettle();
        await _capture(tester, 'play-${kind.name}-landscape');
        expect(
          tester.getSize(canvas).shortestSide,
          greaterThanOrEqualTo(220),
          reason: 'Rotation must preserve a usable ${kind.name} play area.',
        );
        if (kind == ActivityKind.freeColor) {
          final doneText = find.descendant(
            of: find.byKey(const Key('color-finish')),
            matching: find.byType(Text),
          );
          expect(
            tester.getSize(doneText).height,
            lessThanOrEqualTo(40),
            reason: 'The finish label must not wrap into a vertical column.',
          );
        }
        tester.view.physicalSize = const Size(390, 844);
        await tester.pumpAndSettle();
        String? paintedRegion;
        if (kind == ActivityKind.freeColor) {
          final region = SceneFactory.create(level.scene).regions
              .firstWhere((region) => region.group == 'subject');
          paintedRegion = region.id;
          final rect = tester.getRect(canvas);
          await tester.tapAt(
            rect.topLeft +
                Offset(
                  region.labelPoint.dx / 400 * rect.width,
                  region.labelPoint.dy / 400 * rect.height,
                ),
          );
          await tester.pump();
          tester.view.physicalSize = const Size(844, 390);
          await tester.pumpAndSettle();
          tester.view.physicalSize = const Size(390, 844);
          await tester.pumpAndSettle();
          await _capture(tester, 'play-freeColor-progress');
        }
        await tester.tap(find.byTooltip('Сохранить и выйти'));
        await tester.pumpAndSettle();
        if (paintedRegion != null) {
          expect(
            controller.draftFor(level.id)?['fills'],
            contains(paintedRegion),
            reason:
                'A painted region must survive rotation and leaving a game.',
          );
        }
        expect(tester.takeException(), isNull);
      }
      await tester.pumpWidget(const SizedBox());
      await controller.flush();
      controller.dispose();
    } finally {
      semantics.dispose();
    }
  });
}
