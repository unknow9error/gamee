import 'package:flutter/material.dart';

import '../../application/game_controller.dart';
import '../../core/strings.dart';
import '../../core/theme.dart';
import '../../data/catalog.dart';
import '../../domain/models.dart';
import '../../shared/art/scene_illustration.dart';
import '../../shared/widgets/common.dart';
import '../play/play_screen.dart';

class WorldScreen extends StatelessWidget {
  const WorldScreen({super.key, required this.world, required this.controller});
  final WorldDefinition world;
  final GameController controller;
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: controller,
    builder: (context, _) {
      final lang = controller.language;
      final worldLevels = levels.where((l) => l.worldId == world.id).toList();
      final count = worldLevels
          .where((l) => controller.progress.containsKey(l.id))
          .length;
      final tint = Color.alphaBlend(
        Color(world.color).withValues(alpha: .18),
        AppColors.paper,
      );
      return Scaffold(
        appBar: AppBar(
          title: Text(world.title.resolve(lang)),
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 16),
              child: StarCount(count: controller.totalStars),
            ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 22),
          children: [
            Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 620),
                child: Column(
                  children: [
                    SurfaceCard(
                      color: tint,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 22,
                        vertical: 12,
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  world.subtitle.resolve(lang),
                                  style: Theme.of(context)
                                      .textTheme
                                      .headlineMedium,
                                ),
                                const SizedBox(height: 10),
                                Text(
                                  textFor(
                                    lang,
                                    'Пройдено $count из 20',
                                    '20-дан $count аяқталды',
                                    '$count of 20 explored',
                                  ),
                                  style: const TextStyle(
                                    color: AppColors.muted,
                                  ),
                                ),
                                const SizedBox(height: 10),
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: LinearProgressIndicator(
                                    value: count / 20,
                                    minHeight: 7,
                                    backgroundColor: Colors.white,
                                    color: Color(world.color),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 115,
                            height: 125,
                            child: SceneIllustration(scene: world.scene),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 22),
                    for (var chapter = 0; chapter < 4; chapter++) ...[
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 5,
                            ),
                            decoration: BoxDecoration(
                              color: tint,
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(
                              '${textFor(lang, 'ГЛАВА', 'ТАРАУ', 'CHAPTER')} ${chapter + 1}',
                              style: const TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1,
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              [
                                textFor(
                                  lang,
                                  'Первое открытие',
                                  'Алғашқы жаңалық',
                                  'First discovery',
                                ),
                                textFor(
                                  lang,
                                  'Новые секреты',
                                  'Жаңа құпиялар',
                                  'New secrets',
                                ),
                                textFor(
                                  lang,
                                  'Смелое приключение',
                                  'Батыл саяхат',
                                  'Brave adventure',
                                ),
                                textFor(
                                  lang,
                                  'Большое мастерство',
                                  'Үлкен шеберлік',
                                  'Creative master',
                                ),
                              ][chapter],
                              style: const TextStyle(
                                fontWeight: FontWeight.w900,
                                fontSize: 16,
                              ),
                            ),
                          ),
                        ],
                      ),
                      _ChapterTrail(
                        controller: controller,
                        world: world,
                        items: worldLevels.sublist(
                          chapter * 5,
                          chapter * 5 + 5,
                        ),
                      ),
                    ],
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ],
        ),
      );
    },
  );
}

class _ChapterTrail extends StatelessWidget {
  const _ChapterTrail({
    required this.controller,
    required this.world,
    required this.items,
  });
  final GameController controller;
  final WorldDefinition world;
  final List<LevelDefinition> items;
  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, box) {
      final width = box.maxWidth;
      final points = List.generate(
        5,
        (i) => Offset(width * [.28, .65, .72, .38, .25][i], 54 + i * 106),
      );
      return SizedBox(
        height: 570,
        child: Stack(
          children: [
            Positioned.fill(
              child: CustomPaint(
                painter: _TrailPainter(
                  points: points,
                  color: Color(world.color),
                ),
              ),
            ),
            Positioned(
              right: 14,
              top: 315,
              width: 100,
              height: 100,
              child: Opacity(
                opacity: .65,
                child: SceneIllustration(
                  scene: world.scene,
                  variant: items.first.variant,
                ),
              ),
            ),
            for (var i = 0; i < 5; i++)
              Positioned(
                left: points[i].dx - 70,
                top: points[i].dy - 40,
                width: 140,
                child: _LevelNode(level: items[i], controller: controller),
              ),
          ],
        ),
      );
    },
  );
}

class _LevelNode extends StatelessWidget {
  const _LevelNode({required this.level, required this.controller});
  final LevelDefinition level;
  final GameController controller;
  @override
  Widget build(BuildContext context) {
    final lang = controller.language;
    final progress = controller.progress[level.id];
    final unlocked = controller.isUnlocked(level);
    return Column(
      children: [
        Semantics(
          button: true,
          label: '${level.order + 1}. ${activityName(level.kind, lang)}',
          child: SizedBox(
            width: 76,
            height: 76,
            child: Material(
              color: unlocked
                  ? activityColor(level.kind)
                  : const Color(0xFFE9EBE5),
              shape: CircleBorder(
                side: BorderSide(
                  color: progress != null ? AppColors.green : Colors.white,
                  width: 4,
                ),
              ),
              elevation: unlocked ? 3 : 0,
              shadowColor: AppColors.ink.withValues(alpha: .14),
              clipBehavior: Clip.antiAlias,
              child: InkWell(
                onTap: () {
                  if (unlocked) {
                    Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) =>
                            PlayScreen(controller: controller, level: level),
                      ),
                    );
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          textFor(
                            lang,
                            'Пройди 3 задания предыдущей главы, чтобы открыть эту.',
                            'Осы тарауды ашу үшін алдыңғы тараудың 3 тапсырмасын аяқта.',
                            'Finish 3 activities in the previous chapter to open this one.',
                          ),
                        ),
                      ),
                    );
                  }
                },
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Icon(
                      unlocked
                          ? activityIcon(level.kind)
                          : Icons.lock_outline_rounded,
                      size: 31,
                      color: unlocked ? AppColors.ink : AppColors.muted,
                    ),
                    Positioned(
                      top: 6,
                      left: 14,
                      child: Text(
                        '${level.order + 1}',
                        style: const TextStyle(
                          fontSize: 9,
                          fontWeight: FontWeight.w900,
                          color: AppColors.muted,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 6),
        Text(
          activityName(level.kind, lang),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800),
        ),
        if (progress != null)
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(
              3,
              (i) => Icon(
                Icons.star_rounded,
                size: 14,
                color: i < progress.stars
                    ? const Color(0xFFD7A342)
                    : AppColors.line,
              ),
            ),
          ),
      ],
    );
  }
}

class _TrailPainter extends CustomPainter {
  const _TrailPainter({required this.points, required this.color});
  final List<Offset> points;
  final Color color;
  @override
  void paint(Canvas canvas, Size size) {
    final path = Path()..moveTo(points.first.dx, points.first.dy);
    for (var i = 1; i < points.length; i++) {
      final a = points[i - 1], b = points[i];
      path.cubicTo(a.dx, a.dy + 60, b.dx, b.dy - 60, b.dx, b.dy);
    }
    canvas.drawPath(
      path,
      Paint()
        ..color = color.withValues(alpha: .13)
        ..strokeWidth = 21
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round,
    );
    final paint = Paint()
      ..color = color.withValues(alpha: .4)
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    for (final metric in path.computeMetrics()) {
      for (double d = 0; d < metric.length; d += 15) {
        canvas.drawPath(
          metric.extractPath(d, (d + 5).clamp(0, metric.length)),
          paint,
        );
      }
    }
    final leaf = Paint()..color = color.withValues(alpha: .16);
    for (var i = 0; i < 5; i++) {
      canvas.drawOval(
        Rect.fromCenter(
          center: Offset(size.width * (i.isEven ? .12 : .88), i * 106 + 86),
          width: 12,
          height: 22,
        ),
        leaf,
      );
    }
  }

  @override
  bool shouldRepaint(_TrailPainter old) =>
      old.color != color || old.points != points;
}
