import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../core/strings.dart';
import '../../core/theme.dart';
import '../../domain/artwork_limits.dart';
import '../../shared/art/art_scene.dart';
import 'activity_config.dart';
import 'engines/trace_engine.dart';

class DrawingActivity extends StatefulWidget {
  const DrawingActivity({super.key, required this.config});
  final ActivityConfig config;

  @override
  State<DrawingActivity> createState() => _DrawingActivityState();
}

class _DrawingActivityState extends State<DrawingActivity>
    with SingleTickerProviderStateMixin {
  late List<ArtStroke> _steps;
  late ArtScene _scene;
  late List<TraceValidator> _validators;
  late AnimationController _guide;
  final List<List<List<Offset>>> _completed = [];
  final List<List<Offset>> _current = [];
  final Map<String, Color> _fills = {};
  final List<Map<String, Color>> _fillHistory = [];
  double _coverage = 0;
  int _selectedColor = 0;
  bool _sent = false;
  bool _touching = false;
  int? _activePointer;

  int get _pointCount =>
      _completed.fold<int>(
        0,
        (total, stage) =>
            total + stage.fold<int>(0, (sum, stroke) => sum + stroke.length),
      ) +
      _current.fold<int>(0, (total, stroke) => total + stroke.length);
  int get _strokeCount =>
      _completed.fold<int>(0, (total, step) => total + step.length) +
      _current.length;

  static const _colors = [
    Color(0xFFF7CF63),
    Color(0xFFEB9B79),
    Color(0xFF81C4B3),
    Color(0xFF7FB5D5),
    Color(0xFFB1A0D0),
    Color(0xFFEC9DB4),
  ];

  ActivityConfig get config => widget.config;
  bool get _coloring => _completed.length == _steps.length;
  String _t(String ru, String kk, String en) =>
      textFor(config.language, ru, kk, en);

  @override
  void initState() {
    super.initState();
    _guide = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 4200),
    );
    _initialize();
    _setMotion();
  }

  void _initialize() {
    _steps = drawingSteps(config.level.scene);
    _scene = SceneFactory.create(
      config.level.scene,
      variant: config.level.variant,
    );
    _validators = [
      for (final step in _steps)
        TraceValidator(
          step.path,
          tolerance: 20 - config.level.difficulty.toDouble(),
        ),
    ];
    _completed.clear();
    _current.clear();
    _fills.clear();
    _fillHistory.clear();
    _coverage = 0;
    _sent = false;
    final data = config.initialData;
    if (data == null || data['type'] != 'guidedDraw') return;
    final completed = data['stepStrokes'];
    if (completed is List) {
      for (final item in completed.take(_steps.length)) {
        final strokes = decodeTraceStrokes(item);
        if (_pointCount +
                    strokes.fold<int>(
                      0,
                      (total, stroke) => total + stroke.length,
                    ) >
                ArtworkLimits.maxTotalBrushPoints ||
            _strokeCount + strokes.length > ArtworkLimits.maxBrushStrokes) {
          break;
        }
        if (!_validators[_completed.length].evaluate(strokes).complete) break;
        _completed.add(strokes);
      }
    }
    if (!_coloring) {
      final strokes = decodeTraceStrokes(data['currentStrokes']);
      if (_pointCount +
                  strokes.fold<int>(
                    0,
                    (total, stroke) => total + stroke.length,
                  ) <=
              ArtworkLimits.maxTotalBrushPoints &&
          _strokeCount + strokes.length <= ArtworkLimits.maxBrushStrokes) {
        _current.addAll(strokes);
      }
      _coverage = _validators[_completed.length].evaluate(_current).coverage;
    }
    final rawFills = data['fills'];
    if (rawFills is Map && _coloring) {
      final ids = _scene.regions.map((r) => r.id).toSet();
      rawFills.forEach((key, value) {
        if (key is String && value is int && ids.contains(key)) {
          _fills[key] = Color(value);
        }
      });
    }
  }

  void _setMotion() {
    if (config.reducedMotion) {
      _guide.stop();
      _guide.value = .25;
    } else {
      _guide.repeat();
    }
  }

  @override
  void didUpdateWidget(covariant DrawingActivity oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.config.level.id != config.level.id) _initialize();
    if (oldWidget.config.reducedMotion != config.reducedMotion) _setMotion();
  }

  @override
  void dispose() {
    _guide.dispose();
    super.dispose();
  }

  Map<String, dynamic> _data() => {
    'version': 1,
    'type': 'guidedDraw',
    'scene': config.level.scene,
    'step': _completed.length,
    'stepStrokes': [for (final step in _completed) encodeTraceStrokes(step)],
    'currentStrokes': encodeTraceStrokes(_current),
    'fills': {
      for (final entry in _fills.entries) entry.key: entry.value.toARGB32(),
    },
    'strokes': [
      for (final stroke in [..._completed.expand((step) => step), ..._current])
        {
          'color': AppColors.ink.toARGB32(),
          'width': 3.5,
          'points': [
            for (final p in stroke)
              [
                normalizedTraceCoordinate(p.dx),
                normalizedTraceCoordinate(p.dy),
              ],
          ],
        },
    ],
  };

  void _save() => config.onChanged(_data());

  Offset _toArt(Offset point, double side) => Offset(
    (point.dx / side * 400).clamp(0.0, 400.0),
    (point.dy / side * 400).clamp(0.0, 400.0),
  );

  void _start(Offset point, double side) {
    if (_coloring ||
        _sent ||
        _current.length >= 80 ||
        _strokeCount >= ArtworkLimits.maxBrushStrokes ||
        _pointCount >= ArtworkLimits.maxTotalBrushPoints) {
      return;
    }
    setState(() {
      _current.add([_toArt(point, side)]);
      _touching = true;
    });
  }

  void _move(Offset point, double side) {
    if (_coloring || !_touching || _current.isEmpty) return;
    final next = _toArt(point, side);
    final stroke = _current.last;
    final previous = stroke.last;
    final distance = (next - previous).distance;
    if (distance < 2 ||
        stroke.length >= ArtworkLimits.maxPointsPerStroke ||
        _pointCount >= ArtworkLimits.maxTotalBrushPoints) {
      return;
    }
    // Long pointer jumps do not create artificial lines across the contour.
    if (distance > 65) {
      _touching = false;
      _end();
      return;
    }
    final count = math.max(1, (distance / 7).ceil());
    final availablePoints = math.min(
      ArtworkLimits.maxPointsPerStroke - stroke.length,
      ArtworkLimits.maxTotalBrushPoints - _pointCount,
    );
    setState(() {
      for (var index = 1; index <= count && index <= availablePoints; index++) {
        stroke.add(Offset.lerp(previous, next, index / count)!);
      }
    });
  }

  void _end() {
    if (_coloring || _current.isEmpty) return;
    _touching = false;
    _activePointer = null;
    _current.removeWhere((stroke) => stroke.length < 2);
    for (var index = 0; index < _current.length; index++) {
      _current[index] = simplifyTraceStroke(_current[index]);
    }
    final result = _validators[_completed.length].evaluate(_current);
    setState(() {
      _coverage = result.coverage;
      if (result.complete) {
        _completed.add([for (final stroke in _current) List.of(stroke)]);
        _current.clear();
        _coverage = 0;
        _guide.value = 0;
      }
    });
    if (result.complete) config.onFeedback();
    _save();
  }

  void _fill(Offset point, double side) {
    if (!_coloring || _sent) return;
    final artPoint = _toArt(point, side);
    for (final region in _scene.regions.reversed) {
      if (!region.path.contains(artPoint)) continue;
      final color = _colors[_selectedColor];
      if (_fills[region.id] == color) return;
      _fillHistory.add(Map.of(_fills));
      setState(() => _fills[region.id] = color);
      config.onFeedback();
      _save();
      return;
    }
  }

  void _undo() {
    if (_sent) return;
    setState(() {
      if (_coloring && _fillHistory.isNotEmpty) {
        _fills
          ..clear()
          ..addAll(_fillHistory.removeLast());
      } else if (_current.isNotEmpty) {
        _current.removeLast();
      } else if (_completed.isNotEmpty) {
        _fills.clear();
        _fillHistory.clear();
        _current.addAll(_completed.removeLast());
        if (_current.isNotEmpty) _current.removeLast();
      }
      _coverage = _coloring
          ? 0
          : _validators[_completed.length].evaluate(_current).coverage;
    });
    _save();
  }

  Future<void> _reset() async {
    final reset = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          _t(
            'Начнём рисунок заново?',
            'Суретті қайта бастаймыз ба?',
            'Start this drawing again?',
          ),
        ),
        content: Text(
          _t(
            'Линии и цвета этого рисунка очистятся.',
            'Бұл суреттің сызықтары мен түстері өшіріледі.',
            'The lines and colors in this drawing will be cleared.',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(_t('Оставить', 'Қалдыру', 'Keep drawing')),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text(_t('Заново', 'Қайта бастау', 'Start again')),
          ),
        ],
      ),
    );
    if (reset != true || !mounted) return;
    setState(() {
      _completed.clear();
      _current.clear();
      _fills.clear();
      _fillHistory.clear();
      _coverage = 0;
      _sent = false;
    });
    _save();
  }

  bool get _enoughColor {
    final subjectIds = _scene.regions
        .where((r) => r.group == 'subject')
        .map((r) => r.id)
        .toSet();
    if (subjectIds.isEmpty) return _fills.isNotEmpty;
    return _fills.keys.where(subjectIds.contains).length >=
        math.min(2, subjectIds.length);
  }

  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, constraints) {
      final wide = constraints.maxWidth >= 650;
      final colors = _coloring ? _palette(wide) : null;
      final board = Expanded(
        child: Center(
          child: LayoutBuilder(
            builder: (context, space) {
              final side = math.min(space.maxWidth, space.maxHeight);
              return SizedBox.square(
                dimension: side,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(26),
                  child: ColoredBox(
                    color: Colors.white,
                    child: Semantics(
                      label: _coloring
                          ? _t(
                              'Нажимай на детали, чтобы раскрасить рисунок',
                              'Суретті бояу үшін бөліктерді бас',
                              'Tap the parts to color your drawing',
                            )
                          : _t(
                              'Поле для рисования. Обведи пунктирную линию.',
                              'Сурет салу алаңы. Үзік сызықты бастыр.',
                              'Drawing canvas. Trace the dotted line.',
                            ),
                      child: GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTapUp: _coloring
                            ? (details) => _fill(details.localPosition, side)
                            : null,
                        child: Listener(
                          key: const ValueKey('drawing-canvas'),
                          behavior: HitTestBehavior.opaque,
                          onPointerDown: _coloring
                              ? null
                              : (event) {
                                  if (_activePointer != null) return;
                                  _activePointer = event.pointer;
                                  _start(event.localPosition, side);
                                },
                          onPointerMove: _coloring
                              ? null
                              : (event) {
                                  if (_activePointer == event.pointer) {
                                    _move(event.localPosition, side);
                                  }
                                },
                          onPointerUp: _coloring
                              ? null
                              : (event) {
                                  if (_activePointer == event.pointer) _end();
                                },
                          onPointerCancel: _coloring
                              ? null
                              : (event) {
                                  if (_activePointer == event.pointer) _end();
                                },
                          child: AnimatedBuilder(
                            animation: _guide,
                            builder: (context, _) => CustomPaint(
                              painter: _DrawingPainter(
                                scene: _scene,
                                steps: _steps,
                                step: _completed.length,
                                completed: _completed,
                                current: _current,
                                fills: _fills,
                                guide: _guide.value,
                                showHint: config.showHint,
                              ),
                              child: const SizedBox.expand(),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      );
      final shortLandscape =
          constraints.maxWidth > constraints.maxHeight &&
          constraints.maxHeight < 500;
      if (shortLandscape) {
        return Row(
          children: [
            board,
            const SizedBox(width: 12),
            SizedBox(
              width: 224,
              child: Column(
                children: [
                  Expanded(
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          _status(compact: true),
                          _stepProgress(),
                          ?colors,
                        ],
                      ),
                    ),
                  ),
                  _actions(side: true),
                ],
              ),
            ),
          ],
        );
      }
      final compact = constraints.maxHeight < 500;
      return Column(
        children: [
          _status(compact: compact),
          _stepProgress(),
          SizedBox(height: compact ? 6 : 12),
          Expanded(
            child: Row(
              children: [
                board,
                if (wide && colors != null) SizedBox(width: 104, child: colors),
              ],
            ),
          ),
          if (!wide && colors != null) colors,
          _actions(compact: compact),
        ],
      );
    },
  );

  Widget _status({required bool compact}) => Padding(
    padding: EdgeInsets.fromLTRB(8, compact ? 0 : 4, 8, compact ? 4 : 10),
    child: Row(
      children: [
        Container(
          width: compact ? 36 : 44,
          height: compact ? 36 : 44,
          decoration: const BoxDecoration(
            color: AppColors.lime,
            shape: BoxShape.circle,
          ),
          child: Icon(
            _coloring ? Icons.palette_outlined : Icons.gesture_rounded,
            color: AppColors.green,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                _coloring
                    ? _t(
                        'Теперь добавь цвета!',
                        'Енді бояп көр!',
                        'Now add your colors!',
                      )
                    : _t(
                        'Шаг ${_completed.length + 1} из ${_steps.length}',
                        '${_steps.length} қадамның ${_completed.length + 1}-і',
                        'Step ${_completed.length + 1} of ${_steps.length}',
                      ),
                style: Theme.of(context).textTheme.titleMedium,
              ),
              if (!compact)
                Text(
                  _coloring
                      ? _t(
                          'Выбери цвет и нажми на рисунок',
                          'Түсті таңдап, суретті бас',
                          'Choose a color and tap the drawing',
                        )
                      : _t(
                          'Обводи пунктир короткими штрихами',
                          'Үзік сызықты қысқа штрихтармен бастыр',
                          'Trace the dotted line with short strokes',
                        ),
                  style: const TextStyle(fontSize: 12, color: AppColors.muted),
                ),
            ],
          ),
        ),
      ],
    ),
  );

  Widget _stepProgress() => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 10),
    child: Row(
      children: [
        for (var index = 0; index < _steps.length; index++)
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 3),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  minHeight: 7,
                  value: index < _completed.length
                      ? 1
                      : index == _completed.length
                      ? _coverage
                      : 0,
                  backgroundColor: AppColors.line,
                  color: AppColors.green,
                ),
              ),
            ),
          ),
      ],
    ),
  );

  Widget _actions({bool side = false, bool compact = false}) {
    final buttons = Row(
      children: [
        IconButton(
          tooltip: _t('Отменить штрих', 'Штрихты болдырмау', 'Undo stroke'),
          onPressed: _completed.isEmpty && _current.isEmpty ? null : _undo,
          icon: const Icon(Icons.undo_rounded),
        ),
        IconButton(
          tooltip: _t('Начать заново', 'Қайта бастау', 'Start again'),
          onPressed: _reset,
          icon: const Icon(Icons.restart_alt_rounded),
        ),
        if (!side) const Spacer(),
        if (!side && !_coloring && !compact)
          Flexible(
            child: Text(
              _t(
                'Не спеши — у тебя получится',
                'Асықпа — сенің қолыңнан келеді',
                'Take your time. You can do it!',
              ),
              style: const TextStyle(fontSize: 12, color: AppColors.muted),
              textAlign: TextAlign.end,
            ),
          ),
        if (!side && _coloring) _finishButton(),
      ],
    );
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 6, vertical: compact ? 2 : 8),
      child: side
          ? Column(children: [buttons, if (_coloring) _finishButton()])
          : buttons,
    );
  }

  Widget _finishButton() => FilledButton.icon(
    onPressed: _enoughColor && !_sent
        ? () {
            setState(() => _sent = true);
            config.onCompleted(_data());
          }
        : null,
    icon: const Icon(Icons.check_rounded),
    label: Text(_t('Готово!', 'Дайын!', 'All done!')),
  );

  Widget _palette(bool wide) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
    child: Wrap(
      alignment: WrapAlignment.center,
      spacing: 2,
      runSpacing: 4,
      children: [
        for (var index = 0; index < _colors.length; index++)
          Semantics(
            button: true,
            selected: _selectedColor == index,
            label: _t(
              'Цвет ${index + 1}',
              '${index + 1}-түс',
              'Color ${index + 1}',
            ),
            child: InkResponse(
              onTap: () => setState(() => _selectedColor = index),
              radius: 25,
              child: SizedBox(
                width: 48,
                height: 48,
                child: Center(
                  child: AnimatedContainer(
                    duration: config.reducedMotion
                        ? Duration.zero
                        : const Duration(milliseconds: 160),
                    width: _selectedColor == index ? 42 : 34,
                    height: _selectedColor == index ? 42 : 34,
                    decoration: BoxDecoration(
                      color: _colors[index],
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: _selectedColor == index
                            ? AppColors.ink
                            : Colors.white,
                        width: 3,
                      ),
                    ),
                    child: _selectedColor == index
                        ? const Icon(
                            Icons.check_rounded,
                            size: 20,
                            color: AppColors.ink,
                          )
                        : null,
                  ),
                ),
              ),
            ),
          ),
      ],
    ),
  );
}

class _DrawingPainter extends CustomPainter {
  _DrawingPainter({
    required this.scene,
    required this.steps,
    required this.step,
    required this.completed,
    required this.current,
    required this.fills,
    required this.guide,
    required this.showHint,
  });
  final ArtScene scene;
  final List<ArtStroke> steps;
  final int step;
  final List<List<List<Offset>>> completed;
  final List<List<Offset>> current;
  final Map<String, Color> fills;
  final double guide;
  final bool showHint;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / 400, size.height / 400);
    canvas.clipRect(const Rect.fromLTWH(0, 0, 400, 400));
    final coloring = step == steps.length;
    if (coloring) {
      for (final region in scene.regions) {
        if (fills.containsKey(region.id)) {
          canvas.drawPath(region.path, Paint()..color = fills[region.id]!);
        }
      }
    } else {
      final ghost = Paint()
        ..color = AppColors.green.withValues(alpha: .065)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..strokeCap = StrokeCap.round;
      for (final contour in steps) {
        canvas.drawPath(contour.path, ghost);
      }
    }
    final pencil = Paint()
      ..color = AppColors.ink
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..strokeWidth = 3.5;
    for (final stage in completed) {
      for (final stroke in stage) {
        _drawStroke(canvas, stroke, pencil);
      }
    }
    if (!coloring && steps.isNotEmpty) {
      final active = steps[step].path;
      if (showHint) {
        canvas.drawPath(
          active,
          Paint()
            ..color = AppColors.lime.withValues(alpha: .65)
            ..strokeWidth = 25
            ..style = PaintingStyle.stroke
            ..strokeCap = StrokeCap.round
            ..strokeJoin = StrokeJoin.round,
        );
      }
      _dash(
        canvas,
        active,
        Paint()
          ..color = AppColors.green.withValues(alpha: .65)
          ..strokeWidth = 2.6
          ..style = PaintingStyle.stroke
          ..strokeCap = StrokeCap.round,
      );
      for (final stroke in current) {
        _drawStroke(canvas, stroke, pencil);
      }
      final metrics = active.computeMetrics().toList();
      final length = metrics.fold(
        0.0,
        (value, metric) => value + metric.length,
      );
      var distance = guide * length;
      for (final metric in metrics) {
        if (distance <= metric.length) {
          final tangent = metric.getTangentForOffset(
            math.min(distance, metric.length - .001),
          );
          if (tangent != null) {
            canvas.drawCircle(
              tangent.position,
              showHint ? 10 : 6,
              Paint()..color = AppColors.peach,
            );
            canvas.drawCircle(
              tangent.position,
              showHint ? 5 : 3,
              Paint()..color = Colors.white,
            );
          }
          break;
        }
        distance -= metric.length;
      }
    }
    canvas.restore();
  }

  void _drawStroke(Canvas canvas, List<Offset> points, Paint paint) {
    if (points.length < 2) return;
    final path = Path()..moveTo(points.first.dx, points.first.dy);
    for (final point in points.skip(1)) {
      path.lineTo(point.dx, point.dy);
    }
    canvas.drawPath(path, paint);
  }

  void _dash(Canvas canvas, Path path, Paint paint) {
    for (final metric in path.computeMetrics()) {
      for (var distance = 0.0; distance < metric.length; distance += 13) {
        canvas.drawPath(
          metric.extractPath(distance, math.min(distance + 6.5, metric.length)),
          paint,
        );
      }
    }
  }

  @override
  bool shouldRepaint(covariant _DrawingPainter oldDelegate) => true;
}
