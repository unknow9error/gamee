import '../domain/models.dart';

String textFor(String language, String ru, String kk, String en) =>
    LocalizedText(ru, kk, en).resolve(language);

String activityName(ActivityKind kind, String language) => switch (kind) {
  ActivityKind.numberColor => textFor(
    language,
    'Цвета и числа',
    'Түстер мен сандар',
    'Color by number',
  ),
  ActivityKind.freeColor => textFor(
    language,
    'Мастерская цвета',
    'Түстер шеберханасы',
    'Color studio',
  ),
  ActivityKind.maze => textFor(
    language,
    'Найди дорогу',
    'Жолды тап',
    'Find the way',
  ),
  ActivityKind.guidedDraw => textFor(
    language,
    'Рисуем по шагам',
    'Қадамдап сурет салу',
    'Draw step by step',
  ),
  ActivityKind.hiddenAnimals => textFor(
    language,
    'Кто спрятался?',
    'Кім жасырынды?',
    'Who is hiding?',
  ),
};
